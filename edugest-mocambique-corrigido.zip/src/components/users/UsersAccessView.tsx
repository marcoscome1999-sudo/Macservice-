/**
 * EduGest Moçambique - Gestão de Utilizadores, Códigos de Acesso e Segurança
 * Ponto 1 e 2 do SNE: Criação de contas, geração de códigos individuais,
 * ativação/desativação, bloqueio, redefinição de PIN e controlo de permissões.
 */

import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { UserProfile, UserRole, RolePermissions } from '../../types';
import { StatusBadge } from '../common/StatusBadge';
import { Pagination } from '../common/Pagination';
import { EmptyState } from '../common/EmptyState';
import { ConfirmDialog } from '../common/ConfirmDialog';
import {
  ShieldCheck,
  UserPlus,
  KeyRound,
  Lock,
  Unlock,
  Trash2,
  Search,
  CheckCircle2,
  Building,
  UserCheck,
  GraduationCap,
  Users,
  Eye,
  EyeOff,
  Sliders,
  Sparkles,
  Phone,
  Mail,
  FileText
} from 'lucide-react';

export const UsersAccessView: React.FC = () => {
  const {
    db,
    currentUser,
    currentSchool,
    addUser,
    updateUser,
    deleteUser,
    toggleUserStatus,
    resetUserPin,
    revokeUserAccess,
    updateRolePermissions,
    updateSchool
  } = useApp();

  // Abas do Módulo de Administração
  const [activeSubTab, setActiveSubTab] = useState<'UTILIZADORES' | 'PERMISSOES' | 'ESCOLA'>('UTILIZADORES');

  // Filtros de Utilizadores
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('TODOS');
  const [statusFilter, setStatusFilter] = useState<string>('TODOS');
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  // Estados de Modais
  const [isAddUserModalOpen, setIsAddUserModalOpen] = useState(false);
  const [showPinId, setShowPinId] = useState<string | null>(null);
  const [userToDelete, setUserToDelete] = useState<UserProfile | null>(null);
  const [resetPinSuccess, setResetPinSuccess] = useState<string | null>(null);

  // Formulário de Novo Utilizador
  const [newUserForm, setNewUserForm] = useState<{
    name: string;
    email: string;
    role: UserRole;
    phone: string;
    pin: string;
    linkedTeacherId: string;
    linkedStudentId: string;
  }>({
    name: '',
    email: '',
    role: 'PROFESSOR',
    phone: '',
    pin: '1234',
    linkedTeacherId: db.teachers[0]?.id || '',
    linkedStudentId: db.students[0]?.id || ''
  });

  // Formulário de Edição da Escola
  const [schoolForm, setSchoolForm] = useState({
    name: currentSchool.name,
    code: currentSchool.code,
    type: currentSchool.type,
    province: currentSchool.province,
    district: currentSchool.district,
    address: currentSchool.address,
    phone: currentSchool.phone,
    email: currentSchool.email,
    directorName: currentSchool.directorName,
    nuit: currentSchool.nuit
  });
  const [schoolSaveSuccess, setSchoolSaveSuccess] = useState(false);

  // Utilizadores filtrados
  const filteredUsers = useMemo(() => {
    return db.users.filter((u) => {
      const matchSearch =
        u.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        u.accessCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
        u.email.toLowerCase().includes(searchTerm.toLowerCase());
      const matchRole = roleFilter === 'TODOS' || u.role === roleFilter;
      const matchStatus = statusFilter === 'TODOS' || u.status === statusFilter;
      return matchSearch && matchRole && matchStatus;
    });
  }, [db.users, searchTerm, roleFilter, statusFilter]);

  // Paginação
  const totalPages = Math.ceil(filteredUsers.length / pageSize) || 1;
  const paginatedUsers = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredUsers.slice(start, start + pageSize);
  }, [filteredUsers, currentPage, pageSize]);

  // Submissão de Novo Utilizador
  const handleCreateUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUserForm.name.trim() || !newUserForm.email.trim()) return;

    addUser({
      name: newUserForm.name.trim(),
      email: newUserForm.email.trim(),
      role: newUserForm.role,
      phone: newUserForm.phone.trim() || '+258 84 000 0000',
      pin: newUserForm.pin.trim() || '1234',
      status: 'ACTIVO',
      schoolId: currentSchool.id,
      linkedTeacherId: newUserForm.role === 'PROFESSOR' ? newUserForm.linkedTeacherId : undefined,
      linkedStudentId:
        newUserForm.role === 'ALUNO' || newUserForm.role === 'ENCARREGADO'
          ? newUserForm.linkedStudentId
          : undefined
    });

    setIsAddUserModalOpen(false);
    setNewUserForm({
      name: '',
      email: '',
      role: 'PROFESSOR',
      phone: '',
      pin: '1234',
      linkedTeacherId: db.teachers[0]?.id || '',
      linkedStudentId: db.students[0]?.id || ''
    });
  };

  // Salvar Dados da Escola
  const handleSaveSchool = (e: React.FormEvent) => {
    e.preventDefault();
    updateSchool({
      ...currentSchool,
      ...schoolForm
    });
    setSchoolSaveSuccess(true);
    setTimeout(() => setSchoolSaveSuccess(false), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Cabeçalho da Página */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
            <ShieldCheck className="h-6 w-6 text-sky-600" />
            Painel do Administrador & Segurança
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Gestão global de utilizadores, emissão de códigos de acesso SNE, matriz de permissões e dados da instituição.
          </p>
        </div>

        {activeSubTab === 'UTILIZADORES' && (
          <button
            onClick={() => setIsAddUserModalOpen(true)}
            className="inline-flex items-center justify-center gap-2 rounded-xl bg-slate-900 px-4 py-2.5 text-xs sm:text-sm font-semibold text-white shadow-sm hover:bg-slate-800 transition-colors"
          >
            <UserPlus className="h-4 w-4 text-sky-400" />
            Criar Utilizador & Código
          </button>
        )}
      </div>

      {/* Navegação entre Abas do Administrador */}
      <div className="flex items-center gap-2 border-b border-slate-200">
        <button
          onClick={() => setActiveSubTab('UTILIZADORES')}
          className={`flex items-center gap-2 border-b-2 px-4 py-2.5 text-xs sm:text-sm font-bold transition-colors ${
            activeSubTab === 'UTILIZADORES'
              ? 'border-sky-600 text-sky-600'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <Users className="h-4 w-4" />
          Utilizadores & Códigos de Acesso
          <span className="ml-1 rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-bold text-slate-600">
            {db.users.length}
          </span>
        </button>

        <button
          onClick={() => setActiveSubTab('PERMISSOES')}
          className={`flex items-center gap-2 border-b-2 px-4 py-2.5 text-xs sm:text-sm font-bold transition-colors ${
            activeSubTab === 'PERMISSOES'
              ? 'border-sky-600 text-sky-600'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <Sliders className="h-4 w-4" />
          Matriz de Permissões por Função
        </button>

        <button
          onClick={() => setActiveSubTab('ESCOLA')}
          className={`flex items-center gap-2 border-b-2 px-4 py-2.5 text-xs sm:text-sm font-bold transition-colors ${
            activeSubTab === 'ESCOLA'
              ? 'border-sky-600 text-sky-600'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <Building className="h-4 w-4" />
          Configuração da Escola
        </button>
      </div>

      {/* Feedback de Redefinição de PIN */}
      {resetPinSuccess && (
        <div className="flex items-center justify-between rounded-xl bg-emerald-50 border border-emerald-200 px-4 py-3 text-xs sm:text-sm font-semibold text-emerald-800">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 text-emerald-600" />
            <span>{resetPinSuccess}</span>
          </div>
          <button onClick={() => setResetPinSuccess(null)} className="text-emerald-600 hover:text-emerald-900">
            ✕
          </button>
        </div>
      )}

      {/* ABA 1: UTILIZADORES E CÓDIGOS DE ACESSO */}
      {activeSubTab === 'UTILIZADORES' && (
        <div className="space-y-4">
          {/* Barra de Filtros */}
          <div className="flex flex-col gap-3 rounded-2xl border border-slate-200 bg-white p-4 shadow-xs md:flex-row md:items-center md:justify-between">
            <div className="relative flex-1">
              <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Pesquisar por nome, código de acesso (ex: PROF-2026) ou e-mail..."
                value={searchTerm}
                onChange={(e) => {
                  setSearchTerm(e.target.value);
                  setCurrentPage(1);
                }}
                className="w-full rounded-xl border border-slate-200 bg-slate-50/50 pl-10 pr-4 py-2 text-xs sm:text-sm text-slate-900 placeholder:text-slate-400 focus:border-sky-500 focus:bg-white focus:outline-hidden"
              />
            </div>

            <div className="flex items-center gap-2 overflow-x-auto pb-1 md:pb-0">
              <select
                value={roleFilter}
                onChange={(e) => {
                  setRoleFilter(e.target.value);
                  setCurrentPage(1);
                }}
                className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 focus:border-sky-500 focus:outline-hidden"
              >
                <option value="TODOS">Todos os Perfis</option>
                <option value="ADMIN">Administrador</option>
                <option value="DIRECAO">Direção</option>
                <option value="SECRETARIA">Secretaria</option>
                <option value="PROFESSOR">Professor</option>
                <option value="ALUNO">Aluno</option>
                <option value="ENCARREGADO">Encarregado</option>
              </select>

              <select
                value={statusFilter}
                onChange={(e) => {
                  setStatusFilter(e.target.value);
                  setCurrentPage(1);
                }}
                className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 focus:border-sky-500 focus:outline-hidden"
              >
                <option value="TODOS">Todos os Estados</option>
                <option value="ACTIVO">Activo</option>
                <option value="BLOQUEADO">Bloqueado</option>
                <option value="INACTIVO">Inactivo</option>
              </select>
            </div>
          </div>

          {/* Tabela de Contas e Códigos */}
          <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-left text-xs sm:text-sm">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50/80 font-bold text-slate-600">
                    <th className="py-3.5 pl-4 pr-3">Utilizador</th>
                    <th className="px-3 py-3.5">Perfil</th>
                    <th className="px-3 py-3.5">Código de Acesso</th>
                    <th className="px-3 py-3.5">Senha / PIN</th>
                    <th className="px-3 py-3.5">Estado</th>
                    <th className="px-3 py-3.5">Último Acesso</th>
                    <th className="py-3.5 pl-3 pr-4 text-right">Ações do Administrador</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                  {paginatedUsers.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="p-8 text-center">
                        <EmptyState
                          title="Nenhum utilizador encontrado"
                          description="Não foram encontrados utilizadores com os critérios de pesquisa fornecidos."
                          actionLabel="Criar Novo Utilizador"
                          onAction={() => setIsAddUserModalOpen(true)}
                        />
                      </td>
                    </tr>
                  ) : (
                    paginatedUsers.map((user) => {
                      const isRevealed = showPinId === user.id;

                      return (
                        <tr key={user.id} className="hover:bg-slate-50/60 transition-colors">
                          <td className="py-3.5 pl-4 pr-3">
                            <div className="flex items-center gap-2.5">
                              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-100 font-bold text-slate-700 border border-slate-200 text-xs">
                                {user.name.charAt(0)}
                              </div>
                              <div className="min-w-0">
                                <p className="font-bold text-slate-900 truncate">{user.name}</p>
                                <p className="text-[11px] text-slate-500 truncate">{user.email}</p>
                              </div>
                            </div>
                          </td>

                          <td className="px-3 py-3.5">
                            <span className="inline-flex items-center rounded-md bg-slate-100 px-2 py-0.5 text-[11px] font-bold text-slate-700 border border-slate-200">
                              {user.role}
                            </span>
                          </td>

                          <td className="px-3 py-3.5">
                            <span className="font-mono font-extrabold text-sky-800 bg-sky-50 border border-sky-200 px-2 py-0.5 rounded-md text-xs">
                              {user.accessCode}
                            </span>
                          </td>

                          <td className="px-3 py-3.5">
                            <div className="flex items-center gap-1.5 font-mono text-xs text-slate-600">
                              <span>{isRevealed ? user.pin : '••••'}</span>
                              <button
                                onClick={() => setShowPinId(isRevealed ? null : user.id)}
                                title={isRevealed ? 'Ocultar PIN' : 'Ver PIN'}
                                className="text-slate-400 hover:text-slate-600 p-0.5"
                              >
                                {isRevealed ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                              </button>
                            </div>
                          </td>

                          <td className="px-3 py-3.5">
                            <StatusBadge status={user.status} />
                          </td>

                          <td className="px-3 py-3.5 text-slate-500 text-xs">
                            {user.lastLogin || 'Nunca acessou'}
                          </td>

                          <td className="py-3.5 pl-3 pr-4 text-right">
                            <div className="flex items-center justify-end gap-1">
                              {/* Ativar/Bloquear */}
                              <button
                                onClick={() => toggleUserStatus(user.id)}
                                title={user.status === 'ACTIVO' ? 'Bloquear Utilizador' : 'Ativar Utilizador'}
                                className={`rounded-lg p-1.5 transition-colors ${
                                  user.status === 'ACTIVO'
                                    ? 'text-slate-500 hover:bg-amber-50 hover:text-amber-700'
                                    : 'text-emerald-600 hover:bg-emerald-50'
                                }`}
                              >
                                {user.status === 'ACTIVO' ? (
                                  <Lock className="h-4 w-4" />
                                ) : (
                                  <Unlock className="h-4 w-4" />
                                )}
                              </button>

                              {/* Redefinir PIN */}
                              <button
                                onClick={() => {
                                  resetUserPin(user.id, '1234');
                                  setResetPinSuccess(`PIN do utilizador ${user.name} foi redefinido para "1234".`);
                                }}
                                title="Redefinir PIN para 1234"
                                className="rounded-lg p-1.5 text-slate-500 hover:bg-sky-50 hover:text-sky-700 transition-colors"
                              >
                                <KeyRound className="h-4 w-4" />
                              </button>

                              {/* Eliminar (não permite eliminar a si próprio) */}
                              {user.id !== currentUser.id && (
                                <button
                                  onClick={() => setUserToDelete(user)}
                                  title="Eliminar Utilizador"
                                  className="rounded-lg p-1.5 text-slate-400 hover:bg-rose-50 hover:text-rose-600 transition-colors"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            {/* Paginação */}
            {filteredUsers.length > 0 && (
              <Pagination
                currentPage={currentPage}
                totalPages={totalPages}
                totalItems={filteredUsers.length}
                pageSize={pageSize}
                onPageChange={setCurrentPage}
                onPageSizeChange={(newSize) => {
                  setPageSize(newSize);
                  setCurrentPage(1);
                }}
                itemLabel="utilizadores"
              />
            )}
          </div>
        </div>
      )}

      {/* ABA 2: MATRIZ DE PERMISSÕES POR FUNÇÃO */}
      {activeSubTab === 'PERMISSOES' && (
        <div className="space-y-4">
          <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs space-y-3">
            <div className="flex items-center gap-2">
              <Sliders className="h-5 w-5 text-sky-600" />
              <h3 className="font-extrabold text-slate-900 text-base">
                Controlo de Acesso Baseado em Funções (RBAC)
              </h3>
            </div>
            <p className="text-xs sm:text-sm text-slate-500">
              O Administrador define exatamente o que cada perfil pode visualizar, criar, editar ou homologar no sistema escolar.
            </p>
          </div>

          <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-left text-xs sm:text-sm">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50/80 font-bold text-slate-700">
                    <th className="py-3.5 pl-4 pr-3">Módulo / Permissão</th>
                    <th className="px-3 py-3.5 text-center">ADMIN</th>
                    <th className="px-3 py-3.5 text-center">DIREÇÃO</th>
                    <th className="px-3 py-3.5 text-center">SECRETARIA</th>
                    <th className="px-3 py-3.5 text-center">PROFESSOR</th>
                    <th className="px-3 py-3.5 text-center">ALUNO</th>
                    <th className="px-3 py-3.5 text-center">ENCARREGADO</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                  {[
                    { key: 'canManageUsers', label: 'Gerir Utilizadores e Códigos de Acesso' },
                    { key: 'canManageSchool', label: 'Configurações Institucionais da Escola' },
                    { key: 'canManageStudents', label: 'Cadastrar e Gerir Alunos' },
                    { key: 'canManageTeachers', label: 'Gerir Corpo Docente' },
                    { key: 'canManageEnrollments', label: 'Processar e Renovar Matrículas' },
                    { key: 'canManageClasses', label: 'Gestão de Turmas e Salas' },
                    { key: 'canManageSubjects', label: 'Gestão Curricular de Disciplinas' },
                    { key: 'canManageSchedules', label: 'Configuração de Horários Escolares' },
                    { key: 'canLaunchGrades', label: 'Lançamento de Notas e Avaliações' },
                    { key: 'canApprovePautas', label: 'Homologação e Aprovação de Pautas' },
                    { key: 'canManageAttendance', label: 'Controlo de Assiduidade e Faltas' },
                    { key: 'canManageFinance', label: 'Gestão Financeira e Propinas' },
                    { key: 'canIssueDocuments', label: 'Emissão de Declarações e Certificados' },
                    { key: 'canManageTransfers', label: 'Guias e Processos de Transferência' },
                    { key: 'canViewReports', label: 'Acesso a Relatórios Pedagógicos Gerais' },
                    { key: 'canPublishAnnouncements', label: 'Publicação de Comunicados Oficiais' },
                    { key: 'canConfigureSNE', label: 'Parâmetros e Regras SNE (MINEDH)' },
                    { key: 'canViewAuditLogs', label: 'Consulta aos Logs de Auditoria do Sistema' }
                  ].map((perm) => {
                    const permKey = perm.key as keyof RolePermissions;

                    return (
                      <tr key={perm.key} className="hover:bg-slate-50/60 transition-colors">
                        <td className="py-3 pl-4 pr-3 font-semibold text-slate-800">{perm.label}</td>

                        {(['ADMIN', 'DIRECAO', 'SECRETARIA', 'PROFESSOR', 'ALUNO', 'ENCARREGADO'] as UserRole[]).map(
                          (role) => {
                            const isChecked = !!db.rolePermissions?.[role]?.[permKey];
                            const isReadOnly = role === 'ADMIN'; // Admin sempre tem acesso total

                            return (
                              <td key={role} className="px-3 py-3 text-center">
                                <input
                                  type="checkbox"
                                  checked={isChecked}
                                  disabled={isReadOnly}
                                  onChange={(e) => {
                                    updateRolePermissions(role, {
                                      [permKey]: e.target.checked
                                    });
                                  }}
                                  className={`h-4 w-4 rounded-sm border-slate-300 text-sky-600 focus:ring-sky-500 ${
                                    isReadOnly ? 'opacity-60 cursor-not-allowed' : 'cursor-pointer'
                                  }`}
                                />
                              </td>
                            );
                          }
                        )}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ABA 3: CONFIGURAÇÃO INSTITUCIONAL DA ESCOLA */}
      {activeSubTab === 'ESCOLA' && (
        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-xs">
          <form onSubmit={handleSaveSchool} className="space-y-6">
            <div className="border-b border-slate-200 pb-4">
              <h3 className="text-base font-extrabold text-slate-900">
                Identificação & Dados Gerais da Escola
              </h3>
              <p className="text-xs text-slate-500">
                Informações oficiais utilizadas nos cabeçalhos de pautas, certificados e documentos oficiais.
              </p>
            </div>

            {schoolSaveSuccess && (
              <div className="flex items-center gap-2 rounded-xl bg-emerald-50 border border-emerald-200 p-3 text-xs sm:text-sm font-semibold text-emerald-800">
                <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                Dados institucionais da escola guardados com sucesso!
              </div>
            )}

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Nome Oficial da Escola *</label>
                <input
                  type="text"
                  required
                  value={schoolForm.name}
                  onChange={(e) => setSchoolForm({ ...schoolForm, name: e.target.value })}
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs sm:text-sm focus:border-sky-500 focus:bg-white focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Código SIGE da Escola *</label>
                <input
                  type="text"
                  required
                  value={schoolForm.code}
                  onChange={(e) => setSchoolForm({ ...schoolForm, code: e.target.value })}
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs sm:text-sm focus:border-sky-500 focus:bg-white focus:outline-hidden font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Tipo de Instituição *</label>
                <select
                  value={schoolForm.type}
                  onChange={(e) => setSchoolForm({ ...schoolForm, type: e.target.value as any })}
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs sm:text-sm focus:border-sky-500 focus:bg-white focus:outline-hidden font-semibold"
                >
                  <option value="PUBLICA">Pública (MINEDH)</option>
                  <option value="PRIVADA">Privada</option>
                  <option value="COMUNITARIA">Comunitária</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Província *</label>
                <input
                  type="text"
                  required
                  value={schoolForm.province}
                  onChange={(e) => setSchoolForm({ ...schoolForm, province: e.target.value })}
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs sm:text-sm focus:border-sky-500 focus:bg-white focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Distrito Municipal *</label>
                <input
                  type="text"
                  required
                  value={schoolForm.district}
                  onChange={(e) => setSchoolForm({ ...schoolForm, district: e.target.value })}
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs sm:text-sm focus:border-sky-500 focus:bg-white focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">NUIT da Escola</label>
                <input
                  type="text"
                  value={schoolForm.nuit}
                  onChange={(e) => setSchoolForm({ ...schoolForm, nuit: e.target.value })}
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs sm:text-sm focus:border-sky-500 focus:bg-white focus:outline-hidden font-mono"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-slate-700 mb-1">Endereço Físico</label>
                <input
                  type="text"
                  value={schoolForm.address}
                  onChange={(e) => setSchoolForm({ ...schoolForm, address: e.target.value })}
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs sm:text-sm focus:border-sky-500 focus:bg-white focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Telefone Principal</label>
                <input
                  type="text"
                  value={schoolForm.phone}
                  onChange={(e) => setSchoolForm({ ...schoolForm, phone: e.target.value })}
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs sm:text-sm focus:border-sky-500 focus:bg-white focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">E-mail Institucional</label>
                <input
                  type="email"
                  value={schoolForm.email}
                  onChange={(e) => setSchoolForm({ ...schoolForm, email: e.target.value })}
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs sm:text-sm focus:border-sky-500 focus:bg-white focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Nome do(a) Diretor(a) da Escola</label>
                <input
                  type="text"
                  value={schoolForm.directorName}
                  onChange={(e) => setSchoolForm({ ...schoolForm, directorName: e.target.value })}
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs sm:text-sm focus:border-sky-500 focus:bg-white focus:outline-hidden"
                />
              </div>
            </div>

            <div className="flex justify-end pt-4 border-t border-slate-200">
              <button
                type="submit"
                className="rounded-xl bg-sky-600 px-5 py-2.5 text-xs sm:text-sm font-bold text-white shadow-xs hover:bg-sky-700 transition-colors"
              >
                Salvar Alterações Institucionais
              </button>
            </div>
          </form>
        </div>
      )}

      {/* MODAL: CRIAR NOVO UTILIZADOR & GERAR CÓDIGO */}
      {isAddUserModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
          <div className="relative w-full max-w-lg rounded-2xl bg-white p-6 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-4">
              <h3 className="font-extrabold text-slate-900 text-base flex items-center gap-2">
                <UserPlus className="h-5 w-5 text-sky-600" />
                Criar Nova Conta & Código Individual
              </h3>
              <button
                onClick={() => setIsAddUserModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-lg font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateUser} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Nome Completo *</label>
                <input
                  type="text"
                  required
                  placeholder="ex: Prof. Zefanias Langa"
                  value={newUserForm.name}
                  onChange={(e) => setNewUserForm({ ...newUserForm, name: e.target.value })}
                  className="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs sm:text-sm focus:border-sky-500 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Perfil de Acesso *</label>
                  <select
                    value={newUserForm.role}
                    onChange={(e) => setNewUserForm({ ...newUserForm, role: e.target.value as UserRole })}
                    className="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs sm:text-sm focus:border-sky-500 focus:outline-hidden font-semibold"
                  >
                    <option value="PROFESSOR">Professor</option>
                    <option value="ALUNO">Aluno</option>
                    <option value="ENCARREGADO">Encarregado de Educação</option>
                    <option value="SECRETARIA">Secretaria</option>
                    <option value="DIRECAO">Direção</option>
                    <option value="ADMIN">Administrador</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Senha / PIN Inicial *</label>
                  <input
                    type="text"
                    required
                    value={newUserForm.pin}
                    onChange={(e) => setNewUserForm({ ...newUserForm, pin: e.target.value })}
                    className="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs sm:text-sm focus:border-sky-500 focus:outline-hidden font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">E-mail *</label>
                  <input
                    type="email"
                    required
                    placeholder="utilizador@escola.edu.mz"
                    value={newUserForm.email}
                    onChange={(e) => setNewUserForm({ ...newUserForm, email: e.target.value })}
                    className="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs sm:text-sm focus:border-sky-500 focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Telefone (Contacto)</label>
                  <input
                    type="text"
                    placeholder="+258 84 000 0000"
                    value={newUserForm.phone}
                    onChange={(e) => setNewUserForm({ ...newUserForm, phone: e.target.value })}
                    className="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs sm:text-sm focus:border-sky-500 focus:outline-hidden"
                  />
                </div>
              </div>

              {/* Vínculo opcional se for Professor */}
              {newUserForm.role === 'PROFESSOR' && (
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Vincular a Registo Docente Existente
                  </label>
                  <select
                    value={newUserForm.linkedTeacherId}
                    onChange={(e) => setNewUserForm({ ...newUserForm, linkedTeacherId: e.target.value })}
                    className="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs sm:text-sm focus:border-sky-500 focus:outline-hidden"
                  >
                    {db.teachers.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.fullName} ({t.employeeNumber})
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {/* Vínculo opcional se for Aluno ou Encarregado */}
              {(newUserForm.role === 'ALUNO' || newUserForm.role === 'ENCARREGADO') && (
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {newUserForm.role === 'ALUNO' ? 'Vincular a Aluno' : 'Vincular a Educando'}
                  </label>
                  <select
                    value={newUserForm.linkedStudentId}
                    onChange={(e) => setNewUserForm({ ...newUserForm, linkedStudentId: e.target.value })}
                    className="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs sm:text-sm focus:border-sky-500 focus:outline-hidden"
                  >
                    {db.students.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.fullName} ({s.studentNumber} - {s.currentClass})
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div className="rounded-xl bg-sky-50 border border-sky-100 p-3 text-xs text-sky-800">
                <p className="font-bold flex items-center gap-1.5">
                  <Sparkles className="h-3.5 w-3.5 text-sky-600" />
                  Geração Automática de Código SNE:
                </p>
                <p className="mt-0.5 text-sky-700">
                  O sistema irá gerar automaticamente o código padronizado (ex: <strong>PROF-2026-0049</strong> ou <strong>ALU-2026-0422</strong>) após a criação.
                </p>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsAddUserModalOpen(false)}
                  className="rounded-xl border border-slate-200 px-4 py-2 text-xs sm:text-sm font-semibold text-slate-600 hover:bg-slate-50"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-slate-900 px-4 py-2 text-xs sm:text-sm font-semibold text-white hover:bg-slate-800 shadow-sm"
                >
                  Criar Conta & Gerar Código
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CONFIRMAÇÃO DE EXCLUSÃO */}
      <ConfirmDialog
        isOpen={!!userToDelete}
        title="Eliminar Utilizador do Sistema"
        message={`Tem a certeza de que deseja eliminar definitivamente o utilizador "${userToDelete?.name}" (${userToDelete?.accessCode})? Esta ação não pode ser desfeita.`}
        confirmText="Sim, Eliminar Utilizador"
        cancelText="Cancelar"
        variant="danger"
        onConfirm={() => {
          if (userToDelete) {
            deleteUser(userToDelete.id);
            setUserToDelete(null);
          }
        }}
        onCancel={() => setUserToDelete(null)}
      />
    </div>
  );
};
