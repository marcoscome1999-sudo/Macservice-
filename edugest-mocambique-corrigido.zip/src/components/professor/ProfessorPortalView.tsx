/**
 * EduGest Moçambique - Portal do Professor
 * Ponto 4 do SNE: Visão restrita às turmas e disciplinas do docente,
 * caderneta de avaliações com regras SNE, controlo de presenças,
 * submissão de pautas e publicação de materiais escolares.
 */

import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { GradeEntry, AttendanceRecord, SchoolTask, PautaApproval } from '../../types';
import { StatusBadge } from '../common/StatusBadge';
import {
  GraduationCap,
  BookOpen,
  Calendar,
  CheckCircle,
  FileCheck,
  ClipboardList,
  Clock,
  Plus,
  Trash2,
  Lock,
  Send,
  Save,
  AlertCircle,
  Users,
  Check,
  X
} from 'lucide-react';

export const ProfessorPortalView: React.FC = () => {
  const {
    db,
    currentUser,
    currentSchool,
    batchUpdateGrades,
    saveAttendance,
    submitPautaForApproval,
    createTask,
    deleteTask
  } = useApp();

  // Localizar registo docente vinculado
  const linkedTeacher = useMemo(() => {
    return (
      db.teachers.find((t) => t.id === currentUser.linkedTeacherId) ||
      db.teachers.find((t) => t.fullName.toLowerCase().includes(currentUser.name.toLowerCase())) ||
      db.teachers[0]
    );
  }, [db.teachers, currentUser]);

  // Turmas atribuídas ao professor
  const teacherClasses = useMemo(() => {
    if (!linkedTeacher) return db.classes.slice(0, 2);
    return db.classes.filter(
      (c) =>
        c.directorTeacherId === linkedTeacher.id ||
        db.schedules.some((s) => s.teacherId === linkedTeacher.id && s.sectionId === c.id)
    );
  }, [db.classes, db.schedules, linkedTeacher]);

  const activeClasses = teacherClasses.length > 0 ? teacherClasses : db.classes.slice(0, 3);

  // Estados de navegação interna
  const [activeTabSub, setActiveTabSub] = useState<'TURMAS' | 'NOTAS' | 'PRESENCAS' | 'TAREFAS' | 'HORARIO'>('TURMAS');
  const [selectedClassId, setSelectedClassId] = useState<string>(activeClasses[0]?.id || db.classes[0]?.id || '');
  const [selectedSubjectId, setSelectedSubjectId] = useState<string>(db.subjects[0]?.id || '');
  const [selectedTerm, setSelectedTerm] = useState<1 | 2 | 3>(1);

  // Estado da Caderneta de Notas
  const selectedClass = db.classes.find((c) => c.id === selectedClassId) || activeClasses[0];
  const selectedSubject = db.subjects.find((s) => s.id === selectedSubjectId) || db.subjects[0];

  // Alunos da turma selecionada
  const classStudents = useMemo(() => {
    return db.students.filter((s) => s.currentClass === selectedClass?.name);
  }, [db.students, selectedClass]);

  // Notas editáveis na caderneta
  const [editableGrades, setEditableGrades] = useState<Record<string, { acs1: string; acs2: string; testGrade: string; workGrade: string }>>({});
  const [isSavingGrades, setIsSavingGrades] = useState(false);
  const [saveGradesSuccess, setSaveGradesSuccess] = useState(false);
  const [pautaSubmitSuccess, setPautaSubmitSuccess] = useState(false);

  // Verificar se a pauta desta turma já foi homologada
  const currentPautaStatus = useMemo(() => {
    const pauta = (db.pautaApprovals || []).find(
      (p) => p.sectionId === selectedClassId && p.term === selectedTerm
    );
    return pauta ? pauta.status : null;
  }, [db.pautaApprovals, selectedClassId, selectedTerm]);

  const isGradesLocked = currentPautaStatus === 'HOMOLOGADA';

  // Carregar notas existentes quando muda turma/disciplina/trimestre
  useMemo(() => {
    const map: Record<string, { acs1: string; acs2: string; testGrade: string; workGrade: string }> = {};
    classStudents.forEach((st) => {
      const g = db.grades.find(
        (grade) =>
          grade.studentId === st.id &&
          grade.sectionId === selectedClassId &&
          grade.subjectId === selectedSubjectId &&
          grade.term === selectedTerm
      );
      map[st.id] = {
        acs1: g?.acs1 !== null && g?.acs1 !== undefined ? String(g.acs1) : '',
        acs2: g?.acs2 !== null && g?.acs2 !== undefined ? String(g.acs2) : '',
        testGrade: g?.testGrade !== null && g?.testGrade !== undefined ? String(g.testGrade) : '',
        workGrade: g?.workGrade !== null && g?.workGrade !== undefined ? String(g.workGrade) : ''
      };
    });
    setEditableGrades(map);
  }, [classStudents, selectedClassId, selectedSubjectId, selectedTerm, db.grades]);

  // Salvar Caderneta de Notas
  const handleSaveGrades = () => {
    if (isGradesLocked) return;
    setIsSavingGrades(true);

    const entriesToUpdate: GradeEntry[] = classStudents.map((st) => {
      const studentVals = editableGrades[st.id] || { acs1: '', acs2: '', testGrade: '', workGrade: '' };
      const acs1 = studentVals.acs1 !== '' ? parseFloat(studentVals.acs1) : null;
      const acs2 = studentVals.acs2 !== '' ? parseFloat(studentVals.acs2) : null;
      const workGrade = studentVals.workGrade !== '' ? parseFloat(studentVals.workGrade) : null;
      const testGrade = studentVals.testGrade !== '' ? parseFloat(studentVals.testGrade) : null;

      // Cálculo SNE: MPT = média dos testes contínuos; MT = 0.4*MPT + 0.6*ACP
      const continuousList = [acs1, acs2, workGrade].filter((v): v is number => v !== null);
      const mpt = continuousList.length > 0 ? continuousList.reduce((a, b) => a + b, 0) / continuousList.length : null;
      let finalGrade: number | null = null;

      if (mpt !== null && testGrade !== null) {
        finalGrade = Math.round((mpt * 0.4 + testGrade * 0.6) * 10) / 10;
      } else if (mpt !== null) {
        finalGrade = Math.round(mpt * 10) / 10;
      }

      return {
        id: `grade-${st.id}-${selectedClassId}-${selectedSubjectId}-${selectedTerm}`,
        studentId: st.id,
        subjectId: selectedSubjectId,
        sectionId: selectedClassId,
        term: selectedTerm,
        academicYear: 2026,
        acs1,
        acs2,
        workGrade,
        testGrade,
        finalGrade,
        status: 'PUBLICADA',
        updatedAt: new Date().toISOString()
      };
    });

    batchUpdateGrades(entriesToUpdate);
    setIsSavingGrades(false);
    setSaveGradesSuccess(true);
    setTimeout(() => setSaveGradesSuccess(false), 3000);
  };

  // Submeter Pauta à Direção
  const handleSubmitPauta = () => {
    submitPautaForApproval({
      sectionId: selectedClassId,
      sectionName: selectedClass?.name || 'Turma',
      term: selectedTerm,
      academicYear: 2026,
      teacherId: linkedTeacher?.id || currentUser.id,
      teacherName: currentUser.name,
      totalStudents: classStudents.length,
      averageGrade: 12.8
    });
    setPautaSubmitSuccess(true);
    setTimeout(() => setPautaSubmitSuccess(false), 3500);
  };

  // Registo de Presenças de Hoje
  const [todayAttendance, setTodayAttendance] = useState<Record<string, 'PRESENTE' | 'FALTA' | 'JUSTIFICADA' | 'ATRASO'>>({});
  const [attendanceSaved, setAttendanceSaved] = useState(false);

  const handleSaveAttendance = () => {
    const today = new Date().toISOString().split('T')[0];
    saveAttendance({
      schoolId: currentSchool.id,
      date: today,
      sectionId: selectedClassId,
      subjectId: selectedSubjectId,
      teacherId: currentUser.id,
      entries: classStudents.map((st) => ({
        studentId: st.id,
        status: todayAttendance[st.id] || 'PRESENTE'
      }))
    });
    setAttendanceSaved(true);
    setTimeout(() => setAttendanceSaved(false), 3000);
  };

  // Nova Tarefa Escolar
  const [isNewTaskModalOpen, setIsNewTaskModalOpen] = useState(false);
  const [taskForm, setTaskForm] = useState({
    title: '',
    description: '',
    dueDate: new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0],
    type: 'TRABALHO' as SchoolTask['type']
  });

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!taskForm.title.trim()) return;

    createTask({
      title: taskForm.title.trim(),
      description: taskForm.description.trim(),
      subjectId: selectedSubjectId,
      subjectName: selectedSubject?.name || 'Disciplina',
      sectionId: selectedClassId,
      sectionName: selectedClass?.name || 'Turma',
      teacherId: linkedTeacher?.id || currentUser.id,
      teacherName: currentUser.name,
      dueDate: taskForm.dueDate,
      type: taskForm.type
    });

    setIsNewTaskModalOpen(false);
    setTaskForm({
      title: '',
      description: '',
      dueDate: new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0],
      type: 'TRABALHO'
    });
  };

  // Tarefas da turma
  const teacherTasks = (db.tasks || []).filter(
    (t) => t.teacherId === linkedTeacher?.id || t.sectionId === selectedClassId
  );

  return (
    <div className="space-y-6">
      {/* Cabeçalho do Professor */}
      <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-sky-50 text-sky-700 font-extrabold text-lg border border-sky-200">
              {currentUser.name.charAt(0)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg sm:text-xl font-extrabold text-slate-900">{currentUser.name}</h2>
                <span className="font-mono text-xs font-bold text-sky-800 bg-sky-50 border border-sky-200 px-2 py-0.5 rounded-md">
                  {currentUser.accessCode}
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Professor(a) • Especialidade: <strong className="text-slate-700">{linkedTeacher?.specialization || 'Ensino Geral'}</strong> • Escola: {currentSchool.name}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-500">Ano Letivo 2026</span>
          </div>
        </div>
      </div>

      {/* Navegação entre Abas do Professor */}
      <div className="flex items-center gap-2 border-b border-slate-200 overflow-x-auto pb-1 sm:pb-0">
        <button
          onClick={() => setActiveTabSub('TURMAS')}
          className={`flex items-center gap-2 border-b-2 px-4 py-2.5 text-xs sm:text-sm font-bold whitespace-nowrap transition-colors ${
            activeTabSub === 'TURMAS'
              ? 'border-sky-600 text-sky-600'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <Users className="h-4 w-4" />
          Minhas Turmas ({activeClasses.length})
        </button>

        <button
          onClick={() => setActiveTabSub('NOTAS')}
          className={`flex items-center gap-2 border-b-2 px-4 py-2.5 text-xs sm:text-sm font-bold whitespace-nowrap transition-colors ${
            activeTabSub === 'NOTAS'
              ? 'border-sky-600 text-sky-600'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <FileCheck className="h-4 w-4" />
          Caderneta de Notas SNE
        </button>

        <button
          onClick={() => setActiveTabSub('PRESENCAS')}
          className={`flex items-center gap-2 border-b-2 px-4 py-2.5 text-xs sm:text-sm font-bold whitespace-nowrap transition-colors ${
            activeTabSub === 'PRESENCAS'
              ? 'border-sky-600 text-sky-600'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <CheckCircle className="h-4 w-4" />
          Controlo de Presenças
        </button>

        <button
          onClick={() => setActiveTabSub('TAREFAS')}
          className={`flex items-center gap-2 border-b-2 px-4 py-2.5 text-xs sm:text-sm font-bold whitespace-nowrap transition-colors ${
            activeTabSub === 'TAREFAS'
              ? 'border-sky-600 text-sky-600'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <ClipboardList className="h-4 w-4" />
          Tarefas & Materiais Didáticos
        </button>

        <button
          onClick={() => setActiveTabSub('HORARIO')}
          className={`flex items-center gap-2 border-b-2 px-4 py-2.5 text-xs sm:text-sm font-bold whitespace-nowrap transition-colors ${
            activeTabSub === 'HORARIO'
              ? 'border-sky-600 text-sky-600'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <Clock className="h-4 w-4" />
          Meu Horário Semanal
        </button>
      </div>

      {/* ABA 1: MINHAS TURMAS */}
      {activeTabSub === 'TURMAS' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {activeClasses.map((cls) => {
              const studentsInClass = db.students.filter((s) => s.currentClass === cls.name);

              return (
                <div key={cls.id} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs hover:border-sky-300 transition-colors">
                  <div className="flex items-center justify-between">
                    <span className="font-extrabold text-slate-900 text-base">{cls.name}</span>
                    <span className="rounded-md bg-slate-100 text-slate-700 px-2 py-0.5 text-xs font-bold">
                      Turno: {cls.shift}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    {cls.gradeYear}ª Classe • Sala {cls.roomNumber}
                  </p>

                  <div className="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between text-xs">
                    <span className="text-slate-600 font-semibold">Total de Alunos:</span>
                    <span className="font-extrabold text-slate-900">{studentsInClass.length}</span>
                  </div>

                  <div className="mt-4 flex gap-2">
                    <button
                      onClick={() => {
                        setSelectedClassId(cls.id);
                        setActiveTabSub('NOTAS');
                      }}
                      className="flex-1 rounded-xl bg-slate-900 py-2 text-xs font-bold text-white hover:bg-slate-800 transition-colors text-center"
                    >
                      Caderneta de Notas
                    </button>
                    <button
                      onClick={() => {
                        setSelectedClassId(cls.id);
                        setActiveTabSub('PRESENCAS');
                      }}
                      className="rounded-xl border border-slate-200 px-3 py-2 text-xs font-bold text-slate-700 hover:bg-slate-50 transition-colors"
                    >
                      Presenças
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ABA 2: CADERNETA DE NOTAS */}
      {activeTabSub === 'NOTAS' && (
        <div className="space-y-4">
          {/* Seletor de Turma, Disciplina e Trimestre */}
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
            <div className="flex flex-wrap items-center gap-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-500 mb-1">Turma</label>
                <select
                  value={selectedClassId}
                  onChange={(e) => setSelectedClassId(e.target.value)}
                  className="rounded-xl border border-slate-200 bg-white px-3 py-1.5 text-xs font-bold text-slate-800 focus:border-sky-500 focus:outline-hidden"
                >
                  {activeClasses.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.gradeYear}ª Classe)
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-500 mb-1">Disciplina</label>
                <select
                  value={selectedSubjectId}
                  onChange={(e) => setSelectedSubjectId(e.target.value)}
                  className="rounded-xl border border-slate-200 bg-white px-3 py-1.5 text-xs font-bold text-slate-800 focus:border-sky-500 focus:outline-hidden"
                >
                  {db.subjects.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.code})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-500 mb-1">Trimestre</label>
                <select
                  value={selectedTerm}
                  onChange={(e) => setSelectedTerm(Number(e.target.value) as 1 | 2 | 3)}
                  className="rounded-xl border border-slate-200 bg-white px-3 py-1.5 text-xs font-bold text-slate-800 focus:border-sky-500 focus:outline-hidden"
                >
                  <option value={1}>1º Trimestre</option>
                  <option value={2}>2º Trimestre</option>
                  <option value={3}>3º Trimestre</option>
                </select>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {!isGradesLocked ? (
                <>
                  <button
                    onClick={handleSaveGrades}
                    disabled={isSavingGrades}
                    className="inline-flex items-center gap-1.5 rounded-xl bg-slate-900 px-3.5 py-2 text-xs font-bold text-white shadow-xs hover:bg-slate-800 transition-colors"
                  >
                    <Save className="h-4 w-4" />
                    Salvar Notas
                  </button>

                  <button
                    onClick={handleSubmitPauta}
                    className="inline-flex items-center gap-1.5 rounded-xl bg-sky-600 px-3.5 py-2 text-xs font-bold text-white shadow-xs hover:bg-sky-700 transition-colors"
                  >
                    <Send className="h-4 w-4" />
                    Submeter Pauta à Direção
                  </button>
                </>
              ) : (
                <span className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-800 bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded-xl">
                  <Lock className="h-3.5 w-3.5" />
                  Pauta Homologada (Edição Bloqueada)
                </span>
              )}
            </div>
          </div>

          {/* Feedback de Sucesso */}
          {saveGradesSuccess && (
            <div className="rounded-xl bg-emerald-50 border border-emerald-200 p-3 text-xs font-semibold text-emerald-800 flex items-center gap-2">
              <Check className="h-4 w-4 text-emerald-600" />
              Notas da caderneta guardadas com sucesso no sistema escolar.
            </div>
          )}

          {pautaSubmitSuccess && (
            <div className="rounded-xl bg-sky-50 border border-sky-200 p-3 text-xs font-semibold text-sky-800 flex items-center gap-2">
              <Check className="h-4 w-4 text-sky-600" />
              Pauta submetida com sucesso à Direção para homologação oficial.
            </div>
          )}

          {/* Tabela de Notas dos Alunos */}
          <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50/80 font-bold text-slate-700">
                    <th className="py-3 pl-4 pr-2">Nº</th>
                    <th className="px-3 py-3">Aluno</th>
                    <th className="px-3 py-3 text-center">ACS 1 (0-20)</th>
                    <th className="px-3 py-3 text-center">ACS 2 (0-20)</th>
                    <th className="px-3 py-3 text-center">Trabalho (0-20)</th>
                    <th className="px-3 py-3 text-center">ACP (0-20)</th>
                    <th className="px-3 py-3 text-center font-extrabold">Média MT</th>
                    <th className="py-3 pl-3 pr-4 text-center">Situação SNE</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                  {classStudents.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="p-8 text-center text-slate-400">
                        Nenhum aluno cadastrado nesta turma.
                      </td>
                    </tr>
                  ) : (
                    classStudents.map((st, index) => {
                      const grades = editableGrades[st.id] || { acs1: '', acs2: '', testGrade: '', workGrade: '' };
                      const acs1 = parseFloat(grades.acs1) || 0;
                      const acs2 = parseFloat(grades.acs2) || 0;
                      const work = parseFloat(grades.workGrade) || 0;
                      const test = parseFloat(grades.testGrade) || 0;

                      const continuousCount = [grades.acs1, grades.acs2, grades.workGrade].filter((v) => v !== '').length;
                      const mpt = continuousCount > 0 ? (acs1 + acs2 + work) / continuousCount : null;
                      const mt = mpt !== null && grades.testGrade !== '' ? Math.round((mpt * 0.4 + test * 0.6) * 10) / 10 : null;

                      const isPassed = mt !== null && mt >= 10;

                      return (
                        <tr key={st.id} className="hover:bg-slate-50/60 transition-colors">
                          <td className="py-2.5 pl-4 pr-2 font-mono text-slate-400 font-bold">{index + 1}</td>

                          <td className="px-3 py-2.5">
                            <p className="font-bold text-slate-900">{st.fullName}</p>
                            <p className="text-[10px] text-slate-500 font-mono">{st.studentNumber}</p>
                          </td>

                          {/* ACS 1 */}
                          <td className="px-3 py-2.5 text-center">
                            <input
                              type="number"
                              min="0"
                              max="20"
                              step="0.1"
                              disabled={isGradesLocked}
                              value={grades.acs1}
                              onChange={(e) =>
                                setEditableGrades({
                                  ...editableGrades,
                                  [st.id]: { ...grades, acs1: e.target.value }
                                })
                              }
                              className="w-16 text-center rounded-lg border border-slate-200 py-1 text-xs font-bold focus:border-sky-500 focus:outline-hidden disabled:bg-slate-50"
                            />
                          </td>

                          {/* ACS 2 */}
                          <td className="px-3 py-2.5 text-center">
                            <input
                              type="number"
                              min="0"
                              max="20"
                              step="0.1"
                              disabled={isGradesLocked}
                              value={grades.acs2}
                              onChange={(e) =>
                                setEditableGrades({
                                  ...editableGrades,
                                  [st.id]: { ...grades, acs2: e.target.value }
                                })
                              }
                              className="w-16 text-center rounded-lg border border-slate-200 py-1 text-xs font-bold focus:border-sky-500 focus:outline-hidden disabled:bg-slate-50"
                            />
                          </td>

                          {/* Trabalho */}
                          <td className="px-3 py-2.5 text-center">
                            <input
                              type="number"
                              min="0"
                              max="20"
                              step="0.1"
                              disabled={isGradesLocked}
                              value={grades.workGrade}
                              onChange={(e) =>
                                setEditableGrades({
                                  ...editableGrades,
                                  [st.id]: { ...grades, workGrade: e.target.value }
                                })
                              }
                              className="w-16 text-center rounded-lg border border-slate-200 py-1 text-xs font-bold focus:border-sky-500 focus:outline-hidden disabled:bg-slate-50"
                            />
                          </td>

                          {/* ACP */}
                          <td className="px-3 py-2.5 text-center">
                            <input
                              type="number"
                              min="0"
                              max="20"
                              step="0.1"
                              disabled={isGradesLocked}
                              value={grades.testGrade}
                              onChange={(e) =>
                                setEditableGrades({
                                  ...editableGrades,
                                  [st.id]: { ...grades, testGrade: e.target.value }
                                })
                              }
                              className="w-16 text-center rounded-lg border border-slate-200 py-1 text-xs font-bold focus:border-sky-500 focus:outline-hidden disabled:bg-slate-50"
                            />
                          </td>

                          {/* Média MT */}
                          <td className="px-3 py-2.5 text-center font-extrabold">
                            {mt !== null ? (
                              <span className={`text-xs ${isPassed ? 'text-emerald-700' : 'text-rose-600'}`}>
                                {mt.toFixed(1)}
                              </span>
                            ) : (
                              <span className="text-slate-300">-</span>
                            )}
                          </td>

                          {/* Situação */}
                          <td className="py-2.5 pl-3 pr-4 text-center">
                            {mt !== null ? (
                              <span
                                className={`inline-flex items-center rounded-md px-2 py-0.5 text-[10px] font-extrabold ${
                                  isPassed
                                    ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                                    : 'bg-rose-50 text-rose-700 border border-rose-200'
                                }`}
                              >
                                {isPassed ? 'Apto / Positiva' : 'Não Apto'}
                              </span>
                            ) : (
                              <span className="text-slate-400 text-[10px]">Em curso</span>
                            )}
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ABA 3: CONTROLO DE PRESENÇAS */}
      {activeTabSub === 'PRESENCAS' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
            <div>
              <h3 className="font-extrabold text-slate-900 text-sm">Registo de Faltas e Presenças da Aula</h3>
              <p className="text-xs text-slate-500">
                Turma: <strong>{selectedClass?.name}</strong> • Data: <strong>{new Date().toLocaleDateString('pt-MZ')}</strong>
              </p>
            </div>

            <button
              onClick={handleSaveAttendance}
              className="inline-flex items-center gap-1.5 rounded-xl bg-slate-900 px-4 py-2 text-xs font-bold text-white hover:bg-slate-800 shadow-xs"
            >
              <Save className="h-4 w-4" />
              Registar Assiduidade
            </button>
          </div>

          {attendanceSaved && (
            <div className="rounded-xl bg-emerald-50 border border-emerald-200 p-3 text-xs font-semibold text-emerald-800 flex items-center gap-2">
              <Check className="h-4 w-4 text-emerald-600" />
              Presenças da turma registadas com sucesso no histórico da escola.
            </div>
          )}

          <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xs">
            <table className="w-full border-collapse text-left text-xs sm:text-sm">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/80 font-bold text-slate-700">
                  <th className="py-3 pl-4 pr-3">Aluno</th>
                  <th className="px-3 py-3 text-center">Estado da Presença</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                {classStudents.map((st) => {
                  const currentStatus = todayAttendance[st.id] || 'PRESENTE';

                  return (
                    <tr key={st.id} className="hover:bg-slate-50/60">
                      <td className="py-2.5 pl-4 pr-3">
                        <p className="font-bold text-slate-900">{st.fullName}</p>
                        <p className="text-[10px] text-slate-500">{st.studentNumber}</p>
                      </td>
                      <td className="px-3 py-2.5 text-center">
                        <div className="inline-flex items-center gap-2">
                          <button
                            onClick={() => setTodayAttendance({ ...todayAttendance, [st.id]: 'PRESENTE' })}
                            className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
                              currentStatus === 'PRESENTE'
                                ? 'bg-emerald-600 text-white'
                                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                            }`}
                          >
                            Presente
                          </button>
                          <button
                            onClick={() => setTodayAttendance({ ...todayAttendance, [st.id]: 'FALTA_INJUSTIFICADA' })}
                            className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
                              currentStatus === 'FALTA_INJUSTIFICADA'
                                ? 'bg-rose-600 text-white'
                                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                            }`}
                          >
                            Falta
                          </button>
                          <button
                            onClick={() => setTodayAttendance({ ...todayAttendance, [st.id]: 'FALTA_JUSTIFICADA' })}
                            className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
                              currentStatus === 'FALTA_JUSTIFICADA'
                                ? 'bg-amber-600 text-white'
                                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                            }`}
                          >
                            Justificada
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ABA 4: TAREFAS E MATERIAIS */}
      {activeTabSub === 'TAREFAS' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-extrabold text-slate-900 text-sm sm:text-base">
              Tarefas, TPCs e Materiais Didáticos
            </h3>
            <button
              onClick={() => setIsNewTaskModalOpen(true)}
              className="inline-flex items-center gap-1.5 rounded-xl bg-slate-900 px-3.5 py-2 text-xs font-bold text-white hover:bg-slate-800 shadow-xs"
            >
              <Plus className="h-4 w-4 text-sky-400" />
              Publicar Nova Tarefa
            </button>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {teacherTasks.length === 0 ? (
              <div className="col-span-full rounded-2xl border border-dashed border-slate-200 p-8 text-center text-slate-400">
                Nenhuma tarefa ou material publicado para esta turma.
              </div>
            ) : (
              teacherTasks.map((t) => (
                <div key={t.id} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="rounded-md bg-sky-50 text-sky-800 border border-sky-200 px-2 py-0.5 text-[10px] font-bold">
                      {t.type}
                    </span>
                    <button
                      onClick={() => deleteTask(t.id)}
                      className="text-slate-400 hover:text-rose-600 transition-colors p-1"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>

                  <h4 className="font-bold text-slate-900 text-sm">{t.title}</h4>
                  <p className="text-xs text-slate-600 line-clamp-3">{t.description}</p>

                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                    <span>Turma: {t.sectionName}</span>
                    <span className="font-bold text-amber-700">Prazo: {t.dueDate}</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* ABA 5: MEU HORÁRIO SEMANAL */}
      {activeTabSub === 'HORARIO' && (
        <div className="space-y-4">
          <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xs">
            <div className="p-4 border-b border-slate-200 font-extrabold text-slate-900 text-sm">
              Horário Semanal de Aulas do Professor
            </div>
            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50/80 font-bold text-slate-700">
                    <th className="py-3 pl-4 pr-2">Horário</th>
                    <th className="px-3 py-3">Segunda-feira</th>
                    <th className="px-3 py-3">Terça-feira</th>
                    <th className="px-3 py-3">Quarta-feira</th>
                    <th className="px-3 py-3">Quinta-feira</th>
                    <th className="py-3 pl-3 pr-4">Sexta-feira</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                  {['07:30 - 08:15', '08:20 - 09:05', '09:20 - 10:05', '10:10 - 10:55', '11:10 - 11:55'].map(
                    (slotTime, idx) => (
                      <tr key={slotTime} className="hover:bg-slate-50/60">
                        <td className="py-3 pl-4 pr-2 font-mono font-bold text-slate-500">{slotTime}</td>
                        <td className="px-3 py-3">
                          {idx % 2 === 0 ? (
                            <div className="rounded-lg bg-sky-50 border border-sky-200 p-2">
                              <p className="font-bold text-sky-900">Matemática</p>
                              <p className="text-[10px] text-sky-700">Turma 10ª A • Sala 04</p>
                            </div>
                          ) : (
                            <span className="text-slate-300">-</span>
                          )}
                        </td>
                        <td className="px-3 py-3">
                          {idx === 1 || idx === 3 ? (
                            <div className="rounded-lg bg-indigo-50 border border-indigo-200 p-2">
                              <p className="font-bold text-indigo-900">Física</p>
                              <p className="text-[10px] text-indigo-700">Turma 10ª B • Sala 02</p>
                            </div>
                          ) : (
                            <span className="text-slate-300">-</span>
                          )}
                        </td>
                        <td className="px-3 py-3">
                          {idx === 0 || idx === 2 ? (
                            <div className="rounded-lg bg-sky-50 border border-sky-200 p-2">
                              <p className="font-bold text-sky-900">Matemática</p>
                              <p className="text-[10px] text-sky-700">Turma 10ª A • Sala 04</p>
                            </div>
                          ) : (
                            <span className="text-slate-300">-</span>
                          )}
                        </td>
                        <td className="px-3 py-3">
                          {idx === 2 ? (
                            <div className="rounded-lg bg-indigo-50 border border-indigo-200 p-2">
                              <p className="font-bold text-indigo-900">Física</p>
                              <p className="text-[10px] text-indigo-700">Turma 10ª B • Sala 02</p>
                            </div>
                          ) : (
                            <span className="text-slate-300">-</span>
                          )}
                        </td>
                        <td className="py-3 pl-3 pr-4">
                          {idx === 4 ? (
                            <div className="rounded-lg bg-amber-50 border border-amber-200 p-2">
                              <p className="font-bold text-amber-900">Apoio Pedagógico</p>
                              <p className="text-[10px] text-amber-700">Biblioteca</p>
                            </div>
                          ) : (
                            <span className="text-slate-300">-</span>
                          )}
                        </td>
                      </tr>
                    )
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: CRIAR TAREFA */}
      {isNewTaskModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
          <div className="relative w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-4">
              <h3 className="font-extrabold text-slate-900 text-base">Publicar Tarefa Escolar</h3>
              <button onClick={() => setIsNewTaskModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateTask} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Título da Tarefa *</label>
                <input
                  type="text"
                  required
                  placeholder="ex: Ficha de Exercícios de Equações Quadráticas"
                  value={taskForm.title}
                  onChange={(e) => setTaskForm({ ...taskForm, title: e.target.value })}
                  className="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-sky-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Tipo de Atividade *</label>
                <select
                  value={taskForm.type}
                  onChange={(e) => setTaskForm({ ...taskForm, type: e.target.value as any })}
                  className="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs font-semibold focus:border-sky-500 focus:outline-hidden"
                >
                  <option value="TRABALHO">Trabalho Individual / Grupo</option>
                  <option value="TPC">Trabalho Para Casa (TPC)</option>
                  <option value="EXERCICIO">Ficha de Exercícios</option>
                  <option value="MATERIAL">Material de Apoio / Ficha Teórica</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Data Limite de Entrega *</label>
                <input
                  type="date"
                  required
                  value={taskForm.dueDate}
                  onChange={(e) => setTaskForm({ ...taskForm, dueDate: e.target.value })}
                  className="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-sky-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Orientações aos Alunos *</label>
                <textarea
                  required
                  rows={3}
                  placeholder="Descreva as páginas do livro, critérios de avaliação ou orientações de resolução..."
                  value={taskForm.description}
                  onChange={(e) => setTaskForm({ ...taskForm, description: e.target.value })}
                  className="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-sky-500 focus:outline-hidden"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsNewTaskModalOpen(false)}
                  className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-50"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-slate-900 px-4 py-2 text-xs font-bold text-white hover:bg-slate-800 shadow-xs"
                >
                  Publicar Tarefa
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
