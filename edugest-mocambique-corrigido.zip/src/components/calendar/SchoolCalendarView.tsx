/**
 * EduGest Moçambique - Calendário Escolar Oficial (SNE 2026)
 * Ponto 16 do SNE: Prazos oficiais, trimestres letivos, exames nacionais,
 * interrupções letivas, reuniões de pais e feriados nacionais de Moçambique.
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Calendar as CalendarIcon,
  Flag,
  BookOpen,
  Award,
  Users,
  Clock,
  Sparkles,
  CheckCircle2,
  ChevronRight,
  Filter
} from 'lucide-react';

interface CalendarEvent {
  id: string;
  title: string;
  dateRange: string;
  category: 'FERIADO' | 'TRIMESTRE' | 'EXAME' | 'AVALIACAO' | 'REUNIAO' | 'FERIAS';
  description: string;
  status: 'CONCLUIDO' | 'ACTUAL' | 'FUTURO';
}

const MOZAMBIQUE_CALENDAR_2026: CalendarEvent[] = [
  {
    id: 'cal-1',
    title: 'Abertura Solene do Ano Letivo 2026',
    dateRange: '02 de Fevereiro de 2026',
    category: 'TRIMESTRE',
    description: 'Início oficial das atividades letivas em todo o território nacional.',
    status: 'CONCLUIDO'
  },
  {
    id: 'cal-2',
    title: 'Feriado Nacional: Dia dos Heróis Moçambicanos',
    dateRange: '03 de Fevereiro de 2026',
    category: 'FERIADO',
    description: 'Homenagem aos combatentes e heróis da pátria moçambicana.',
    status: 'CONCLUIDO'
  },
  {
    id: 'cal-3',
    title: '1º Período de Avaliações Contínuas (ACS 1)',
    dateRange: '02 a 13 de Março de 2026',
    category: 'AVALIACAO',
    description: 'Primeira ronda de testes e trabalhos contínuos em todas as disciplinas.',
    status: 'ACTUAL'
  },
  {
    id: 'cal-4',
    title: 'Feriado Nacional: Dia da Mulher Moçambicana',
    dateRange: '07 de Abril de 2026',
    category: 'FERIADO',
    description: 'Celebração em memória de Josina Machel e da mulher moçambicana.',
    status: 'FUTURO'
  },
  {
    id: 'cal-5',
    title: 'Realização das ACPs do 1º Trimestre',
    dateRange: '20 a 30 de Abril de 2026',
    category: 'AVALIACAO',
    description: 'Avaliações de Controlo Parcial (provas trimestrais do 1º Trimestre).',
    status: 'FUTURO'
  },
  {
    id: 'cal-6',
    title: 'Feriado Nacional: Dia Internacional dos Trabalhadores',
    dateRange: '01 de Maio de 2026',
    category: 'FERIADO',
    description: 'Feriado público e descanso dos servidores e trabalhadores da educação.',
    status: 'FUTURO'
  },
  {
    id: 'cal-7',
    title: 'Fecho do 1º Trimestre & Homologação das Pautas',
    dateRange: '08 de Maio de 2026',
    category: 'TRIMESTRE',
    description: 'Submissão e homologação digital das pautas pela Direção da escola.',
    status: 'FUTURO'
  },
  {
    id: 'cal-8',
    title: 'Interrupção Letiva (Férias do 1º Trimestre)',
    dateRange: '11 a 15 de Maio de 2026',
    category: 'FERIAS',
    description: 'Interrupção letiva para alunos e capacitação pedagógica docente.',
    status: 'FUTURO'
  },
  {
    id: 'cal-9',
    title: 'Início do 2º Trimestre Letivo',
    dateRange: '18 de Maio de 2026',
    category: 'TRIMESTRE',
    description: 'Retomada oficial das aulas para o segundo trimestre do ano.',
    status: 'FUTURO'
  },
  {
    id: 'cal-10',
    title: 'Feriado Nacional: 51º Aniversário da Independência Nacional',
    dateRange: '25 de Junho de 2026',
    category: 'FERIADO',
    description: 'Celebração do Dia da Independência e Proclamação da República de Moçambique.',
    status: 'FUTURO'
  },
  {
    id: 'cal-11',
    title: 'Feriado Nacional: Dia dos Acordos de Lusaka (Dia da Vitória)',
    dateRange: '07 de Setembro de 2026',
    category: 'FERIADO',
    description: 'Homenagem à assinatura dos acordos que antecederam a independência.',
    status: 'FUTURO'
  },
  {
    id: 'cal-12',
    title: 'Feriado Nacional: Dia das Forças Armadas (FADM)',
    dateRange: '25 de Setembro de 2026',
    category: 'FERIADO',
    description: 'Comemoração das Forças Armadas de Defesa de Moçambique.',
    status: 'FUTURO'
  },
  {
    id: 'cal-13',
    title: 'Feriado Nacional: Dia da Paz e Reconciliação Nacional',
    dateRange: '04 de Outubro de 2026',
    category: 'FERIADO',
    description: 'Celebração da paz estabelecida pelo Acordo Geral de Roma de 1992.',
    status: 'FUTURO'
  },
  {
    id: 'cal-14',
    title: 'Exames Nacionais do MINEDH (10ª e 12ª Classes)',
    dateRange: '16 a 27 de Novembro de 2026',
    category: 'EXAME',
    description: 'Exames finais nacionais centralizados pelo Ministério da Educação.',
    status: 'FUTURO'
  },
  {
    id: 'cal-15',
    title: 'Encerramento Oficial do Ano Letivo 2026',
    dateRange: '11 de Dezembro de 2026',
    category: 'TRIMESTRE',
    description: 'Divulgação das pautas finais, emissão de certificados e matrículas para 2027.',
    status: 'FUTURO'
  }
];

export const SchoolCalendarView: React.FC = () => {
  const { currentSchool } = useApp();
  const [filterCategory, setFilterCategory] = useState<string>('TODOS');

  const filteredEvents = MOZAMBIQUE_CALENDAR_2026.filter(
    (e) => filterCategory === 'TODOS' || e.category === filterCategory
  );

  const getBadgeColor = (category: CalendarEvent['category']) => {
    switch (category) {
      case 'FERIADO':
        return 'bg-rose-50 text-rose-800 border-rose-200';
      case 'TRIMESTRE':
        return 'bg-sky-50 text-sky-800 border-sky-200';
      case 'EXAME':
        return 'bg-purple-50 text-purple-800 border-purple-200';
      case 'AVALIACAO':
        return 'bg-amber-50 text-amber-800 border-amber-200';
      case 'FERIAS':
        return 'bg-emerald-50 text-emerald-800 border-emerald-200';
      default:
        return 'bg-slate-50 text-slate-700 border-slate-200';
    }
  };

  return (
    <div className="space-y-6">
      {/* Cabeçalho */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
            <CalendarIcon className="h-6 w-6 text-sky-600" />
            Calendário Escolar Oficial (SNE Moçambique 2026)
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Diretrizes homologadas pelo MINEDH • Escola: <strong className="text-slate-700">{currentSchool.name}</strong>
          </p>
        </div>

        {/* Filtro por Categoria */}
        <div className="flex items-center gap-2">
          <Filter className="h-4 w-4 text-slate-400" />
          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 focus:border-sky-500 focus:outline-hidden"
          >
            <option value="TODOS">Todos os Eventos</option>
            <option value="FERIADO">Feriados Nacionais</option>
            <option value="TRIMESTRE">Trimestres & Abertura</option>
            <option value="AVALIACAO">Provas & Avaliações</option>
            <option value="EXAME">Exames Nacionais</option>
            <option value="FERIAS">Interrupções Letivas</option>
          </select>
        </div>
      </div>

      {/* Cartões dos 3 Trimestres */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <div className="rounded-2xl border border-sky-300 bg-sky-50/60 p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-extrabold text-sky-800 uppercase tracking-wider">1º Trimestre</span>
            <span className="rounded-full bg-sky-200 px-2 py-0.5 text-[10px] font-bold text-sky-900">Em Curso</span>
          </div>
          <p className="mt-2 text-base font-extrabold text-slate-900">02 Fev a 08 Mai 2026</p>
          <p className="text-xs text-slate-600 mt-1">14 Semanas Letivas • ACS1, ACS2 e ACP</p>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-extrabold text-slate-500 uppercase tracking-wider">2º Trimestre</span>
            <span className="rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-bold text-slate-600">Previsto</span>
          </div>
          <p className="mt-2 text-base font-extrabold text-slate-900">18 Mai a 21 Ago 2026</p>
          <p className="text-xs text-slate-600 mt-1">14 Semanas Letivas • Provas Trimestrais</p>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-extrabold text-slate-500 uppercase tracking-wider">3º Trimestre & Exames</span>
            <span className="rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-bold text-slate-600">Previsto</span>
          </div>
          <p className="mt-2 text-base font-extrabold text-slate-900">31 Ago a 11 Dez 2026</p>
          <p className="text-xs text-slate-600 mt-1">15 Semanas • Exames Nacionais e Pautas Finais</p>
        </div>
      </div>

      {/* Lista Cronológica de Eventos e Feriados */}
      <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
        <h3 className="font-extrabold text-slate-900 text-base mb-4">
          Cronograma Detalhado & Feriados Nacionais
        </h3>

        <div className="divide-y divide-slate-100">
          {filteredEvents.map((evt) => (
            <div key={evt.id} className="py-3.5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 hover:bg-slate-50/60 transition-colors px-2 rounded-xl">
              <div className="flex items-start gap-3">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-slate-100 font-bold text-slate-700">
                  {evt.category === 'FERIADO' ? (
                    <Flag className="h-4 w-4 text-rose-600" />
                  ) : evt.category === 'EXAME' ? (
                    <Award className="h-4 w-4 text-purple-600" />
                  ) : (
                    <BookOpen className="h-4 w-4 text-sky-600" />
                  )}
                </div>
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <h4 className="font-bold text-slate-900 text-sm">{evt.title}</h4>
                    <span className={`rounded-md border px-2 py-0.5 text-[10px] font-bold ${getBadgeColor(evt.category)}`}>
                      {evt.category}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">{evt.description}</p>
                </div>
              </div>

              <div className="sm:text-right shrink-0">
                <span className="font-mono text-xs font-bold text-slate-800 bg-slate-50 border border-slate-200 px-2.5 py-1 rounded-lg">
                  {evt.dateRange}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
