/**
 * EduGest Moçambique - Validador Público de Autenticidade de Documentos (QR)
 * Permite a qualquer entidade (empregadores, universidades, embaixadas, governos provinciais)
 * verificar em tempo real se um documento emitido no território moçambicano é autêntico e inalterado.
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { DocumentRecord } from '../../types';
import {
  ShieldCheck,
  Search,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  QrCode,
  FileText,
  School,
  Calendar,
  Lock
} from 'lucide-react';

export const PublicValidatorView: React.FC = () => {
  const { findDocumentByCode, db } = useApp();

  const [inputCode, setInputCode] = useState('');
  const [searched, setSearched] = useState(false);
  const [resultDoc, setResultDoc] = useState<DocumentRecord | null>(null);

  const handleValidate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputCode.trim()) return;

    const found = findDocumentByCode(inputCode.trim());
    setResultDoc(found);
    setSearched(true);
  };

  const sampleCodes = (db.documents || []).slice(0, 3).map((d) => d.securityHash);

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Banner Superior */}
      <div className="text-center space-y-2">
        <div className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-sky-100 text-sky-700 shadow-xs mb-2">
          <ShieldCheck className="h-8 w-8" />
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          Portal Público de Validação de Documentos Escolares
        </h2>
        <p className="text-xs sm:text-sm text-slate-600 max-w-lg mx-auto">
          Verifique a autenticidade e validade de certificados, declarações de matrícula e notas emitidos pelas instituições do Sistema Nacional de Educação (SNE).
        </p>
      </div>

      {/* Caixa de Entrada do Código */}
      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-md">
        <form onSubmit={handleValidate} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Insira o Código de Validação Único ou Número do Documento:
            </label>
            <div className="relative">
              <QrCode className="absolute left-3.5 top-3 h-5 w-5 text-slate-400" />
              <input
                type="text"
                required
                value={inputCode}
                onChange={(e) => setInputCode(e.target.value)}
                placeholder="Ex: MZ7B92A1421 ou DOC-MZ-2026-1049"
                className="w-full rounded-xl border border-slate-300 py-2.5 pl-11 pr-4 text-sm font-mono uppercase font-bold text-slate-900 placeholder-slate-400 focus:border-sky-500 focus:outline-none focus:ring-2 focus:ring-sky-100"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full rounded-xl bg-sky-600 py-3 text-xs font-extrabold text-white uppercase tracking-wider hover:bg-sky-700 shadow-sm transition flex items-center justify-center gap-2"
          >
            <Search className="h-4 w-4" />
            Validar Autenticidade do Documento
          </button>
        </form>

        {/* Sugestões de Teste Rápido */}
        <div className="mt-4 pt-4 border-t border-slate-100 text-xs text-slate-500">
          <span className="font-semibold block mb-1">Códigos de Exemplo emitidos no sistema:</span>
          <div className="flex flex-wrap gap-1.5">
            {sampleCodes.map((code) => (
              <button
                key={code}
                type="button"
                onClick={() => {
                  setInputCode(code);
                  const found = findDocumentByCode(code);
                  setResultDoc(found);
                  setSearched(true);
                }}
                className="rounded-lg bg-slate-100 px-2 py-1 font-mono text-xs font-bold text-sky-700 hover:bg-sky-50 transition"
              >
                {code}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Resultado da Validação */}
      {searched && (
        <div>
          {resultDoc ? (
            <div className="rounded-2xl border border-emerald-200 bg-emerald-50/50 p-6 shadow-md space-y-4">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-600 text-white font-bold">
                  <CheckCircle2 className="h-6 w-6" />
                </div>
                <div>
                  <h4 className="text-base font-extrabold text-emerald-950">
                    DOCUMENTO OFICIAL VÁLIDO E AUTÊNTICO
                  </h4>
                  <p className="text-xs text-emerald-800">
                    Emitido conforme as directrizes do Ministério da Educação e Desenvolvimento Humano (MINEDH).
                  </p>
                </div>
              </div>

              <div className="rounded-xl border border-emerald-200 bg-white p-4 space-y-2 text-xs text-slate-700">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <p><strong>Tipo de Documento:</strong> {resultDoc.type.replace('_', ' ')}</p>
                  <p><strong>Nº do Registo:</strong> <span className="font-mono font-bold text-sky-700">{resultDoc.documentNumber}</span></p>
                  <p><strong>Aluno Beneficiário:</strong> {resultDoc.studentName}</p>
                  <p><strong>Classe / Turma:</strong> {resultDoc.gradeLevel} - {resultDoc.sectionName}</p>
                  <p><strong>Ano Lectivo:</strong> {resultDoc.academicYear}</p>
                  <p><strong>Data de Emissão:</strong> {resultDoc.issueDate}</p>
                  <p><strong>Secretaria Emissora:</strong> {resultDoc.issuedBy}</p>
                  <p><strong>Código de Segurança:</strong> <span className="font-mono font-bold text-emerald-800">{resultDoc.securityHash}</span></p>
                </div>

                <div className="mt-2 pt-2 border-t border-slate-100 text-[11px] text-slate-500">
                  <strong>Finalidade Declarada:</strong> {resultDoc.details}
                </div>
              </div>

              <div className="flex items-center gap-2 text-[11px] font-semibold text-emerald-800">
                <Lock className="h-3.5 w-3.5 text-emerald-600" />
                Registo assinado digitalmente pelo sistema EduGest Moçambique.
              </div>
            </div>
          ) : (
            <div className="rounded-2xl border border-rose-200 bg-rose-50/60 p-6 shadow-md text-center space-y-2">
              <XCircle className="h-10 w-10 text-rose-600 mx-auto" />
              <h4 className="text-base font-extrabold text-rose-950">
                DOCUMENTO NÃO ENCONTRADO OU INVÁLIDO
              </h4>
              <p className="text-xs text-rose-800 max-w-md mx-auto">
                Não foi localizado nenhum registo oficial com o código fornecido. Verifique se digitou correctamente o código alfanumérico ou contacte a secretaria da escola.
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
