/**
 * EduGest Moçambique - Emissão de Documentos Oficiais (DocumentsView)
 * Declaração de Matrícula, Declaração com Notas, Sem Notas, Certificados,
 * Guia de Transferência, Cartão de Estudante.
 * Elementos oficiais do SNE: Código de segurança único, QR Code para validação pública,
 * Carimbo oficial e layout imprimível da República de Moçambique.
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { DocumentRecord } from '../../types';
import {
  FileCheck,
  Plus,
  Search,
  Printer,
  ShieldCheck,
  QrCode,
  CheckCircle2,
  Download,
  X
} from 'lucide-react';

export const DocumentsView: React.FC = () => {
  const { db, currentSchool, currentUser, generateDocument, setActiveTab } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState('ALL');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [previewDoc, setPreviewDoc] = useState<DocumentRecord | null>(null);

  const [formData, setFormData] = useState<{
    studentId: string;
    type: DocumentRecord['type'];
    purpose: string;
  }>({
    studentId: db.students[0]?.id || 'std-1',
    type: 'DECLARACAO_MATRICULA',
    purpose: 'Para efeitos de apresentação no local de trabalho do encarregado de educação.'
  });

  const filteredDocs = db.documents.filter((doc) => {
    const matchSearch =
      doc.studentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      doc.documentNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      doc.securityHash.toLowerCase().includes(searchTerm.toLowerCase());

    const matchType = selectedType === 'ALL' || doc.type === selectedType;

    return matchSearch && matchType;
  });

  const handleCreateDocument = (e: React.FormEvent) => {
    e.preventDefault();
    const student = db.students.find((s) => s.id === formData.studentId);
    if (!student) return;

    const newDoc = generateDocument({
      schoolId: currentSchool.id,
      type: formData.type,
      studentId: student.id,
      studentName: student.fullName,
      gradeLevel: student.currentClass,
      sectionName: student.currentSection,
      academicYear: 2026,
      issuedBy: currentUser.name,
      details: formData.purpose
    });

    setIsModalOpen(false);
    setPreviewDoc(newDoc);
  };

  return (
    <div className="space-y-6">
      {/* Cabeçalho */}
      <div className="no-print flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
            <FileCheck className="h-6 w-6 text-sky-600" />
            Emissão de Documentos Oficiais & Certificados
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Declarações, guias de transferência e certificados com código de segurança e validação QR pública.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-1.5 rounded-xl bg-sky-600 px-3.5 py-2 text-xs font-bold text-white shadow-sm hover:bg-sky-700 transition"
        >
          <Plus className="h-4 w-4" />
          Emitir Novo Documento
        </button>
      </div>

      {/* Filtros */}
      <div className="no-print flex flex-col sm:flex-row sm:items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Pesquisar por aluno, nº do documento ou código hash..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full rounded-xl border border-slate-200 py-2 pl-9 pr-4 text-xs text-slate-800 placeholder-slate-400 focus:border-sky-500 focus:outline-none"
          />
        </div>

        <select
          value={selectedType}
          onChange={(e) => setSelectedType(e.target.value)}
          className="rounded-xl border border-slate-200 bg-slate-50 py-2 px-3 text-xs font-semibold text-slate-700 focus:border-sky-500 focus:outline-none"
        >
          <option value="ALL">Todos os Tipos</option>
          <option value="DECLARACAO_MATRICULA">Declaração de Matrícula</option>
          <option value="DECLARACAO_COM_NOTAS">Declaração com Notas</option>
          <option value="DECLARACAO_SEM_NOTAS">Declaração sem Notas</option>
          <option value="CERTIFICADO_HABILITACOES">Certificado de Habilitações</option>
          <option value="GUIA_TRANSFERENCIA">Guia de Transferência</option>
          <option value="COMPROVATIVO_MATRICULA">Comprovativo de Matrícula</option>
          <option value="CARTAO_ESTUDANTE">Cartão de Estudante</option>
        </select>
      </div>

      {/* Tabela de Documentos Emitidos */}
      <div className="no-print overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600">
            <thead className="border-b border-slate-200 bg-slate-50 font-bold uppercase tracking-wider text-slate-500">
              <tr>
                <th className="py-3 px-4">Nº do Documento</th>
                <th className="py-3 px-4">Tipo de Documento</th>
                <th className="py-3 px-4">Aluno Beneficiário</th>
                <th className="py-3 px-4">Classe & Turma</th>
                <th className="py-3 px-4">Hash de Validação</th>
                <th className="py-3 px-4">Data Emissão</th>
                <th className="py-3 px-4">Estado</th>
                <th className="py-3 px-4 text-center">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredDocs.map((doc) => (
                <tr key={doc.id} className="hover:bg-slate-50/80 transition">
                  <td className="py-3 px-4 font-mono font-bold text-sky-700">
                    {doc.documentNumber}
                  </td>
                  <td className="py-3 px-4 font-bold text-slate-900">
                    {doc.type.replace('_', ' ')}
                  </td>
                  <td className="py-3 px-4 font-medium text-slate-800">
                    {doc.studentName}
                  </td>
                  <td className="py-3 px-4 text-slate-600">
                    {doc.gradeLevel} - {doc.sectionName}
                  </td>
                  <td className="py-3 px-4 font-mono text-[11px] text-emerald-700 font-bold">
                    {doc.securityHash}
                  </td>
                  <td className="py-3 px-4 text-slate-500">
                    {doc.issueDate}
                  </td>
                  <td className="py-3 px-4">
                    <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-bold text-emerald-800">
                      {doc.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-center">
                    <div className="flex items-center justify-center gap-2">
                      <button
                        onClick={() => setPreviewDoc(doc)}
                        className="rounded-lg bg-sky-50 px-2.5 py-1 text-xs font-bold text-sky-700 hover:bg-sky-100 transition flex items-center gap-1"
                      >
                        <Printer className="h-3.5 w-3.5" />
                        Visualizar / Imprimir
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL DE EMISSÃO DE NOVO DOCUMENTO */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
          <div className="relative w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-4">
              <h3 className="font-extrabold text-slate-900 text-base flex items-center gap-2">
                <FileCheck className="h-5 w-5 text-sky-600" />
                Emitir Documento Escolar Oficial
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleCreateDocument} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Aluno Solicitante *</label>
                <select
                  value={formData.studentId}
                  onChange={(e) => setFormData({ ...formData, studentId: e.target.value })}
                  className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-sky-500 focus:outline-none"
                >
                  {db.students.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.fullName} ({s.studentNumber} - {s.currentClass})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Tipo de Documento *</label>
                <select
                  value={formData.type}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value as any })}
                  className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-sky-500 focus:outline-none"
                >
                  <option value="DECLARACAO_MATRICULA">Declaração de Matrícula</option>
                  <option value="DECLARACAO_COM_NOTAS">Declaração com Notas</option>
                  <option value="DECLARACAO_SEM_NOTAS">Declaração sem Notas</option>
                  <option value="CERTIFICADO_HABILITACOES">Certificado de Habilitações</option>
                  <option value="COMPROVATIVO_MATRICULA">Comprovativo de Matrícula</option>
                  <option value="CARTAO_ESTUDANTE">Cartão de Estudante</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Finalidade / Observações</label>
                <textarea
                  rows={3}
                  value={formData.purpose}
                  onChange={(e) => setFormData({ ...formData, purpose: e.target.value })}
                  className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-sky-500 focus:outline-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-4 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="rounded-xl bg-slate-100 px-4 py-2 font-bold text-slate-700 hover:bg-slate-200 text-xs"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-sky-600 px-5 py-2 font-bold text-white hover:bg-sky-700 text-xs shadow-sm"
                >
                  Gerar Documento com QR Code
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL / VISUALIZADOR DE DOCUMENTO OFICIAL MINEDH COM QR   */}
      {/* ========================================================= */}
      {previewDoc && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 p-4 backdrop-blur-xs overflow-y-auto">
          <div className="relative w-full max-w-2xl rounded-2xl bg-white shadow-2xl p-8 my-8 print:border-none print:shadow-none print:m-0 print:p-6">
            {/* Cabeçalho Nacional Oficial */}
            <div className="text-center border-b-2 border-slate-900 pb-4 mb-6">
              <div className="flex justify-center items-center gap-3 mb-1">
                <div className="h-14 w-14 rounded-full border-2 border-slate-900 p-1 flex items-center justify-center font-black text-xs text-slate-900">
                  REP. MZ
                </div>
                <div>
                  <h1 className="text-base font-extrabold uppercase tracking-wider text-slate-900">
                    REPÚBLICA DE MOÇAMBIQUE
                  </h1>
                  <h2 className="text-xs font-bold uppercase tracking-wide text-slate-700">
                    MINISTÉRIO DA EDUCAÇÃO E DESENVOLVIMENTO HUMANO
                  </h2>
                  <h3 className="text-[11px] font-semibold text-slate-600">
                    Direcção Provincial de Educação • {currentSchool.province}
                  </h3>
                </div>
              </div>

              <div className="mt-4 rounded-lg bg-slate-50 py-1.5 border border-slate-200">
                <h4 className="text-sm font-extrabold text-slate-900 uppercase">
                  {currentSchool.name}
                </h4>
                <p className="text-[10px] text-slate-500 font-mono">
                  NUIT: {currentSchool.nuit} • {currentSchool.address} • Tel: {currentSchool.phone}
                </p>
              </div>
            </div>

            {/* Título do Documento */}
            <div className="text-center my-6">
              <h3 className="text-lg font-black uppercase tracking-widest text-slate-900 border-b-2 border-slate-300 inline-block pb-1">
                {previewDoc.type.replace('_', ' ')}
              </h3>
              <p className="text-xs font-mono font-bold text-sky-800 mt-1">
                Nº Registo: {previewDoc.documentNumber}
              </p>
            </div>

            {/* Corpo do Texto Formal */}
            <div className="space-y-4 text-xs leading-relaxed text-slate-800 text-justify px-2">
              <p>
                Para os devidos efeitos e a pedido do interessado, certifica-se que{' '}
                <strong>{previewDoc.studentName}</strong>, encontrando-se devidamente matriculado(a) nesta instituição de ensino no Ano Lectivo de <strong>{previewDoc.academicYear}</strong>, frequenta presentemente a{' '}
                <strong>{previewDoc.gradeLevel}</strong>, na{' '}
                <strong>{previewDoc.sectionName}</strong>, sob o processo individual nº{' '}
                <strong>{previewDoc.studentId}</strong>.
              </p>

              <p>
                O presente documento é emitido em conformidade com o Regulamento Geral do Sistema Nacional de Educação (SNE) e destina-se expressamente a:{' '}
                <em>{previewDoc.details || 'Fins oficiais requeridos pelo encarregado de educação.'}</em>
              </p>

              <p>
                Por ser verdade e ter sido solicitado, passa-se a presente declaração que vai por mim assinada e autenticada com o carimbo a óleo em uso nesta instituição.
              </p>
            </div>

            {/* Rodapé Oficial: Data, Assinatura e QR Code */}
            <div className="mt-10 pt-6 border-t border-slate-300 flex items-end justify-between">
              {/* Bloco do QR Code e Código de Segurança */}
              <div className="flex items-center gap-3">
                <div className="h-20 w-20 border-2 border-slate-900 p-1.5 rounded-lg flex flex-col items-center justify-center bg-slate-50">
                  <QrCode className="h-12 w-12 text-slate-900" />
                  <span className="text-[8px] font-bold uppercase tracking-tighter">Validação QR</span>
                </div>
                <div>
                  <span className="text-[10px] font-bold text-slate-500 uppercase block">
                    Código Anti-Fraude / Hash:
                  </span>
                  <span className="font-mono text-xs font-extrabold text-slate-900 tracking-wider">
                    {previewDoc.securityHash}
                  </span>
                  <p className="text-[9px] text-slate-500 mt-0.5">
                    Validável em: edugest.co.mz/validar-documento
                  </p>
                </div>
              </div>

              {/* Data e Assinatura */}
              <div className="text-center text-xs">
                <p className="text-slate-600 mb-6">
                  {currentSchool.province}, {previewDoc.issueDate}
                </p>
                <div className="border-t border-slate-900 w-48 mx-auto pt-1 font-bold">
                  A Secretaria Escolar
                </div>
                <p className="text-[10px] text-slate-400 mt-0.5">{previewDoc.issuedBy}</p>
              </div>
            </div>

            {/* Ações da Janela */}
            <div className="no-print mt-8 flex justify-between items-center border-t border-slate-200 pt-4">
              <button
                onClick={() => setPreviewDoc(null)}
                className="rounded-xl bg-slate-100 px-4 py-2 text-xs font-bold text-slate-700 hover:bg-slate-200"
              >
                Fechar
              </button>

              <div className="flex gap-2">
                <button
                  onClick={() => {
                    setPreviewDoc(null);
                    setActiveTab('validar-documento');
                  }}
                  className="rounded-xl border border-slate-200 px-3 py-2 text-xs font-bold text-sky-700 hover:bg-sky-50 flex items-center gap-1.5"
                >
                  <ShieldCheck className="h-4 w-4" />
                  Testar Validação Pública
                </button>

                <button
                  onClick={() => window.print()}
                  className="rounded-xl bg-slate-900 px-4 py-2 text-xs font-bold text-white hover:bg-slate-800 flex items-center gap-1.5 shadow-sm"
                >
                  <Printer className="h-4 w-4" />
                  Imprimir Documento Oficial
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
