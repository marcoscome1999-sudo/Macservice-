/**
 * EduGest Moçambique - Gestão de Transferências Escolares (TransfersView)
 * Transferências de Entrada e de Saída.
 * Emissão de Guia Oficial de Transferência do SNE com carimbo,
 * escola de origem/destino, província, motivo legal e histórico académico.
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TransferRecord } from '../../types';
import {
  ArrowLeftRight,
  Plus,
  Search,
  Printer,
  FileText,
  School,
  MapPin,
  CheckCircle2,
  X
} from 'lucide-react';

export const TransfersView: React.FC = () => {
  const { db, currentSchool, currentUser, registerTransfer } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState<'ALL' | 'SAIDA' | 'ENTRADA'>('ALL');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [guideToPrint, setGuideToPrint] = useState<TransferRecord | null>(null);

  const [formData, setFormData] = useState<Omit<TransferRecord, 'id' | 'guideNumber' | 'status'>>({
    schoolId: currentSchool.id,
    studentId: db.students[0]?.id || 'std-1',
    studentName: db.students[0]?.fullName || 'Aluno',
    type: 'SAIDA',
    originSchool: currentSchool.name,
    originProvince: currentSchool.province,
    destinationSchool: 'Escola Secundária Samora Machel',
    destinationProvince: 'Gaza',
    gradeLevel: '10ª Classe',
    date: new Date().toISOString().split('T')[0],
    reason: 'Mudança de residência do encarregado de educação.',
    authorizedBy: currentUser.name
  });

  const filteredTransfers = db.transfers.filter((t) => {
    const matchSearch =
      t.studentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.guideNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.destinationSchool.toLowerCase().includes(searchTerm.toLowerCase());

    const matchType = selectedType === 'ALL' || t.type === selectedType;

    return matchSearch && matchType;
  });

  const handleSaveTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    const student = db.students.find((s) => s.id === formData.studentId);

    const newTransfer = registerTransfer({
      ...formData,
      studentName: student?.fullName || formData.studentName,
      gradeLevel: student?.currentClass || formData.gradeLevel
    });

    setIsModalOpen(false);
    setGuideToPrint(newTransfer);
  };

  return (
    <div className="space-y-6">
      {/* Cabeçalho */}
      <div className="no-print flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
            <ArrowLeftRight className="h-6 w-6 text-sky-600" />
            Transferências Escolares & Guias Oficiais
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Controlo de migração de alunos entre instituições de ensino do Sistema Nacional de Educação (SNE).
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-1.5 rounded-xl bg-sky-600 px-3.5 py-2 text-xs font-bold text-white shadow-sm hover:bg-sky-700 transition"
        >
          <Plus className="h-4 w-4" />
          Emitir Guia de Transferência
        </button>
      </div>

      {/* Filtros */}
      <div className="no-print flex flex-col sm:flex-row sm:items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Pesquisar por aluno, nº de guia ou escola..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full rounded-xl border border-slate-200 py-2 pl-9 pr-4 text-xs text-slate-800 placeholder-slate-400 focus:border-sky-500 focus:outline-none"
          />
        </div>

        <select
          value={selectedType}
          onChange={(e) => setSelectedType(e.target.value as any)}
          className="rounded-xl border border-slate-200 bg-slate-50 py-2 px-3 text-xs font-semibold text-slate-700 focus:border-sky-500 focus:outline-none"
        >
          <option value="ALL">Todas as Direcções</option>
          <option value="SAIDA">Transferências de Saída</option>
          <option value="ENTRADA">Transferências de Entrada</option>
        </select>
      </div>

      {/* Tabela de Transferências */}
      <div className="no-print overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600">
            <thead className="border-b border-slate-200 bg-slate-50 font-bold uppercase tracking-wider text-slate-500">
              <tr>
                <th className="py-3 px-4">Nº Guia Oficial</th>
                <th className="py-3 px-4">Aluno</th>
                <th className="py-3 px-4">Tipo</th>
                <th className="py-3 px-4">Escola Origem</th>
                <th className="py-3 px-4">Escola Destino</th>
                <th className="py-3 px-4">Classe</th>
                <th className="py-3 px-4">Data</th>
                <th className="py-3 px-4 text-center">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredTransfers.map((t) => (
                <tr key={t.id} className="hover:bg-slate-50/80 transition">
                  <td className="py-3 px-4 font-mono font-bold text-sky-700">
                    {t.guideNumber}
                  </td>
                  <td className="py-3 px-4 font-bold text-slate-900">
                    {t.studentName}
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className={`inline-flex rounded-full px-2 py-0.5 text-[10px] font-bold ${
                        t.type === 'SAIDA' ? 'bg-amber-100 text-amber-800' : 'bg-emerald-100 text-emerald-800'
                      }`}
                    >
                      {t.type === 'SAIDA' ? 'Saída' : 'Entrada'}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-slate-700">
                    <p className="font-semibold">{t.originSchool}</p>
                    <p className="text-[10px] text-slate-400">{t.originProvince}</p>
                  </td>
                  <td className="py-3 px-4 text-slate-700">
                    <p className="font-semibold">{t.destinationSchool}</p>
                    <p className="text-[10px] text-slate-400">{t.destinationProvince}</p>
                  </td>
                  <td className="py-3 px-4 font-medium text-slate-800">
                    {t.gradeLevel}
                  </td>
                  <td className="py-3 px-4 text-slate-500">
                    {t.date}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <button
                      onClick={() => setGuideToPrint(t)}
                      className="rounded-lg bg-sky-50 px-2.5 py-1 text-xs font-bold text-sky-700 hover:bg-sky-100 transition flex items-center gap-1 mx-auto"
                    >
                      <Printer className="h-3.5 w-3.5" />
                      Imprimir Guia
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Emitir Guia */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
          <div className="relative w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-4">
              <h3 className="font-extrabold text-slate-900 text-base flex items-center gap-2">
                <ArrowLeftRight className="h-5 w-5 text-sky-600" />
                Registar Transferência Escolar
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSaveTransfer} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Aluno *</label>
                <select
                  value={formData.studentId}
                  onChange={(e) => setFormData({ ...formData, studentId: e.target.value })}
                  className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-sky-500 focus:outline-none"
                >
                  {db.students.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.fullName} ({s.studentNumber} - {s.currentClass})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Tipo de Movimento *</label>
                  <select
                    value={formData.type}
                    onChange={(e) => setFormData({ ...formData, type: e.target.value as any })}
                    className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-sky-500 focus:outline-none"
                  >
                    <option value="SAIDA">Transferência de Saída</option>
                    <option value="ENTRADA">Transferência de Entrada</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Data *</label>
                  <input
                    type="date"
                    required
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-sky-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Escola de Origem</label>
                  <input
                    type="text"
                    required
                    value={formData.originSchool}
                    onChange={(e) => setFormData({ ...formData, originSchool: e.target.value })}
                    className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-sky-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Província Origem</label>
                  <input
                    type="text"
                    required
                    value={formData.originProvince}
                    onChange={(e) => setFormData({ ...formData, originProvince: e.target.value })}
                    className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-sky-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Escola de Destino</label>
                  <input
                    type="text"
                    required
                    value={formData.destinationSchool}
                    onChange={(e) => setFormData({ ...formData, destinationSchool: e.target.value })}
                    className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-sky-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Província Destino</label>
                  <input
                    type="text"
                    required
                    value={formData.destinationProvince}
                    onChange={(e) => setFormData({ ...formData, destinationProvince: e.target.value })}
                    className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-sky-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Motivo Justificativo *</label>
                <textarea
                  rows={2}
                  required
                  value={formData.reason}
                  onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
                  className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-sky-500 focus:outline-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-4 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="rounded-xl bg-slate-100 px-4 py-2 font-bold text-slate-700 hover:bg-slate-200 text-xs"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-sky-600 px-5 py-2 font-bold text-white hover:bg-sky-700 text-xs shadow-sm"
                >
                  Confirmar e Gerar Guia
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* GUIA DE TRANSFERÊNCIA IMPRESSA */}
      {guideToPrint && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
          <div className="relative w-full max-w-xl rounded-2xl bg-white p-8 shadow-2xl print:border-none print:shadow-none">
            <div className="border-b-2 border-slate-900 pb-4 text-center">
              <h4 className="font-extrabold text-sm uppercase tracking-wider text-slate-900">
                REPÚBLICA DE MOÇAMBIQUE
              </h4>
              <p className="text-xs font-bold text-slate-700 uppercase">
                MINISTÉRIO DA EDUCAÇÃO E DESENVOLVIMENTO HUMANO
              </p>
              <div className="mt-2 inline-block rounded-md bg-sky-100 px-3 py-0.5 text-xs font-extrabold text-sky-900 uppercase">
                GUIA OFICIAL DE TRANSFERÊNCIA ESCOLAR
              </div>
            </div>

            <div className="my-5 space-y-2 text-xs text-slate-800">
              <div className="flex justify-between border-b border-slate-100 pb-1">
                <span>Nº da Guia:</span>
                <strong className="font-mono text-sky-800">{guideToPrint.guideNumber}</strong>
              </div>
              <div className="flex justify-between border-b border-slate-100 pb-1">
                <span>Nome do Aluno:</span>
                <strong>{guideToPrint.studentName}</strong>
              </div>
              <div className="flex justify-between border-b border-slate-100 pb-1">
                <span>Classe que Frequenta:</span>
                <strong>{guideToPrint.gradeLevel}</strong>
              </div>
              <div className="flex justify-between border-b border-slate-100 pb-1">
                <span>Escola de Origem:</span>
                <strong>{guideToPrint.originSchool} ({guideToPrint.originProvince})</strong>
              </div>
              <div className="flex justify-between border-b border-slate-100 pb-1">
                <span>Escola de Destino:</span>
                <strong>{guideToPrint.destinationSchool} ({guideToPrint.destinationProvince})</strong>
              </div>
              <div className="flex justify-between border-b border-slate-100 pb-1">
                <span>Motivo da Transferência:</span>
                <span className="italic">{guideToPrint.reason}</span>
              </div>
              <div className="flex justify-between border-b border-slate-100 pb-1">
                <span>Data de Emissão:</span>
                <strong>{guideToPrint.date}</strong>
              </div>
            </div>

            <div className="mt-8 border-t border-slate-300 pt-4 text-center text-xs text-slate-600">
              <p>Autenticado pela Direção Pedagógica • Carimbo Oficial</p>
              <div className="mt-6 flex justify-between gap-2 no-print">
                <button
                  onClick={() => setGuideToPrint(null)}
                  className="rounded-xl bg-slate-100 px-4 py-2 font-bold text-slate-700 hover:bg-slate-200"
                >
                  Fechar
                </button>
                <button
                  onClick={() => window.print()}
                  className="rounded-xl bg-sky-600 px-5 py-2 font-bold text-white hover:bg-sky-700 flex items-center gap-1.5"
                >
                  <Printer className="h-4 w-4" />
                  Imprimir Guia Oficial
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
