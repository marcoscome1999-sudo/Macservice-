/**
 * EduGest Moçambique - Gestão de Alunos (StudentsView)
 * Cadastro completo, importação CSV/Excel, pesquisa avançada,
 * e visualização individual com as 7 abas:
 * Perfil → Matrículas → Notas → Faltas → Pagamentos → Documentos → Histórico
 */

import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { Student, PaymentItem, GradeEntry, AttendanceRecord, DocumentRecord } from '../../types';
import {
  Users,
  UserPlus,
  Search,
  Filter,
  Download,
  Upload,
  Eye,
  Edit2,
  Trash2,
  Phone,
  Mail,
  MapPin,
  Calendar,
  CreditCard,
  FileText,
  Clock,
  Award,
  CheckCircle2,
  AlertCircle,
  X,
  FileSpreadsheet
} from 'lucide-react';
import { StatusBadge } from '../common/StatusBadge';
import { Pagination } from '../common/Pagination';
import { EmptyState } from '../common/EmptyState';
import { ConfirmDialog } from '../common/ConfirmDialog';

const MZ_PROVINCES = [
  'Maputo Cidade',
  'Província de Maputo',
  'Gaza',
  'Inhambane',
  'Sofala',
  'Manica',
  'Tete',
  'Zambézia',
  'Nampula',
  'Niassa',
  'Cabo Delgado'
];

export const StudentsView: React.FC<{ initialSearch?: string }> = ({ initialSearch }) => {
  const { db, addStudent, updateStudent, deleteStudent, currentUser, generateDocument } = useApp();

  // Estados de Filtro e Pesquisa
  const [searchTerm, setSearchTerm] = useState(initialSearch || '');

  React.useEffect(() => {
    if (initialSearch !== undefined) {
      setSearchTerm(initialSearch);
    }
  }, [initialSearch]);
  const [selectedClass, setSelectedClass] = useState('ALL');
  const [selectedStatus, setSelectedStatus] = useState('ALL');

  // Modais
  const [isNewStudentModalOpen, setIsNewStudentModalOpen] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [activeStudentTab, setActiveStudentTab] = useState<'perfil' | 'matriculas' | 'notas' | 'faltas' | 'pagamentos' | 'documentos' | 'historico'>('perfil');

  // Formulário de Novo Aluno
  const [formData, setFormData] = useState<Omit<Student, 'id' | 'createdAt'>>({
    schoolId: db.schools[0]?.id || 'school-1',
    studentNumber: `AL-2026-${Math.floor(1000 + Math.random() * 9000)}`,
    fullName: '',
    gender: 'M',
    birthDate: '2010-01-01',
    birthPlace: 'Maputo Cidade',
    district: 'KaMpfumo',
    province: 'Maputo Cidade',
    nationality: 'Moçambicana',
    idDocType: 'BI',
    idDocNumber: '',
    nuit: '',
    phone: '+258 84 ',
    address: '',
    fatherName: '',
    motherName: '',
    guardianName: '',
    guardianPhone: '+258 84 ',
    guardianEmail: '',
    guardianRelation: 'PAI',
    medicalNotes: '',
    specialNeeds: 'Nenhuma',
    schoolHistory: '',
    currentClass: '10ª Classe',
    currentSection: 'Turma A',
    status: 'ACTIVO'
  });

  // Importação CSV/Excel
  const [csvText, setCsvText] = useState('');
  const [importMessage, setImportMessage] = useState<string | null>(null);

  // Lista Filtrada
  const filteredStudents = useMemo(() => {
    return db.students.filter((student) => {
      const matchSearch =
        student.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        student.studentNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (student.nuit && student.nuit.includes(searchTerm)) ||
        student.guardianName.toLowerCase().includes(searchTerm.toLowerCase());

      const matchClass = selectedClass === 'ALL' || student.currentClass === selectedClass;
      const matchStatus = selectedStatus === 'ALL' || student.status === selectedStatus;

      return matchSearch && matchClass && matchStatus;
    });
  }, [db.students, searchTerm, selectedClass, selectedStatus]);

  // Paginação da Tabela de Alunos
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [studentToDelete, setStudentToDelete] = useState<Student | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Resetar página se filtros mudarem
  React.useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, selectedClass, selectedStatus]);

  const totalPages = Math.ceil(filteredStudents.length / pageSize) || 1;
  const paginatedStudents = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredStudents.slice(start, start + pageSize);
  }, [filteredStudents, currentPage, pageSize]);

  // Lista de Classes Únicas
  const availableClasses = useMemo(() => {
    const set = new Set(db.students.map((s) => s.currentClass));
    return ['ALL', ...Array.from(set)];
  }, [db.students]);

  // Submissão do Novo Aluno
  const handleSaveStudent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.fullName.trim()) return;

    addStudent(formData);
    setIsNewStudentModalOpen(false);
    // Reset form
    setFormData({
      schoolId: db.schools[0]?.id || 'school-1',
      studentNumber: `AL-2026-${Math.floor(1000 + Math.random() * 9000)}`,
      fullName: '',
      gender: 'M',
      birthDate: '2010-01-01',
      birthPlace: 'Maputo Cidade',
      district: 'KaMpfumo',
      province: 'Maputo Cidade',
      nationality: 'Moçambicana',
      idDocType: 'BI',
      idDocNumber: '',
      nuit: '',
      phone: '+258 84 ',
      address: '',
      fatherName: '',
      motherName: '',
      guardianName: '',
      guardianPhone: '+258 84 ',
      guardianEmail: '',
      guardianRelation: 'PAI',
      medicalNotes: '',
      specialNeeds: 'Nenhuma',
      schoolHistory: '',
      currentClass: '10ª Classe',
      currentSection: 'Turma A',
      status: 'ACTIVO'
    });
  };

  // Processar importação CSV
  const handleProcessCsv = () => {
    try {
      const lines = csvText.trim().split('\n');
      if (lines.length < 2) {
        setImportMessage('Ficheiro vazio ou sem dados suficientes.');
        return;
      }
      let count = 0;
      for (let i = 1; i < lines.length; i++) {
        const parts = lines[i].split(',').map((p) => p.trim());
        if (parts[0]) {
          addStudent({
            schoolId: db.schools[0]?.id || 'school-1',
            studentNumber: `AL-2026-${Math.floor(1000 + Math.random() * 9000)}`,
            fullName: parts[0],
            gender: (parts[1]?.toUpperCase() === 'F' ? 'F' : 'M') as 'M' | 'F',
            birthDate: parts[2] || '2010-01-01',
            birthPlace: parts[3] || 'Maputo',
            district: parts[4] || 'KaMpfumo',
            province: parts[5] || 'Maputo Cidade',
            nationality: 'Moçambicana',
            idDocType: 'BI',
            idDocNumber: parts[6] || '000000000',
            nuit: parts[7] || '',
            phone: parts[8] || '',
            address: parts[9] || '',
            fatherName: 'Pai Cadastrado',
            motherName: 'Mãe Cadastrada',
            guardianName: parts[10] || parts[0],
            guardianPhone: parts[11] || '+258 84 000 0000',
            guardianRelation: 'PAI',
            currentClass: parts[12] || '10ª Classe',
            currentSection: parts[13] || 'Turma A',
            status: 'ACTIVO'
          });
          count++;
        }
      }
      setImportMessage(`Sucesso! ${count} alunos importados com êxito para a base de dados.`);
      setTimeout(() => {
        setIsImportModalOpen(false);
        setImportMessage(null);
        setCsvText('');
      }, 1500);
    } catch {
      setImportMessage('Erro ao processar o formato CSV. Verifique a estrutura.');
    }
  };

  // Exportar Alunos para CSV
  const handleExportCsv = () => {
    const headers = 'Numero,Nome,Sexo,Classe,Turma,BI,Encarregado,Contacto,Provincia,Estado\n';
    const rows = filteredStudents
      .map(
        (s) =>
          `"${s.studentNumber}","${s.fullName}","${s.gender}","${s.currentClass}","${s.currentSection}","${s.idDocNumber}","${s.guardianName}","${s.guardianPhone}","${s.province}","${s.status}"`
      )
      .join('\n');
    const blob = new Blob([headers + rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `EduGest_MZ_Alunos_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Dados do Aluno Selecionado para as 7 abas
  const studentEnrollments = useMemo(() => {
    if (!selectedStudent) return [];
    return db.enrollments.filter((e) => e.studentId === selectedStudent.id);
  }, [db.enrollments, selectedStudent]);

  const studentGrades = useMemo(() => {
    if (!selectedStudent) return [];
    return db.grades.filter((g) => g.studentId === selectedStudent.id);
  }, [db.grades, selectedStudent]);

  const studentPayments = useMemo(() => {
    if (!selectedStudent) return [];
    return db.payments.filter((p) => p.studentId === selectedStudent.id);
  }, [db.payments, selectedStudent]);

  const studentDocuments = useMemo(() => {
    if (!selectedStudent) return [];
    return db.documents.filter((d) => d.studentId === selectedStudent.id);
  }, [db.documents, selectedStudent]);

  const studentAttendanceStats = useMemo(() => {
    if (!selectedStudent) return { total: 0, present: 0, justified: 0, absent: 0, delay: 0 };
    let present = 0, justified = 0, absent = 0, delay = 0;
    let total = 0;
    db.attendance.forEach((att) => {
      const entry = att.entries.find((e) => e.studentId === selectedStudent.id);
      if (entry) {
        total++;
        if (entry.status === 'PRESENTE') present++;
        else if (entry.status === 'JUSTIFICADA') justified++;
        else if (entry.status === 'FALTA') absent++;
        else if (entry.status === 'ATRASO') delay++;
      }
    });
    return { total, present, justified, absent, delay };
  }, [db.attendance, selectedStudent]);

  return (
    <div className="space-y-6">
      {/* Cabeçalho da Seção */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
            <Users className="h-6 w-6 text-sky-600" />
            Gestão de Alunos
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Cadastros completos, processos escolares, acompanhamento pedagógico e financeiro.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleExportCsv}
            className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-bold text-slate-700 hover:bg-slate-50 transition shadow-xs"
          >
            <Download className="h-4 w-4 text-slate-500" />
            Exportar CSV
          </button>

          <button
            onClick={() => setIsImportModalOpen(true)}
            className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-bold text-slate-700 hover:bg-slate-50 transition shadow-xs"
          >
            <Upload className="h-4 w-4 text-slate-500" />
            Importar Excel/CSV
          </button>

          <button
            onClick={() => setIsNewStudentModalOpen(true)}
            className="flex items-center gap-1.5 rounded-xl bg-sky-600 px-3.5 py-2 text-xs font-bold text-white shadow-sm hover:bg-sky-700 transition"
          >
            <UserPlus className="h-4 w-4" />
            Cadastrar Novo Aluno
          </button>
        </div>
      </div>

      {/* Barra de Filtros & Pesquisa */}
      <div className="flex flex-col gap-3 rounded-2xl border border-slate-200 bg-white p-4 shadow-xs sm:flex-row sm:items-center sm:justify-between">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Pesquisar por nome, nº do aluno, NUIT ou encarregado..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full rounded-xl border border-slate-200 py-2 pl-9 pr-4 text-xs text-slate-800 placeholder-slate-400 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
          />
        </div>

        <div className="flex items-center gap-2">
          <select
            value={selectedClass}
            onChange={(e) => setSelectedClass(e.target.value)}
            className="rounded-xl border border-slate-200 bg-slate-50 py-2 px-3 text-xs font-semibold text-slate-700 focus:border-sky-500 focus:outline-none"
          >
            {availableClasses.map((c) => (
              <option key={c} value={c}>
                {c === 'ALL' ? 'Todas as Classes' : c}
              </option>
            ))}
          </select>

          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="rounded-xl border border-slate-200 bg-slate-50 py-2 px-3 text-xs font-semibold text-slate-700 focus:border-sky-500 focus:outline-none"
          >
            <option value="ALL">Todos os Estados</option>
            <option value="ACTIVO">Activos</option>
            <option value="TRANSFERIDO">Transferidos</option>
            <option value="DESISTENTE">Desistentes</option>
            <option value="GRADUADO">Graduados</option>
          </select>
        </div>
      </div>

      {/* Tabela de Alunos */}
      <div className="overflow-hidden rounded-lg border border-slate-200 bg-white shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600">
            <thead className="border-b border-slate-200 bg-slate-50 font-bold uppercase tracking-wider text-slate-500">
              <tr>
                <th className="py-3 px-4">Nº Aluno</th>
                <th className="py-3 px-4">Nome Completo</th>
                <th className="py-3 px-4">Classe & Turma</th>
                <th className="py-3 px-4">Documento / NUIT</th>
                <th className="py-3 px-4">Encarregado & Contacto</th>
                <th className="py-3 px-4">Província</th>
                <th className="py-3 px-4">Estado</th>
                <th className="py-3 px-4 text-center">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredStudents.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-4">
                    <EmptyState
                      title="Nenhum aluno encontrado"
                      description="Não foram encontrados alunos correspondentes aos critérios de pesquisa ou filtros selecionados."
                      actionLabel="Cadastrar Novo Aluno"
                      onAction={() => setIsNewStudentModalOpen(true)}
                    />
                  </td>
                </tr>
              ) : (
                paginatedStudents.map((student) => (
                  <tr key={student.id} className="hover:bg-slate-50/80 transition">
                    <td className="py-3 px-4 font-mono font-bold text-slate-900">
                      {student.studentNumber}
                    </td>
                    <td className="py-3 px-4 font-bold text-slate-900">
                      <div className="flex items-center gap-2">
                        <div className="flex h-7 w-7 items-center justify-center rounded bg-slate-100 text-slate-700 font-bold text-[11px] border border-slate-200">
                          {student.fullName.charAt(0)}
                        </div>
                        <div>
                          <p>{student.fullName}</p>
                          <p className="text-[10px] text-slate-400 font-normal">
                            Nasc: {student.birthDate} ({student.gender === 'F' ? 'Feminino' : 'Masculino'})
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-semibold text-slate-800">{student.currentClass}</span>
                      <span className="block text-[11px] text-slate-500">{student.currentSection}</span>
                    </td>
                    <td className="py-3 px-4 font-mono text-[11px]">
                      <span className="block text-slate-800">{student.idDocType}: {student.idDocNumber}</span>
                      {student.nuit && <span className="text-slate-400">NUIT: {student.nuit}</span>}
                    </td>
                    <td className="py-3 px-4">
                      <span className="block font-medium text-slate-800">{student.guardianName}</span>
                      <span className="block text-[11px] text-slate-500">{student.guardianPhone}</span>
                    </td>
                    <td className="py-3 px-4 text-slate-700">
                      {student.province}
                    </td>
                    <td className="py-3 px-4">
                      <StatusBadge status={student.status} size="sm" />
                    </td>
                    <td className="py-3 px-4 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={() => {
                            setSelectedStudent(student);
                            setActiveStudentTab('perfil');
                          }}
                          className="rounded p-1.5 text-slate-600 hover:bg-slate-100 hover:text-slate-900 transition"
                          title="Ver Ficha Individual Completa"
                        >
                          <Eye className="h-4 w-4" />
                        </button>
                        {currentUser.role === 'ADMIN' && (
                          <button
                            onClick={() => setStudentToDelete(student)}
                            className="rounded p-1.5 text-slate-400 hover:bg-rose-50 hover:text-rose-600 transition"
                            title="Eliminar Aluno"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Paginação */}
        {filteredStudents.length > 0 && (
          <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            totalItems={filteredStudents.length}
            pageSize={pageSize}
            onPageChange={setCurrentPage}
            onPageSizeChange={(newSize) => {
              setPageSize(newSize);
              setCurrentPage(1);
            }}
            itemLabel="alunos"
          />
        )}
      </div>

      {/* MODAL 1: FICHA INDIVIDUAL DO ALUNO (COM AS 7 ABAS SOLICITADAS NO PONTO 4) */}
      {selectedStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs overflow-y-auto">
          <div className="relative w-full max-w-4xl rounded-2xl bg-white shadow-2xl my-8 overflow-hidden">
            {/* Topo do Modal */}
            <div className="flex items-center justify-between border-b border-slate-200 bg-slate-900 px-6 py-4 text-white">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-sky-500 font-extrabold text-white text-base">
                  {selectedStudent.fullName.charAt(0)}
                </div>
                <div>
                  <h3 className="text-base font-extrabold">{selectedStudent.fullName}</h3>
                  <p className="text-xs text-slate-300">
                    Nº: {selectedStudent.studentNumber} • {selectedStudent.currentClass} ({selectedStudent.currentSection})
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSelectedStudent(null)}
                className="rounded-lg p-1 text-slate-400 hover:bg-white/10 hover:text-white"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* As 7 Abas: Perfil → Matrículas → Notas → Faltas → Pagamentos → Documentos → Histórico */}
            <div className="flex border-b border-slate-200 bg-slate-50 px-6 overflow-x-auto custom-scrollbar">
              {(
                [
                  { key: 'perfil', label: '1. Perfil Completo' },
                  { key: 'matriculas', label: '2. Matrículas' },
                  { key: 'notas', label: '3. Notas & Médias' },
                  { key: 'faltas', label: '4. Faltas & Assiduidade' },
                  { key: 'pagamentos', label: '5. Pagamentos (MT)' },
                  { key: 'documentos', label: '6. Documentos & QR' },
                  { key: 'historico', label: '7. Histórico Escolar' }
                ] as const
              ).map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setActiveStudentTab(tab.key)}
                  className={`border-b-2 py-3 px-3 text-xs font-bold whitespace-nowrap transition-colors ${
                    activeStudentTab === tab.key
                      ? 'border-sky-600 text-sky-700 bg-white'
                      : 'border-transparent text-slate-500 hover:text-slate-900'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Conteúdo das Abas */}
            <div className="p-6 max-h-[70vh] overflow-y-auto text-xs text-slate-700 space-y-4">
              {/* ABA 1: PERFIL COMPLETO */}
              {activeStudentTab === 'perfil' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="rounded-xl border border-slate-200 p-4 space-y-2 bg-slate-50/50">
                    <h4 className="font-extrabold text-slate-900 border-b border-slate-200 pb-1.5 uppercase text-[11px] tracking-wider text-sky-700">
                      Identificação Pessoal & Nascimento
                    </h4>
                    <p><strong>Nome Completo:</strong> {selectedStudent.fullName}</p>
                    <p><strong>Sexo:</strong> {selectedStudent.gender === 'F' ? 'Feminino' : 'Masculino'}</p>
                    <p><strong>Data de Nascimento:</strong> {selectedStudent.birthDate}</p>
                    <p><strong>Naturalidade:</strong> {selectedStudent.birthPlace}</p>
                    <p><strong>Distrito:</strong> {selectedStudent.district}</p>
                    <p><strong>Província:</strong> {selectedStudent.province}</p>
                    <p><strong>Nacionalidade:</strong> {selectedStudent.nationality}</p>
                    <p><strong>Documento:</strong> {selectedStudent.idDocType} nº {selectedStudent.idDocNumber}</p>
                    <p><strong>NUIT:</strong> {selectedStudent.nuit || 'Não aplicável'}</p>
                  </div>

                  <div className="rounded-xl border border-slate-200 p-4 space-y-2 bg-slate-50/50">
                    <h4 className="font-extrabold text-slate-900 border-b border-slate-200 pb-1.5 uppercase text-[11px] tracking-wider text-sky-700">
                      Filiação & Encarregado de Educação
                    </h4>
                    <p><strong>Nome do Pai:</strong> {selectedStudent.fatherName}</p>
                    <p><strong>Nome da Mãe:</strong> {selectedStudent.motherName}</p>
                    <p><strong>Encarregado de Educação:</strong> {selectedStudent.guardianName} ({selectedStudent.guardianRelation})</p>
                    <p><strong>Contacto do Encarregado:</strong> {selectedStudent.guardianPhone}</p>
                    <p><strong>Email do Encarregado:</strong> {selectedStudent.guardianEmail || 'Não informado'}</p>
                    <p><strong>Endereço Residencial:</strong> {selectedStudent.address}</p>
                  </div>

                  <div className="col-span-1 md:col-span-2 rounded-xl border border-slate-200 p-4 space-y-2 bg-slate-50/50">
                    <h4 className="font-extrabold text-slate-900 border-b border-slate-200 pb-1.5 uppercase text-[11px] tracking-wider text-sky-700">
                      Saúde & Necessidades Educativas Especiais (NEE)
                    </h4>
                    <p><strong>Informação Médica:</strong> {selectedStudent.medicalNotes || 'Nenhuma restrição ou alergia reportada.'}</p>
                    <p><strong>Necessidades Educativas Especiais (NEE):</strong> {selectedStudent.specialNeeds || 'Nenhuma.'}</p>
                  </div>
                </div>
              )}

              {/* ABA 2: MATRÍCULAS */}
              {activeStudentTab === 'matriculas' && (
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <h4 className="font-bold text-slate-900">Histórico de Matrículas e Renovações</h4>
                    <span className="text-xs font-semibold text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
                      Ano Activo: 2026
                    </span>
                  </div>

                  {studentEnrollments.length === 0 ? (
                    <p className="text-slate-400 py-4">Nenhuma matrícula registrada para este aluno.</p>
                  ) : (
                    studentEnrollments.map((enr) => (
                      <div key={enr.id} className="rounded-xl border border-slate-200 p-4 bg-white flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 shadow-xs">
                        <div>
                          <p className="font-bold text-slate-900 text-sm">
                            {enr.enrollmentNumber} • {enr.gradeLevel} ({enr.sectionName})
                          </p>
                          <p className="text-[11px] text-slate-500">
                            Ano Lectivo: {enr.academicYear} • Data: {enr.date} • Encarregado: {enr.guardianName}
                          </p>
                        </div>
                        <span className="rounded-full bg-emerald-100 px-3 py-1 text-xs font-bold text-emerald-800 self-start sm:self-auto">
                          {enr.status}
                        </span>
                      </div>
                    ))
                  )}
                </div>
              )}

              {/* ABA 3: NOTAS */}
              {activeStudentTab === 'notas' && (
                <div className="space-y-3">
                  <h4 className="font-bold text-slate-900">Boletim Escolar de Avaliações (0 a 20 Valores)</h4>
                  {studentGrades.length === 0 ? (
                    <p className="text-slate-400 py-4">Nenhuma nota lançada para este aluno ainda.</p>
                  ) : (
                    <div className="overflow-x-auto rounded-xl border border-slate-200">
                      <table className="w-full text-left text-xs">
                        <thead className="bg-slate-100 text-slate-700 font-bold uppercase">
                          <tr>
                            <th className="p-2.5">Disciplina</th>
                            <th className="p-2.5">Trimestre</th>
                            <th className="p-2.5">ACS 1</th>
                            <th className="p-2.5">ACS 2</th>
                            <th className="p-2.5">Trabalho (TI)</th>
                            <th className="p-2.5">ACP (Prova)</th>
                            <th className="p-2.5">Média (MT)</th>
                            <th className="p-2.5">Resultado</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {studentGrades.map((g) => {
                            const sub = db.subjects.find((s) => s.id === g.subjectId);
                            const isPassing = (g.mt ?? 0) >= 10;
                            return (
                              <tr key={g.id} className="hover:bg-slate-50">
                                <td className="p-2.5 font-bold text-slate-900">{sub?.name || g.subjectId}</td>
                                <td className="p-2.5">{g.term}º Trimestre</td>
                                <td className="p-2.5 font-mono">{g.acs1 ?? '-'}</td>
                                <td className="p-2.5 font-mono">{g.acs2 ?? '-'}</td>
                                <td className="p-2.5 font-mono">{g.trabalho ?? '-'}</td>
                                <td className="p-2.5 font-mono font-bold text-slate-800">{g.acp ?? '-'}</td>
                                <td className="p-2.5 font-mono font-extrabold text-sky-700 text-sm">
                                  {g.mt ?? '-'}
                                </td>
                                <td className="p-2.5">
                                  <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                                    isPassing ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                                  }`}>
                                    {isPassing ? 'Aprovado' : 'Não Aprovado'}
                                  </span>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              )}

              {/* ABA 4: FALTAS & ASSIDUIDADE */}
              {activeStudentTab === 'faltas' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-4 gap-3 text-center">
                    <div className="rounded-xl border border-slate-200 p-3 bg-slate-50">
                      <p className="text-[10px] font-bold text-slate-500 uppercase">Aulas Registadas</p>
                      <p className="text-lg font-extrabold text-slate-900">{studentAttendanceStats.total}</p>
                    </div>
                    <div className="rounded-xl border border-emerald-200 p-3 bg-emerald-50">
                      <p className="text-[10px] font-bold text-emerald-700 uppercase">Presenças</p>
                      <p className="text-lg font-extrabold text-emerald-900">{studentAttendanceStats.present}</p>
                    </div>
                    <div className="rounded-xl border border-indigo-200 p-3 bg-indigo-50">
                      <p className="text-[10px] font-bold text-indigo-700 uppercase">Justificadas</p>
                      <p className="text-lg font-extrabold text-indigo-900">{studentAttendanceStats.justified}</p>
                    </div>
                    <div className="rounded-xl border border-rose-200 p-3 bg-rose-50">
                      <p className="text-[10px] font-bold text-rose-700 uppercase">Faltas Injustificadas</p>
                      <p className="text-lg font-extrabold text-rose-900">{studentAttendanceStats.absent}</p>
                    </div>
                  </div>

                  <div className="rounded-xl border border-slate-200 p-4 bg-slate-50 text-xs">
                    <p className="font-bold text-slate-900 mb-1">Regra Oficial de Assiduidade (SNE):</p>
                    <p className="text-slate-600">
                      O limite máximo de faltas injustificadas permitido pelo Regulamento Geral do Ensino Básico e Secundário é de <strong>25%</strong> da carga horária da disciplina. Alertas são disparados automaticamente ao encarregado.
                    </p>
                  </div>
                </div>
              )}

              {/* ABA 5: PAGAMENTOS */}
              {activeStudentTab === 'pagamentos' && (
                <div className="space-y-3">
                  <h4 className="font-bold text-slate-900">Extrato Financeiro & Propinas em Meticais (MT)</h4>
                  {studentPayments.length === 0 ? (
                    <p className="text-slate-400 py-4">Nenhum pagamento registado para este aluno.</p>
                  ) : (
                    <div className="space-y-2">
                      {studentPayments.map((p) => (
                        <div key={p.id} className="flex items-center justify-between rounded-xl border border-slate-200 p-3 bg-white">
                          <div>
                            <p className="font-bold text-slate-900">
                              {p.feeType} {p.monthRef && `(${p.monthRef})`}
                            </p>
                            <p className="text-[11px] text-slate-500">
                              Vencimento: {p.dueDate} • Recibo: {p.receiptNumber || 'Pendente'}
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="font-extrabold text-sm text-slate-900">{p.amount.toLocaleString('pt-MZ')} MT</p>
                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              p.status === 'PAGO' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                            }`}>
                              {p.status}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* ABA 6: DOCUMENTOS */}
              {activeStudentTab === 'documentos' && (
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <h4 className="font-bold text-slate-900">Documentos Oficiais Emitidos com Código QR</h4>
                    <button
                      onClick={() => {
                        generateDocument({
                          schoolId: selectedStudent.schoolId,
                          type: 'DECLARACAO_MATRICULA',
                          studentId: selectedStudent.id,
                          studentName: selectedStudent.fullName,
                          gradeLevel: selectedStudent.currentClass,
                          sectionName: selectedStudent.currentSection,
                          academicYear: 2026,
                          issuedBy: currentUser.name,
                          details: 'Declaração gerada para fins de comprovação oficial de matrícula.'
                        });
                      }}
                      className="rounded-lg bg-sky-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-sky-700"
                    >
                      + Emitir Declaração de Matrícula
                    </button>
                  </div>

                  {studentDocuments.length === 0 ? (
                    <p className="text-slate-400 py-4">Nenhum documento gerado ainda.</p>
                  ) : (
                    studentDocuments.map((doc) => (
                      <div key={doc.id} className="rounded-xl border border-slate-200 p-3 bg-white flex justify-between items-center">
                        <div>
                          <p className="font-bold text-slate-900">{doc.type.replace('_', ' ')}</p>
                          <p className="text-[11px] text-slate-500">
                            Nº {doc.documentNumber} • Hash QR: <span className="font-mono text-sky-700 font-bold">{doc.securityHash}</span>
                          </p>
                          <p className="text-[10px] text-slate-400">Emitido em {doc.issueDate} por {doc.issuedBy}</p>
                        </div>
                        <span className="rounded-full bg-emerald-100 px-2.5 py-1 text-xs font-bold text-emerald-800">
                          {doc.status}
                        </span>
                      </div>
                    ))
                  )}
                </div>
              )}

              {/* ABA 7: HISTÓRICO ESCOLAR */}
              {activeStudentTab === 'historico' && (
                <div className="space-y-3">
                  <h4 className="font-bold text-slate-900">Linha de Tempo e Histórico do Aluno</h4>
                  <div className="relative border-l-2 border-slate-200 pl-4 space-y-4 ml-2">
                    <div className="relative">
                      <span className="absolute -left-[21px] top-1 h-3 w-3 rounded-full bg-sky-600"></span>
                      <p className="font-bold text-slate-900">Matrícula Confirmada no Ano 2026</p>
                      <p className="text-[11px] text-slate-500">Admitido na {selectedStudent.currentClass} - {selectedStudent.currentSection}.</p>
                    </div>
                    {selectedStudent.schoolHistory && (
                      <div className="relative">
                        <span className="absolute -left-[21px] top-1 h-3 w-3 rounded-full bg-slate-400"></span>
                        <p className="font-bold text-slate-900">Percurso Anterior</p>
                        <p className="text-[11px] text-slate-500">{selectedStudent.schoolHistory}</p>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Rodapé do Modal */}
            <div className="border-t border-slate-200 bg-slate-50 px-6 py-3 text-right">
              <button
                onClick={() => setSelectedStudent(null)}
                className="rounded-xl bg-slate-200 px-4 py-2 text-xs font-bold text-slate-800 hover:bg-slate-300"
              >
                Fechar Ficha
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: CADASTRAR NOVO ALUNO */}
      {isNewStudentModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs overflow-y-auto">
          <div className="relative w-full max-w-2xl rounded-2xl bg-white shadow-2xl my-8 overflow-hidden">
            <div className="flex items-center justify-between border-b border-slate-200 bg-slate-900 px-6 py-4 text-white">
              <h3 className="font-extrabold text-base flex items-center gap-2">
                <UserPlus className="h-5 w-5 text-sky-400" />
                Cadastrar Novo Aluno (SNE Moçambique)
              </h3>
              <button
                onClick={() => setIsNewStudentModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSaveStudent} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="sm:col-span-2">
                  <label className="block font-bold text-slate-700 mb-1">Nome Completo do Aluno *</label>
                  <input
                    type="text"
                    required
                    value={formData.fullName}
                    onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                    className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-sky-500 focus:outline-none"
                    placeholder="ex: Marcelino dos Santos"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Sexo *</label>
                  <select
                    value={formData.gender}
                    onChange={(e) => setFormData({ ...formData, gender: e.target.value as 'M' | 'F' })}
                    className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-sky-500 focus:outline-none"
                  >
                    <option value="M">Masculino</option>
                    <option value="F">Feminino</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Data de Nascimento *</label>
                  <input
                    type="date"
                    required
                    value={formData.birthDate}
                    onChange={(e) => setFormData({ ...formData, birthDate: e.target.value })}
                    className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-sky-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Província *</label>
                  <select
                    value={formData.province}
                    onChange={(e) => setFormData({ ...formData, province: e.target.value })}
                    className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-sky-500 focus:outline-none"
                  >
                    {MZ_PROVINCES.map((p) => (
                      <option key={p} value={p}>{p}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Distrito / Localidade *</label>
                  <input
                    type="text"
                    required
                    value={formData.district}
                    onChange={(e) => setFormData({ ...formData, district: e.target.value })}
                    className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-sky-500 focus:outline-none"
                    placeholder="ex: Cidade da Matola, KaMpfumo"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Documento de Identificação *</label>
                  <div className="flex gap-1.5">
                    <select
                      value={formData.idDocType}
                      onChange={(e) => setFormData({ ...formData, idDocType: e.target.value as any })}
                      className="rounded-xl border border-slate-300 p-2 text-xs focus:border-sky-500 focus:outline-none"
                    >
                      <option value="BI">BI</option>
                      <option value="CEDULA">Cédula</option>
                      <option value="PASSAPORTE">Passaporte</option>
                      <option value="DIRE">DIRE</option>
                    </select>
                    <input
                      type="text"
                      required
                      value={formData.idDocNumber}
                      onChange={(e) => setFormData({ ...formData, idDocNumber: e.target.value })}
                      className="flex-1 rounded-xl border border-slate-300 p-2 text-xs focus:border-sky-500 focus:outline-none"
                      placeholder="Número do documento"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">NUIT (se aplicável)</label>
                  <input
                    type="text"
                    value={formData.nuit}
                    onChange={(e) => setFormData({ ...formData, nuit: e.target.value })}
                    className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-sky-500 focus:outline-none"
                    placeholder="ex: 120948571"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Classe a Ingressar *</label>
                  <select
                    value={formData.currentClass}
                    onChange={(e) => setFormData({ ...formData, currentClass: e.target.value })}
                    className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-sky-500 focus:outline-none"
                  >
                    <option value="7ª Classe">7ª Classe (ESG - 1º Ciclo)</option>
                    <option value="8ª Classe">8ª Classe (ESG - 1º Ciclo)</option>
                    <option value="9ª Classe">9ª Classe (ESG - 1º Ciclo)</option>
                    <option value="10ª Classe">10ª Classe (Exame Nacional)</option>
                    <option value="11ª Classe">11ª Classe (ESG - 2º Ciclo)</option>
                    <option value="12ª Classe">12ª Classe (Pré-Universitário)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Turma *</label>
                  <input
                    type="text"
                    required
                    value={formData.currentSection}
                    onChange={(e) => setFormData({ ...formData, currentSection: e.target.value })}
                    className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-sky-500 focus:outline-none"
                    placeholder="Turma A"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block font-bold text-slate-700 mb-1">Nome do Encarregado de Educação *</label>
                  <input
                    type="text"
                    required
                    value={formData.guardianName}
                    onChange={(e) => setFormData({ ...formData, guardianName: e.target.value })}
                    className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-sky-500 focus:outline-none"
                    placeholder="Nome completo do encarregado"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Contacto Telefónico do Encarregado *</label>
                  <input
                    type="tel"
                    required
                    value={formData.guardianPhone}
                    onChange={(e) => setFormData({ ...formData, guardianPhone: e.target.value })}
                    className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-sky-500 focus:outline-none"
                    placeholder="+258 84 000 0000"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Endereço Residencial</label>
                  <input
                    type="text"
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-sky-500 focus:outline-none"
                    placeholder="Bairro, Rua, Casa nº"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-4 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsNewStudentModalOpen(false)}
                  className="rounded-xl bg-slate-100 px-4 py-2 font-bold text-slate-700 hover:bg-slate-200"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-sky-600 px-5 py-2 font-bold text-white hover:bg-sky-700 shadow-sm"
                >
                  Confirmar Cadastro do Aluno
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: IMPORTAR EXCEL / CSV */}
      {isImportModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
          <div className="relative w-full max-w-xl rounded-2xl bg-white shadow-2xl p-6">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-4">
              <h3 className="font-extrabold text-slate-900 text-base flex items-center gap-2">
                <FileSpreadsheet className="h-5 w-5 text-emerald-600" />
                Importar Lista de Alunos (Excel / CSV)
              </h3>
              <button
                onClick={() => setIsImportModalOpen(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <p className="text-xs text-slate-600 mb-3 leading-relaxed">
              Cole os dados dos alunos no formato CSV com os seguintes campos:<br />
              <code className="text-[11px] bg-slate-100 p-1 rounded font-mono block mt-1">
                Nome,Sexo(M/F),DataNascimento,Naturalidade,Distrito,Provincia,BI,NUIT,Telefone,Morada,Encarregado,ContactoEncarregado,Classe,Turma
              </code>
            </p>

            <textarea
              rows={6}
              value={csvText}
              onChange={(e) => setCsvText(e.target.value)}
              placeholder="Exemplo:
Américo António Sitoe,M,2010-05-12,Maputo,KaMpfumo,Maputo Cidade,110293847291B,120938471,+258 84 111 2233,Bairro Central,António Sitoe,+258 84 111 0000,10ª Classe,Turma A"
              className="w-full rounded-xl border border-slate-300 p-3 text-xs font-mono focus:border-sky-500 focus:outline-none"
            />

            {importMessage && (
              <p className={`mt-2 text-xs font-bold ${importMessage.startsWith('Sucesso') ? 'text-emerald-600' : 'text-rose-600'}`}>
                {importMessage}
              </p>
            )}

            <div className="mt-4 flex justify-end gap-2">
              <button
                onClick={() => setIsImportModalOpen(false)}
                className="rounded-xl bg-slate-100 px-4 py-2 font-bold text-slate-700 hover:bg-slate-200 text-xs"
              >
                Cancelar
              </button>
              <button
                onClick={handleProcessCsv}
                className="rounded-xl bg-emerald-600 px-5 py-2 font-bold text-white hover:bg-emerald-700 text-xs shadow-sm"
              >
                Importar Dados
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Diálogo de Confirmação de Eliminação de Aluno */}
      <ConfirmDialog
        isOpen={Boolean(studentToDelete)}
        onClose={() => setStudentToDelete(null)}
        onConfirm={() => {
          if (studentToDelete) {
            setIsDeleting(true);
            deleteStudent(studentToDelete.id);
            setIsDeleting(false);
            setStudentToDelete(null);
          }
        }}
        title="Eliminar Registo de Aluno"
        description={`Tem a certeza de que pretende eliminar definitivamente a ficha escolar de ${studentToDelete?.fullName} (${studentToDelete?.studentNumber})? Esta ação removerá os dados de matrículas e histórico associado.`}
        confirmLabel="Eliminar Aluno"
        cancelLabel="Manter Aluno"
        variant="danger"
        isLoading={isDeleting}
      />
    </div>
  );
};
