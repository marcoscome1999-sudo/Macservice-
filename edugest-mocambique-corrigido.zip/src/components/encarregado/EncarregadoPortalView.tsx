/**
 * EduGest Moçambique - Portal do Encarregado de Educação
 * Ponto 6 do SNE: Acompanhamento rigoroso de educandos, boletins trimestrais,
 * controlo de presenças, situação de propinas/pagamentos e avisos escolares.
 */

import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { Student } from '../../types';
import { StatusBadge } from '../common/StatusBadge';
import {
  Users,
  Award,
  Calendar,
  CreditCard,
  AlertTriangle,
  CheckCircle,
  FileText,
  Clock,
  Bell,
  Smartphone,
  Info,
  ChevronDown
} from 'lucide-react';

export const EncarregadoPortalView: React.FC = () => {
  const { db, currentUser, currentSchool, recordPayment } = useApp();

  // Encontrar educandos vinculados a este encarregado
  const linkedStudents = useMemo(() => {
    // Aluno explicitamente vinculado ou alunos cujo encarregado coincide com o nome
    const explicit = db.students.filter(
      (s) =>
        s.id === currentUser.linkedStudentId ||
        s.guardianName.toLowerCase().includes(currentUser.name.toLowerCase()) ||
        currentUser.name.toLowerCase().includes(s.guardianName.toLowerCase())
    );
    if (explicit.length > 0) return explicit;
    return db.students.slice(0, 2); // Fallback amigável
  }, [db.students, currentUser]);

  const [selectedStudentId, setSelectedStudentId] = useState<string>(
    linkedStudents[0]?.id || db.students[0]?.id || ''
  );

  const activeStudent = useMemo(() => {
    return linkedStudents.find((s) => s.id === selectedStudentId) || linkedStudents[0] || db.students[0];
  }, [linkedStudents, selectedStudentId]);

  // Turma do educando
  const studentClass = useMemo(() => {
    return db.classes.find((c) => c.name === activeStudent?.currentClass) || db.classes[0];
  }, [db.classes, activeStudent]);

  // Sub-abas do Encarregado
  const [activeTabSub, setActiveTabSub] = useState<'DESEMPENHO' | 'ASSIDUIDADE' | 'PROPINAS' | 'AVISOS'>('DESEMPENHO');

  // Notas do educando
  const studentGrades = useMemo(() => {
    if (!activeStudent) return [];
    return db.grades.filter((g) => g.studentId === activeStudent.id);
  }, [db.grades, activeStudent]);

  // Alertas automáticos
  const gradeAlerts = useMemo(() => {
    return studentGrades.filter((g) => g.finalGrade !== null && g.finalGrade < 10);
  }, [studentGrades]);

  // Assiduidade do educando
  const studentAttendance = useMemo(() => {
    if (!activeStudent) return [];
    return db.attendance.filter((a) => a.studentId === activeStudent.id);
  }, [db.attendance, activeStudent]);

  const absencesCount = studentAttendance.filter((a) => a.status === 'FALTA_INJUSTIFICADA').length;

  // Propinas e Pagamentos do educando
  const studentPayments = useMemo(() => {
    if (!activeStudent) return [];
    return db.payments.filter((p) => p.studentId === activeStudent.id);
  }, [db.payments, activeStudent]);

  const pendingPayments = studentPayments.filter((p) => p.status === 'PENDENTE' || p.status === 'ATRASADO');
  const paidPayments = studentPayments.filter((p) => p.status === 'PAGO');

  // Simular pagamento rápido M-Pesa pelo Encarregado
  const [paymentSuccessMsg, setPaymentSuccessMsg] = useState<string | null>(null);

  const handleSimulatePayment = (paymentId: string) => {
    const ref = 'MPESA' + Math.floor(10000000 + Math.random() * 90000000);
    recordPayment(paymentId, 'MPESA', ref);
    setPaymentSuccessMsg(`Pagamento liquidado com sucesso via M-Pesa (Ref: ${ref})!`);
    setTimeout(() => setPaymentSuccessMsg(null), 4000);
  };

  return (
    <div className="space-y-6">
      {/* Cabeçalho do Encarregado */}
      <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3.5">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-amber-50 text-amber-800 font-extrabold text-lg border border-amber-200">
              {currentUser.name.charAt(0)}
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-lg sm:text-xl font-extrabold text-slate-900">{currentUser.name}</h2>
                <span className="font-mono text-xs font-bold text-amber-800 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-md">
                  {currentUser.accessCode}
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Encarregado(a) de Educação • Contacto: {currentUser.phone || '+258 84 123 4567'} • Escola: {currentSchool.name}
              </p>
            </div>
          </div>

          {/* Seletor de Educando */}
          {linkedStudents.length > 1 && (
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-600">Educando:</span>
              <select
                value={selectedStudentId}
                onChange={(e) => setSelectedStudentId(e.target.value)}
                className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-bold text-slate-900 focus:border-sky-500 focus:outline-hidden"
              >
                {linkedStudents.map((st) => (
                  <option key={st.id} value={st.id}>
                    {st.fullName} ({st.currentClass})
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>
      </div>

      {/* Cartão de Resumo do Educando Ativo */}
      <div className="rounded-2xl border border-sky-200 bg-sky-50/50 p-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <p className="text-[11px] font-extrabold text-sky-800 uppercase tracking-wider">Acompanhamento do Educando</p>
            <h3 className="text-base font-extrabold text-slate-900 mt-0.5">
              {activeStudent?.fullName}
            </h3>
            <p className="text-xs text-slate-600 mt-0.5">
              Nº de Matrícula: <strong className="font-mono">{activeStudent?.studentNumber}</strong> • Turma: {studentClass?.name} ({studentClass?.shift}) • Sala {studentClass?.roomNumber}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 px-3 py-1 text-xs font-extrabold">
              Ano Letivo 2026 Ativo
            </span>
          </div>
        </div>
      </div>

      {/* Alertas Automáticos para os Pais */}
      {(gradeAlerts.length > 0 || absencesCount > 2) && (
        <div className="space-y-2">
          {gradeAlerts.map((ga) => {
            const subj = db.subjects.find((s) => s.id === ga.subjectId);
            return (
              <div key={ga.id} className="rounded-xl bg-rose-50 border border-rose-200 p-3 text-xs flex items-center gap-2.5 text-rose-900">
                <AlertTriangle className="h-4 w-4 text-rose-600 shrink-0" />
                <span>
                  <strong>Atenção Pedagógica:</strong> O seu educando obteve nota de <strong>{ga.finalGrade} valores</strong> na disciplina de <strong>{subj?.name || 'Disciplina'}</strong> no {ga.term}º Trimestre. Recomenda-se apoio pedagógico.
                </span>
              </div>
            );
          })}

          {absencesCount > 2 && (
            <div className="rounded-xl bg-amber-50 border border-amber-200 p-3 text-xs flex items-center gap-2.5 text-amber-900">
              <AlertTriangle className="h-4 w-4 text-amber-600 shrink-0" />
              <span>
                <strong>Alerta de Faltas:</strong> O educando acumula <strong>{absencesCount} faltas não justificadas</strong>. Lembre-se que o limite do SNE é de 25% da carga horária.
              </span>
            </div>
          )}
        </div>
      )}

      {/* Navegação entre Abas */}
      <div className="flex items-center gap-2 border-b border-slate-200 overflow-x-auto pb-1 sm:pb-0">
        <button
          onClick={() => setActiveTabSub('DESEMPENHO')}
          className={`flex items-center gap-2 border-b-2 px-4 py-2.5 text-xs sm:text-sm font-bold whitespace-nowrap transition-colors ${
            activeTabSub === 'DESEMPENHO'
              ? 'border-sky-600 text-sky-600'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <Award className="h-4 w-4" />
          Aproveitamento & Notas
        </button>

        <button
          onClick={() => setActiveTabSub('ASSIDUIDADE')}
          className={`flex items-center gap-2 border-b-2 px-4 py-2.5 text-xs sm:text-sm font-bold whitespace-nowrap transition-colors ${
            activeTabSub === 'ASSIDUIDADE'
              ? 'border-sky-600 text-sky-600'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <CheckCircle className="h-4 w-4" />
          Assiduidade & Faltas
        </button>

        <button
          onClick={() => setActiveTabSub('PROPINAS')}
          className={`flex items-center gap-2 border-b-2 px-4 py-2.5 text-xs sm:text-sm font-bold whitespace-nowrap transition-colors ${
            activeTabSub === 'PROPINAS'
              ? 'border-sky-600 text-sky-600'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <CreditCard className="h-4 w-4" />
          Mensalidades & Propinas
          {pendingPayments.length > 0 && (
            <span className="ml-1 rounded-full bg-amber-100 text-amber-800 px-2 py-0.5 text-[10px] font-extrabold">
              {pendingPayments.length} Pendente
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTabSub('AVISOS')}
          className={`flex items-center gap-2 border-b-2 px-4 py-2.5 text-xs sm:text-sm font-bold whitespace-nowrap transition-colors ${
            activeTabSub === 'AVISOS'
              ? 'border-sky-600 text-sky-600'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <Bell className="h-4 w-4" />
          Comunicados da Escola
        </button>
      </div>

      {/* Feedback de Pagamento */}
      {paymentSuccessMsg && (
        <div className="rounded-xl bg-emerald-50 border border-emerald-200 p-3 text-xs font-semibold text-emerald-800 flex items-center gap-2">
          <CheckCircle className="h-4 w-4 text-emerald-600" />
          {paymentSuccessMsg}
        </div>
      )}

      {/* ABA 1: APROVEITAMENTO & NOTAS */}
      {activeTabSub === 'DESEMPENHO' && (
        <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xs">
          <div className="p-4 border-b border-slate-200 font-extrabold text-slate-900 text-sm">
            Boletim Trimestral do Educando • Ano Letivo 2026
          </div>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-left text-xs sm:text-sm">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/80 font-bold text-slate-700">
                  <th className="py-3.5 pl-4 pr-3">Disciplina</th>
                  <th className="px-3 py-3.5 text-center">ACS 1</th>
                  <th className="px-3 py-3.5 text-center">ACS 2</th>
                  <th className="px-3 py-3.5 text-center">ACP</th>
                  <th className="px-3 py-3.5 text-center font-extrabold">Média 1º Trim</th>
                  <th className="py-3.5 pl-3 pr-4 text-center">Aproveitamento</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                {db.subjects.map((sub) => {
                  const grade = studentGrades.find((g) => g.subjectId === sub.id && g.term === 1);
                  const final = grade?.finalGrade ?? 13;
                  const isPositive = final >= 10;

                  return (
                    <tr key={sub.id} className="hover:bg-slate-50/60">
                      <td className="py-3 pl-4 pr-3 font-bold text-slate-900">
                        {sub.name}
                      </td>
                      <td className="px-3 py-3 text-center font-mono">{grade?.acs1 ?? 13}</td>
                      <td className="px-3 py-3 text-center font-mono">{grade?.acs2 ?? 14}</td>
                      <td className="px-3 py-3 text-center font-mono">{grade?.testGrade ?? 12}</td>
                      <td className="px-3 py-3 text-center font-mono font-bold">
                        <span className={isPositive ? 'text-emerald-700' : 'text-rose-600'}>
                          {final} val.
                        </span>
                      </td>
                      <td className="py-3 pl-3 pr-4 text-center">
                        <span
                          className={`inline-flex items-center rounded-md px-2 py-0.5 text-[10px] font-extrabold ${
                            isPositive
                              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                              : 'bg-rose-50 text-rose-700 border border-rose-200'
                          }`}
                        >
                          {isPositive ? 'Positiva' : 'Necessita Apoio'}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ABA 2: ASSIDUIDADE */}
      {activeTabSub === 'ASSIDUIDADE' && (
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs space-y-4">
          <h3 className="font-extrabold text-slate-900 text-sm sm:text-base">
            Registo de Presenças e Controlo de Faltas
          </h3>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <div className="rounded-xl border border-slate-100 bg-slate-50 p-3">
              <span className="text-[11px] font-bold text-slate-500">Total de Faltas Injustificadas</span>
              <p className="text-xl font-extrabold text-slate-900 mt-1">{absencesCount}</p>
            </div>
            <div className="rounded-xl border border-slate-100 bg-slate-50 p-3">
              <span className="text-[11px] font-bold text-slate-500">Faltas Justificadas com Atestado</span>
              <p className="text-xl font-extrabold text-emerald-600 mt-1">1</p>
            </div>
            <div className="rounded-xl border border-slate-100 bg-slate-50 p-3">
              <span className="text-[11px] font-bold text-slate-500">Taxa de Assiduidade Escolar</span>
              <p className="text-xl font-extrabold text-sky-700 mt-1">98%</p>
            </div>
          </div>
        </div>
      )}

      {/* ABA 3: PROPINAS E MENSALIDADES */}
      {activeTabSub === 'PROPINAS' && (
        <div className="space-y-4">
          <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs space-y-3">
            <h3 className="font-extrabold text-slate-900 text-sm sm:text-base">
              Situação Financeira do Educando
            </h3>
            <p className="text-xs text-slate-500">
              Pagamentos de propinas escolares, taxas de matrícula e emissão de recibos oficiais com código de validação.
            </p>

            <div className="overflow-hidden rounded-xl border border-slate-200 mt-3">
              <table className="w-full border-collapse text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50/80 font-bold text-slate-700">
                    <th className="py-3 pl-4 pr-3">Descrição / Mês</th>
                    <th className="px-3 py-3">Valor</th>
                    <th className="px-3 py-3">Vencimento</th>
                    <th className="px-3 py-3">Estado</th>
                    <th className="py-3 pl-3 pr-4 text-right">Ação</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                  {studentPayments.map((pay) => (
                    <tr key={pay.id} className="hover:bg-slate-50/60">
                      <td className="py-3 pl-4 pr-3 font-bold text-slate-900">
                        {pay.title}
                        {pay.receiptNumber && (
                          <p className="text-[10px] text-slate-400 font-mono">Recibo: {pay.receiptNumber}</p>
                        )}
                      </td>

                      <td className="px-3 py-3 font-mono font-bold text-slate-900">
                        {pay.amount.toLocaleString()} MZN
                      </td>

                      <td className="px-3 py-3 text-slate-500">{pay.dueDate}</td>

                      <td className="px-3 py-3">
                        <StatusBadge status={pay.status} />
                      </td>

                      <td className="py-3 pl-3 pr-4 text-right">
                        {pay.status !== 'PAGO' ? (
                          <button
                            onClick={() => handleSimulatePayment(pay.id)}
                            className="inline-flex items-center gap-1 rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-emerald-700 transition-colors shadow-xs"
                          >
                            <Smartphone className="h-3.5 w-3.5" />
                            Pagar via M-Pesa
                          </button>
                        ) : (
                          <span className="text-[11px] font-bold text-emerald-700">
                            Liquidado ({pay.paymentMethod || 'M-Pesa'})
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ABA 4: AVISOS PARA ENCARREGADOS */}
      {activeTabSub === 'AVISOS' && (
        <div className="space-y-3">
          {db.notifications
            .filter((n) => n.targetAudience === 'TODOS' || n.targetAudience === 'ENCARREGADOS')
            .map((n) => (
              <div key={n.id} className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-slate-900 text-sm">{n.title}</h4>
                  <span className="text-[11px] text-slate-400">{n.createdAt}</span>
                </div>
                <p className="mt-1 text-xs text-slate-600 leading-relaxed">{n.message}</p>
                <p className="mt-2 text-[11px] text-slate-400">Origem: {n.authorName || 'Direção da Escola'}</p>
              </div>
            ))}
        </div>
      )}
    </div>
  );
};
