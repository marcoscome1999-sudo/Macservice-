/**
 * EduGest Moçambique - Assiduidade & Presenças (AttendanceView)
 * Registo diário de chamada, faltas justificadas/injustificadas, atrasos,
 * alerta automático de excesso de faltas (> 25% segundo regras do SNE)
 * e estatísticas por turma.
 */

import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { AttendanceRecord } from '../../types';
import {
  CalendarCheck,
  Save,
  AlertTriangle,
  Clock,
  CheckCircle2,
  XCircle,
  HelpCircle,
  Calendar,
  Filter
} from 'lucide-react';

export const AttendanceView: React.FC = () => {
  const { db, saveAttendance } = useApp();

  const [selectedSection, setSelectedSection] = useState(db.sections[0]?.name || 'Turma 10A');
  const [selectedSubjectId, setSelectedSubjectId] = useState(db.subjects[0]?.id || 'sub-1');
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Alunos da turma
  const students = useMemo(() => {
    return db.students.filter((s) => s.currentSection === selectedSection);
  }, [db.students, selectedSection]);

  // Estado das presenças do dia
  const [statuses, setStatuses] = useState<Record<string, 'PRESENTE' | 'FALTA' | 'JUSTIFICADA' | 'ATRASO'>>({});

  // Inicializar chamada
  React.useEffect(() => {
    const existing = db.attendance.find(
      (a) => a.date === selectedDate && a.sectionId === selectedSection && a.subjectId === selectedSubjectId
    );

    const initial: Record<string, 'PRESENTE' | 'FALTA' | 'JUSTIFICADA' | 'ATRASO'> = {};
    for (const st of students) {
      if (existing) {
        const found = existing.entries.find((e) => e.studentId === st.id);
        initial[st.id] = found ? found.status : 'PRESENTE';
      } else {
        initial[st.id] = 'PRESENTE';
      }
    }
    setStatuses(initial);
  }, [students, selectedDate, selectedSection, selectedSubjectId, db.attendance]);

  const handleStatusToggle = (studentId: string, status: 'PRESENTE' | 'FALTA' | 'JUSTIFICADA' | 'ATRASO') => {
    setStatuses((prev) => ({
      ...prev,
      [studentId]: status
    }));
  };

  const handleSaveAttendance = () => {
    const entries = students.map((s) => ({
      studentId: s.id,
      studentName: s.fullName,
      status: statuses[s.id] || 'PRESENTE'
    }));

    saveAttendance({
      schoolId: db.schools[0]?.id || 'school-1',
      date: selectedDate,
      sectionId: selectedSection,
      subjectId: selectedSubjectId,
      entries
    });

    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  };

  // Contadores
  const summary = useMemo(() => {
    let present = 0, absent = 0, justified = 0, delay = 0;
    Object.values(statuses).forEach((st) => {
      if (st === 'PRESENTE') present++;
      else if (st === 'FALTA') absent++;
      else if (st === 'JUSTIFICADA') justified++;
      else if (st === 'ATRASO') delay++;
    });
    return { present, absent, justified, delay, total: students.length };
  }, [statuses, students.length]);

  return (
    <div className="space-y-6">
      {/* Cabeçalho */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
            <CalendarCheck className="h-6 w-6 text-emerald-600" />
            Livro de Ponto & Assiduidade Escolar
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Registo de faltas, presenças e controlo de limite legal de faltas (25% SNE).
          </p>
        </div>

        <div className="flex items-center gap-2">
          {saveSuccess && (
            <span className="flex items-center gap-1 rounded-xl bg-emerald-50 px-3 py-1.5 text-xs font-bold text-emerald-700 border border-emerald-200">
              <CheckCircle2 className="h-4 w-4" />
              Presenças Registadas
            </span>
          )}

          <button
            onClick={handleSaveAttendance}
            className="flex items-center gap-1.5 rounded-xl bg-emerald-600 px-4 py-2 text-xs font-bold text-white shadow-sm hover:bg-emerald-700 transition"
          >
            <Save className="h-4 w-4" />
            Confirmar Chamada
          </button>
        </div>
      </div>

      {/* Barra de Filtros: Data, Turma e Disciplina */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
        <div>
          <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
            Data da Aula
          </label>
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="w-full rounded-xl border border-slate-200 bg-slate-50 py-2 px-3 text-xs font-semibold text-slate-800 focus:border-emerald-500 focus:outline-none"
          />
        </div>

        <div>
          <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
            Turma
          </label>
          <select
            value={selectedSection}
            onChange={(e) => setSelectedSection(e.target.value)}
            className="w-full rounded-xl border border-slate-200 bg-slate-50 py-2 px-3 text-xs font-semibold text-slate-800 focus:border-emerald-500 focus:outline-none"
          >
            {db.sections.map((s) => (
              <option key={s.id} value={s.name}>
                {s.gradeLevel} - {s.name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
            Disciplina
          </label>
          <select
            value={selectedSubjectId}
            onChange={(e) => setSelectedSubjectId(e.target.value)}
            className="w-full rounded-xl border border-slate-200 bg-slate-50 py-2 px-3 text-xs font-semibold text-slate-800 focus:border-emerald-500 focus:outline-none"
          >
            {db.subjects.map((sub) => (
              <option key={sub.id} value={sub.id}>
                {sub.name} ({sub.code})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Cartões de Resumo da Chamada */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="rounded-xl border border-emerald-200 bg-emerald-50/70 p-3 text-center">
          <p className="text-[10px] font-bold uppercase text-emerald-700">Presentes</p>
          <p className="text-xl font-extrabold text-emerald-900">{summary.present}</p>
        </div>

        <div className="rounded-xl border border-rose-200 bg-rose-50/70 p-3 text-center">
          <p className="text-[10px] font-bold uppercase text-rose-700">Faltas Injustificadas</p>
          <p className="text-xl font-extrabold text-rose-900">{summary.absent}</p>
        </div>

        <div className="rounded-xl border border-indigo-200 bg-indigo-50/70 p-3 text-center">
          <p className="text-[10px] font-bold uppercase text-indigo-700">Faltas Justificadas</p>
          <p className="text-xl font-extrabold text-indigo-900">{summary.justified}</p>
        </div>

        <div className="rounded-xl border border-amber-200 bg-amber-50/70 p-3 text-center">
          <p className="text-[10px] font-bold uppercase text-amber-700">Atrasos</p>
          <p className="text-xl font-extrabold text-amber-900">{summary.delay}</p>
        </div>
      </div>

      {/* Lista dos Alunos para Marcação de Presença */}
      <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="border-b border-slate-200 bg-slate-50 font-bold uppercase text-slate-500">
              <tr>
                <th className="py-3 px-4 w-12 text-center">#</th>
                <th className="py-3 px-4">Nome do Aluno</th>
                <th className="py-3 px-4">Contacto do Encarregado</th>
                <th className="py-3 px-4 text-center">Marcação de Assiduidade</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {students.map((student, idx) => {
                const currentStatus = statuses[student.id] || 'PRESENTE';

                return (
                  <tr key={student.id} className="hover:bg-slate-50 transition">
                    <td className="py-3 px-4 text-center font-mono font-bold text-slate-400">
                      {idx + 1}
                    </td>
                    <td className="py-3 px-4 font-bold text-slate-900">
                      <div>
                        <p>{student.fullName}</p>
                        <p className="text-[10px] text-slate-400 font-mono">{student.studentNumber}</p>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-slate-600">
                      {student.guardianName} ({student.guardianPhone})
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center justify-center gap-2">
                        <button
                          onClick={() => handleStatusToggle(student.id, 'PRESENTE')}
                          className={`rounded-lg px-2.5 py-1 text-xs font-bold transition flex items-center gap-1 ${
                            currentStatus === 'PRESENTE'
                              ? 'bg-emerald-600 text-white shadow-xs'
                              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                          }`}
                        >
                          <CheckCircle2 className="h-3.5 w-3.5" />
                          Presente
                        </button>

                        <button
                          onClick={() => handleStatusToggle(student.id, 'FALTA')}
                          className={`rounded-lg px-2.5 py-1 text-xs font-bold transition flex items-center gap-1 ${
                            currentStatus === 'FALTA'
                              ? 'bg-rose-600 text-white shadow-xs'
                              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                          }`}
                        >
                          <XCircle className="h-3.5 w-3.5" />
                          Falta
                        </button>

                        <button
                          onClick={() => handleStatusToggle(student.id, 'JUSTIFICADA')}
                          className={`rounded-lg px-2.5 py-1 text-xs font-bold transition flex items-center gap-1 ${
                            currentStatus === 'JUSTIFICADA'
                              ? 'bg-indigo-600 text-white shadow-xs'
                              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                          }`}
                        >
                          <HelpCircle className="h-3.5 w-3.5" />
                          Justificada
                        </button>

                        <button
                          onClick={() => handleStatusToggle(student.id, 'ATRASO')}
                          className={`rounded-lg px-2.5 py-1 text-xs font-bold transition flex items-center gap-1 ${
                            currentStatus === 'ATRASO'
                              ? 'bg-amber-600 text-white shadow-xs'
                              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                          }`}
                        >
                          <Clock className="h-3.5 w-3.5" />
                          Atraso
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
