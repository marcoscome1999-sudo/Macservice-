/**
 * EduGest Moçambique - Gestão de Propinas & Pagamentos (FinanceView)
 * Moeda oficial: Meticais (MT).
 * Formas de pagamento nacionais: M-Pesa, e-Mola, Transferência bancária
 * (Millennium BIM, BCI, Standard Bank, Moza Banco), POS / Cartão e Numerário.
 * Emissão de recibos oficiais numerados, controlo de dívidas e lembretes de cobrança.
 */

import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { PaymentItem } from '../../types';
import {
  Wallet,
  Plus,
  Search,
  CheckCircle2,
  Clock,
  AlertCircle,
  Printer,
  Smartphone,
  CreditCard,
  Send,
  Download,
  Filter,
  X
} from 'lucide-react';
import { StatusBadge } from '../common/StatusBadge';
import { Pagination } from '../common/Pagination';
import { EmptyState } from '../common/EmptyState';

export const FinanceView: React.FC = () => {
  const { db, recordPayment, createNewCharge, sendNotification, currentSchool } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<'ALL' | 'PAGO' | 'PENDENTE' | 'ATRASADO'>('ALL');
  const [selectedMethodFilter, setSelectedMethodFilter] = useState('ALL');

  // Paginação
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  // Modais
  const [isPayModalOpen, setIsPayModalOpen] = useState(false);
  const [selectedItemToPay, setSelectedItemToPay] = useState<PaymentItem | null>(null);
  const [payMethod, setPayMethod] = useState<PaymentItem['paymentMethod']>('M-PESA');
  const [transactionRef, setTransactionRef] = useState('');

  const [isNewChargeModalOpen, setIsNewChargeModalOpen] = useState(false);
  const [chargeForm, setChargeForm] = useState<Omit<PaymentItem, 'id'>>({
    schoolId: db.schools[0]?.id || 'school-1',
    studentId: db.students[0]?.id || 'std-1',
    studentName: db.students[0]?.fullName || 'Aluno',
    gradeLevel: '10ª Classe',
    feeType: 'PROPINA_MENSAL',
    amount: 3500,
    dueDate: '2026-04-10',
    status: 'PENDENTE',
    monthRef: 'Abril/2026'
  });

  const [receiptToPrint, setReceiptToPrint] = useState<PaymentItem | null>(null);
  const [reminderSentMessage, setReminderSentMessage] = useState<string | null>(null);

  // Lista Filtrada
  const filteredPayments = useMemo(() => {
    return db.payments.filter((p) => {
      const matchSearch =
        p.studentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (p.receiptNumber && p.receiptNumber.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (p.transactionRef && p.transactionRef.toLowerCase().includes(searchTerm.toLowerCase()));

      const matchStatus = selectedStatus === 'ALL' || p.status === selectedStatus;
      const matchMethod = selectedMethodFilter === 'ALL' || p.paymentMethod === selectedMethodFilter;

      return matchSearch && matchStatus && matchMethod;
    });
  }, [db.payments, searchTerm, selectedStatus, selectedMethodFilter]);

  // Resetar página quando filtros mudam
  React.useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, selectedStatus, selectedMethodFilter]);

  const totalPages = Math.ceil(filteredPayments.length / pageSize) || 1;
  const paginatedPayments = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredPayments.slice(start, start + pageSize);
  }, [filteredPayments, currentPage, pageSize]);

  // Estatísticas Financeiras
  const stats = useMemo(() => {
    let paidMT = 0;
    let pendingMT = 0;
    let overdueMT = 0;

    db.payments.forEach((p) => {
      if (p.status === 'PAGO') paidMT += p.amount;
      else if (p.status === 'PENDENTE') pendingMT += p.amount;
      else if (p.status === 'ATRASADO') overdueMT += p.amount;
    });

    const totalExpected = paidMT + pendingMT + overdueMT;
    const recoveryRate = totalExpected > 0 ? Math.round((paidMT / totalExpected) * 100) : 100;

    return { paidMT, pendingMT, overdueMT, totalExpected, recoveryRate };
  }, [db.payments]);

  // Confirmar Pagamento
  const handleConfirmPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedItemToPay) return;

    recordPayment(selectedItemToPay.id, payMethod, transactionRef);
    setIsPayModalOpen(false);
    setSelectedItemToPay(null);
    setTransactionRef('');
  };

  // Criar Novo Encargo
  const handleSaveCharge = (e: React.FormEvent) => {
    e.preventDefault();
    const student = db.students.find((s) => s.id === chargeForm.studentId);
    createNewCharge({
      ...chargeForm,
      studentName: student?.fullName || chargeForm.studentName,
      gradeLevel: student?.currentClass || chargeForm.gradeLevel
    });
    setIsNewChargeModalOpen(false);
  };

  // Enviar Lembrete de Cobrança por SMS/WhatsApp
  const handleSendReminder = (item: PaymentItem) => {
    sendNotification({
      schoolId: currentSchool.id,
      title: `Aviso de Cobrança: ${item.feeType} (${item.monthRef || 'Vencimento'})`,
      body: `Prezado(a) encarregado(a) de ${item.studentName}, informamos que o pagamento no valor de ${item.amount.toLocaleString('pt-MZ')} MT encontra-se pendente. Pode liquidar via M-Pesa ou e-Mola usando o número da escola.`,
      targetAudience: 'ENCARREGADOS',
      channel: 'SMS',
      category: 'FINANCEIRO'
    });

    setReminderSentMessage(`Notificação de cobrança enviada com sucesso para o encarregado de ${item.studentName}.`);
    setTimeout(() => setReminderSentMessage(null), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Cabeçalho */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
            <Wallet className="h-6 w-6 text-emerald-600" />
            Propinas, Taxas & Tesouraria Escolar
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Valores em Meticais (MT) • M-Pesa, e-Mola, Transferências Bancárias (BIM, BCI, Standard Bank) e POS.
          </p>
        </div>

        <button
          onClick={() => setIsNewChargeModalOpen(true)}
          className="flex items-center gap-1.5 rounded-xl bg-emerald-600 px-3.5 py-2 text-xs font-bold text-white shadow-sm hover:bg-emerald-700 transition"
        >
          <Plus className="h-4 w-4" />
          Lançar Nova Cobrança
        </button>
      </div>

      {reminderSentMessage && (
        <div className="rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-xs font-bold text-emerald-800 flex items-center gap-2">
          <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0" />
          {reminderSentMessage}
        </div>
      )}

      {/* Cartões Financeiros Principais (Valores em MT) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="rounded-lg border border-slate-200 bg-white p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase tracking-wider">Total Cobrado / Pago</span>
            <Wallet className="h-4 w-4 text-emerald-600" />
          </div>
          <p className="mt-2 text-2xl font-bold text-slate-900 tracking-tight">
            {stats.paidMT.toLocaleString('pt-MZ')} MT
          </p>
          <div className="mt-2 flex items-center justify-between text-[11px] text-slate-500 pt-2 border-t border-slate-100">
            <span className="text-emerald-700 font-semibold">{stats.recoveryRate}% arrecadado</span>
            <span>Meta atingida</span>
          </div>
        </div>

        <div className="rounded-lg border border-slate-200 bg-white p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase tracking-wider">Pendente a Vencer</span>
            <Clock className="h-4 w-4 text-amber-500" />
          </div>
          <p className="mt-2 text-2xl font-bold text-slate-900 tracking-tight">
            {stats.pendingMT.toLocaleString('pt-MZ')} MT
          </p>
          <div className="mt-2 flex items-center justify-between text-[11px] text-slate-500 pt-2 border-t border-slate-100">
            <span>Prazo regular</span>
            <span className="text-slate-600 font-medium">Aguardando termo</span>
          </div>
        </div>

        <div className="rounded-lg border border-slate-200 bg-white p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase tracking-wider">Dívidas em Atraso</span>
            <AlertCircle className="h-4 w-4 text-rose-500" />
          </div>
          <p className="mt-2 text-2xl font-bold text-rose-700 tracking-tight">
            {stats.overdueMT.toLocaleString('pt-MZ')} MT
          </p>
          <div className="mt-2 flex items-center justify-between text-[11px] text-slate-500 pt-2 border-t border-slate-100">
            <span className="text-rose-600 font-medium">Cobrança activa</span>
            <button
              onClick={() => setSelectedStatus('ATRASADO')}
              className="text-slate-700 font-semibold hover:underline"
            >
              Filtrar atrasos
            </button>
          </div>
        </div>

        <div className="rounded-lg border border-slate-200 bg-white p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase tracking-wider">Canais de Liquidação</span>
            <CreditCard className="h-4 w-4 text-slate-400" />
          </div>
          <div className="mt-2 flex items-center gap-2">
            <span className="rounded bg-slate-100 px-2 py-0.5 text-xs font-bold text-slate-800 border border-slate-200">
              M-Pesa 65%
            </span>
            <span className="rounded bg-slate-100 px-2 py-0.5 text-xs font-bold text-slate-800 border border-slate-200">
              e-Mola 20%
            </span>
          </div>
          <div className="mt-2 flex items-center justify-between text-[11px] text-slate-500 pt-2 border-t border-slate-100">
            <span>Bancos BIM / BCI / SB</span>
            <span className="text-slate-700 font-medium">POS 15%</span>
          </div>
        </div>
      </div>

      {/* Filtros e Pesquisa */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 rounded-lg border border-slate-200 bg-white p-4 shadow-xs">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Pesquisar por aluno, nº de recibo ou referência de transação..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full rounded-md border border-slate-200 py-2 pl-9 pr-4 text-xs text-slate-800 placeholder-slate-400 focus:border-slate-400 focus:outline-none"
          />
        </div>

        <div className="flex items-center gap-2">
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value as any)}
            className="rounded-md border border-slate-200 bg-slate-50 py-2 px-3 text-xs font-semibold text-slate-700 focus:border-slate-400 focus:outline-none"
          >
            <option value="ALL">Todos os Estados</option>
            <option value="PAGO">Pagos</option>
            <option value="PENDENTE">Pendentes</option>
            <option value="ATRASADO">Em Atraso</option>
          </select>

          <select
            value={selectedMethodFilter}
            onChange={(e) => setSelectedMethodFilter(e.target.value)}
            className="rounded-md border border-slate-200 bg-slate-50 py-2 px-3 text-xs font-semibold text-slate-700 focus:border-slate-400 focus:outline-none"
          >
            <option value="ALL">Todas as Formas</option>
            <option value="M-PESA">M-Pesa</option>
            <option value="E-MOLA">e-Mola</option>
            <option value="TRANSFERENCIA_BANCARIA">Transferência Bancária</option>
            <option value="POS">POS / Cartão</option>
            <option value="NUMERARIO">Numerário</option>
          </select>
        </div>
      </div>

      {/* Tabela Financeira */}
      <div className="overflow-hidden rounded-lg border border-slate-200 bg-white shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600">
            <thead className="border-b border-slate-200 bg-slate-50 font-bold uppercase tracking-wider text-slate-500">
              <tr>
                <th className="py-3 px-4">Aluno / Classe</th>
                <th className="py-3 px-4">Conceito / Taxa</th>
                <th className="py-3 px-4">Referência / Mês</th>
                <th className="py-3 px-4">Vencimento</th>
                <th className="py-3 px-4">Valor (MT)</th>
                <th className="py-3 px-4">Forma & Recibo</th>
                <th className="py-3 px-4">Estado</th>
                <th className="py-3 px-4 text-center">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredPayments.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-4">
                    <EmptyState
                      title="Nenhum registo financeiro encontrado"
                      description="Não há cobranças ou pagamentos correspondentes aos filtros selecionados."
                      actionLabel="Lançar Nova Cobrança"
                      onAction={() => setIsNewChargeModalOpen(true)}
                    />
                  </td>
                </tr>
              ) : (
                paginatedPayments.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-50/80 transition">
                    <td className="py-3 px-4 font-bold text-slate-900">
                      <p>{item.studentName}</p>
                      <p className="text-[10px] text-slate-400 font-normal">{item.gradeLevel}</p>
                    </td>
                    <td className="py-3 px-4 font-medium text-slate-800">
                      {item.feeType.replace('_', ' ')}
                    </td>
                    <td className="py-3 px-4 text-slate-600">
                      {item.monthRef || 'Taxa Única'}
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-600">
                      {item.dueDate}
                    </td>
                    <td className="py-3 px-4 font-bold text-slate-900 text-sm">
                      {item.amount.toLocaleString('pt-MZ')} MT
                    </td>
                    <td className="py-3 px-4">
                      {item.status === 'PAGO' ? (
                        <div>
                          <span className="font-semibold text-emerald-800">{item.paymentMethod}</span>
                          {item.receiptNumber && (
                            <span className="block font-mono text-[10px] text-slate-400">
                              {item.receiptNumber}
                            </span>
                          )}
                        </div>
                      ) : (
                        <span className="text-slate-400 italic">A aguardar liquidação</span>
                      )}
                    </td>
                    <td className="py-3 px-4">
                      <StatusBadge status={item.status} size="sm" />
                    </td>
                    <td className="py-3 px-4 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        {item.status !== 'PAGO' ? (
                          <>
                            <button
                              onClick={() => {
                                setSelectedItemToPay(item);
                                setIsPayModalOpen(true);
                              }}
                              className="rounded bg-slate-900 px-2.5 py-1 font-semibold text-white text-[11px] hover:bg-slate-800 shadow-xs transition"
                            >
                              Liquidar
                            </button>
                            <button
                              onClick={() => handleSendReminder(item)}
                              className="rounded border border-slate-200 p-1 text-slate-600 hover:bg-slate-100 transition"
                              title="Enviar Lembrete por SMS/WhatsApp"
                            >
                              <Send className="h-3.5 w-3.5" />
                            </button>
                          </>
                        ) : (
                          <button
                            onClick={() => setReceiptToPrint(item)}
                            className="rounded border border-slate-200 px-2 py-1 text-slate-700 font-semibold text-[11px] hover:bg-slate-100 flex items-center gap-1 transition"
                          >
                            <Printer className="h-3.5 w-3.5 text-slate-500" />
                            Recibo
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Paginação */}
        {filteredPayments.length > 0 && (
          <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            totalItems={filteredPayments.length}
            pageSize={pageSize}
            onPageChange={setCurrentPage}
            onPageSizeChange={(newSize) => {
              setPageSize(newSize);
              setCurrentPage(1);
            }}
            itemLabel="registos"
          />
        )}
      </div>

      {/* MODAL 1: CONFIRMAR PAGAMENTO */}
      {isPayModalOpen && selectedItemToPay && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
          <div className="relative w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-4">
              <h3 className="font-extrabold text-slate-900 text-base flex items-center gap-2">
                <Smartphone className="h-5 w-5 text-emerald-600" />
                Registar Pagamento em Meticais (MT)
              </h3>
              <button onClick={() => setIsPayModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleConfirmPayment} className="space-y-4 text-xs">
              <div className="rounded-xl border border-slate-200 bg-slate-50 p-3">
                <p><strong>Aluno:</strong> {selectedItemToPay.studentName}</p>
                <p><strong>Encargo:</strong> {selectedItemToPay.feeType} ({selectedItemToPay.monthRef || 'Taxa'})</p>
                <p className="text-sm font-extrabold text-emerald-800 mt-1">
                  Valor a Pagar: {selectedItemToPay.amount.toLocaleString('pt-MZ')} MT
                </p>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Forma de Pagamento *</label>
                <div className="grid grid-cols-2 gap-2">
                  {(
                    [
                      { id: 'M-PESA', label: 'M-Pesa (Vodacom)' },
                      { id: 'E-MOLA', label: 'e-Mola (Movitel)' },
                      { id: 'TRANSFERENCIA_BANCARIA', label: 'BIM / BCI / Standard' },
                      { id: 'POS', label: 'Cartão / POS' },
                      { id: 'NUMERARIO', label: 'Numerário / Caixa' }
                    ] as const
                  ).map((m) => (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => setPayMethod(m.id)}
                      className={`rounded-xl border p-2 text-left font-bold transition text-xs ${
                        payMethod === m.id
                          ? 'border-emerald-600 bg-emerald-50 text-emerald-900'
                          : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      {m.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Referência da Transação / Comprovativo
                </label>
                <input
                  type="text"
                  value={transactionRef}
                  onChange={(e) => setTransactionRef(e.target.value)}
                  placeholder="Ex: MPESA-7B8A91 ou Talão Bancário"
                  className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-emerald-500 focus:outline-none font-mono"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsPayModalOpen(false)}
                  className="rounded-xl bg-slate-100 px-4 py-2 font-bold text-slate-700 hover:bg-slate-200"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-emerald-600 px-5 py-2 font-bold text-white hover:bg-emerald-700 shadow-sm"
                >
                  Confirmar Pagamento & Gerar Recibo
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: LANÇAR NOVA COBRANÇA */}
      {isNewChargeModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
          <div className="relative w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-4">
              <h3 className="font-extrabold text-slate-900 text-base flex items-center gap-2">
                <Plus className="h-5 w-5 text-emerald-600" />
                Lançar Cobrança Escolar
              </h3>
              <button onClick={() => setIsNewChargeModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSaveCharge} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Aluno Beneficiário *</label>
                <select
                  value={chargeForm.studentId}
                  onChange={(e) => setChargeForm({ ...chargeForm, studentId: e.target.value })}
                  className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-emerald-500 focus:outline-none"
                >
                  {db.students.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.fullName} ({s.studentNumber} - {s.currentClass})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Tipo de Taxa *</label>
                  <select
                    value={chargeForm.feeType}
                    onChange={(e) => setChargeForm({ ...chargeForm, feeType: e.target.value as any })}
                    className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-emerald-500 focus:outline-none"
                  >
                    <option value="PROPINA_MENSAL">Propina Mensal</option>
                    <option value="MATRICULA">Taxa de Matrícula</option>
                    <option value="EXAME">Taxa de Exame</option>
                    <option value="CERTIFICADO">Certificado</option>
                    <option value="UNIFORME">Uniforme & Material</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Mês de Referência</label>
                  <input
                    type="text"
                    value={chargeForm.monthRef || ''}
                    onChange={(e) => setChargeForm({ ...chargeForm, monthRef: e.target.value })}
                    placeholder="ex: Maio/2026"
                    className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-emerald-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Valor em Meticais (MT) *</label>
                  <input
                    type="number"
                    required
                    min={50}
                    value={chargeForm.amount}
                    onChange={(e) => setChargeForm({ ...chargeForm, amount: Number(e.target.value) })}
                    className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-emerald-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Data de Vencimento *</label>
                  <input
                    type="date"
                    required
                    value={chargeForm.dueDate}
                    onChange={(e) => setChargeForm({ ...chargeForm, dueDate: e.target.value })}
                    className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-emerald-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-4 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsNewChargeModalOpen(false)}
                  className="rounded-xl bg-slate-100 px-4 py-2 font-bold text-slate-700 hover:bg-slate-200 text-xs"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-emerald-600 px-5 py-2 font-bold text-white hover:bg-emerald-700 text-xs shadow-sm"
                >
                  Gerar Cobrança
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: RECIBO OFICIAL IMPRESSO */}
      {receiptToPrint && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
          <div className="relative w-full max-w-lg rounded-2xl bg-white p-8 shadow-2xl print:border-none print:shadow-none">
            <div className="border-b-2 border-slate-900 pb-4 text-center">
              <h4 className="font-extrabold text-sm uppercase tracking-wider text-slate-900">
                REPÚBLICA DE MOÇAMBIQUE
              </h4>
              <p className="text-xs font-bold text-slate-700 uppercase">{currentSchool.name}</p>
              <p className="text-[10px] text-slate-500">NUIT: {currentSchool.nuit} • {currentSchool.province}</p>
              <div className="mt-2 inline-block rounded-md bg-emerald-100 px-3 py-0.5 text-xs font-extrabold text-emerald-900 uppercase">
                RECIBO OFICIAL DE QUITAÇÃO
              </div>
            </div>

            <div className="my-5 space-y-2 text-xs text-slate-800">
              <div className="flex justify-between border-b border-slate-100 pb-1">
                <span>Número do Recibo:</span>
                <strong className="font-mono text-emerald-800">{receiptToPrint.receiptNumber}</strong>
              </div>
              <div className="flex justify-between border-b border-slate-100 pb-1">
                <span>Data de Emissão:</span>
                <strong>{receiptToPrint.paidDate}</strong>
              </div>
              <div className="flex justify-between border-b border-slate-100 pb-1">
                <span>Recebemos de:</span>
                <strong>{receiptToPrint.studentName}</strong>
              </div>
              <div className="flex justify-between border-b border-slate-100 pb-1">
                <span>Referente a:</span>
                <strong>{receiptToPrint.feeType} ({receiptToPrint.monthRef || 'Taxa'})</strong>
              </div>
              <div className="flex justify-between border-b border-slate-100 pb-1">
                <span>Forma de Pagamento:</span>
                <strong>{receiptToPrint.paymentMethod} (Ref: {receiptToPrint.transactionRef})</strong>
              </div>
              <div className="flex justify-between pt-2 text-sm font-extrabold text-slate-950">
                <span>Total Liquidado:</span>
                <span className="text-emerald-800">{receiptToPrint.amount.toLocaleString('pt-MZ')} MT</span>
              </div>
            </div>

            <div className="mt-8 border-t border-slate-300 pt-4 text-center text-xs text-slate-600">
              <p>Processado por Sistema EduGest Moçambique • Assinatura e Carimbo da Tesouraria</p>
              <div className="mt-6 flex justify-between gap-2 no-print">
                <button
                  onClick={() => setReceiptToPrint(null)}
                  className="rounded-xl bg-slate-100 px-4 py-2 font-bold text-slate-700 hover:bg-slate-200"
                >
                  Fechar
                </button>
                <button
                  onClick={() => window.print()}
                  className="rounded-xl bg-emerald-600 px-5 py-2 font-bold text-white hover:bg-emerald-700 flex items-center gap-1.5"
                >
                  <Printer className="h-4 w-4" />
                  Imprimir Recibo
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
