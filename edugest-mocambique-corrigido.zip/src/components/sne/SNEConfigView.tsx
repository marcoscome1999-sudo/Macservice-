/**
 * EduGest Moçambique - Configurações do Sistema Nacional de Educação (SNEConfigView)
 * Permite adaptar classes, ciclos de aprendizagem, fórmulas de cálculo de notas,
 * pesos de avaliações (MPT vs ACP), nota mínima de aprovação, dispensa de exames
 * e regras oficiais conforme alterações deliberadas pelo MINEDH.
 */

import React, { useState, useEffect, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { SNEConfig } from '../../types';
import {
  Settings2,
  Save,
  Sliders,
  Award,
  BookOpen,
  Scale,
  CheckCircle2,
  RotateCcw,
  AlertCircle
} from 'lucide-react';

export const SNEConfigView: React.FC = () => {
  const { sneConfig, updateSNEConfig } = useApp();

  const safeInitial: SNEConfig = useMemo(() => ({
    academicYear: sneConfig?.academicYear ?? 2026,
    currentTerm: sneConfig?.currentTerm ?? 1,
    minGrade: sneConfig?.minGrade ?? 0,
    maxGrade: sneConfig?.maxGrade ?? 20,
    passingGrade: sneConfig?.passingGrade ?? 10,
    minPassingGrade: sneConfig?.minPassingGrade ?? 10,
    termsCount: sneConfig?.termsCount ?? 3,
    evaluationFormula: sneConfig?.evaluationFormula ?? 'STANDARD_MINEDH',
    maxAbsencePercentage: sneConfig?.maxAbsencePercentage ?? 25,
    examExemptionGrade: sneConfig?.examExemptionGrade ?? 14,
    examAdmissionGrade: sneConfig?.examAdmissionGrade ?? 10,
    gradingFormula: sneConfig?.gradingFormula ?? 'MT = (MPT * 0.4) + (ACP * 0.6)',
    mptWeight: sneConfig?.mptWeight ?? 0.4,
    acpWeight: sneConfig?.acpWeight ?? 0.6,
    allowGradeEditingAfterLock: sneConfig?.allowGradeEditingAfterLock ?? false,
    levels: sneConfig?.levels ?? []
  }), [sneConfig]);

  const [formConfig, setFormConfig] = useState<SNEConfig>(safeInitial);
  const [saveSuccess, setSaveSuccess] = useState(false);

  useEffect(() => {
    if (sneConfig) {
      setFormConfig(safeInitial);
    }
  }, [sneConfig, safeInitial]);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateSNEConfig(formConfig);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  const handleResetDefaults = () => {
    const defaults: SNEConfig = {
      ...(sneConfig || {}),
      academicYear: 2026,
      currentTerm: 1,
      minGrade: 0,
      maxGrade: 20,
      passingGrade: 10,
      minPassingGrade: 10,
      termsCount: 3,
      evaluationFormula: 'STANDARD_MINEDH',
      levels: sneConfig?.levels || [],
      examExemptionGrade: 14,
      examAdmissionGrade: 10,
      gradingFormula: 'MT = (MPT * 0.4) + (ACP * 0.6)',
      mptWeight: 0.4,
      acpWeight: 0.6,
      maxAbsencePercentage: 25,
      allowGradeEditingAfterLock: false
    };
    setFormConfig(defaults);
    updateSNEConfig(defaults);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  return (
    <div className="space-y-6">
      {/* Cabeçalho */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
            <Settings2 className="h-6 w-6 text-sky-600" />
            Configuração do Sistema Nacional de Educação (SNE)
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Regulamento oficial do MINEDH • Ciclos, Fórmulas de Avaliação, Exames e Assiduidade.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {saveSuccess && (
            <span className="flex items-center gap-1 rounded-xl bg-emerald-50 px-3 py-1.5 text-xs font-bold text-emerald-700 border border-emerald-200">
              <CheckCircle2 className="h-4 w-4" />
              Regras Atualizadas
            </span>
          )}

          <button
            type="button"
            onClick={handleResetDefaults}
            className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-bold text-slate-700 hover:bg-slate-50 transition"
          >
            <RotateCcw className="h-4 w-4 text-slate-500" />
            Repor Padrão MINEDH
          </button>
        </div>
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* Bloco 1: Escala e Critérios de Aprovação */}
        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-xs space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
            <Scale className="h-5 w-5 text-sky-600" />
            <h3 className="text-sm font-extrabold text-slate-900">
              Escala de Avaliação e Limiares de Aprovação
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 text-xs">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Nota Mínima da Escala</label>
              <input
                type="number"
                min={0}
                max={20}
                value={formConfig?.minGrade ?? 0}
                onChange={(e) => setFormConfig({ ...formConfig, minGrade: Number(e.target.value) })}
                className="w-full rounded-xl border border-slate-300 p-2 font-mono font-bold"
              />
              <span className="text-[10px] text-slate-400">Padrão moçambicano: 0 valores</span>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Nota Máxima da Escala</label>
              <input
                type="number"
                min={10}
                max={20}
                value={formConfig?.maxGrade ?? 20}
                onChange={(e) => setFormConfig({ ...formConfig, maxGrade: Number(e.target.value) })}
                className="w-full rounded-xl border border-slate-300 p-2 font-mono font-bold"
              />
              <span className="text-[10px] text-slate-400">Padrão moçambicano: 20 valores</span>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Nota Mínima de Transição (Aprovação)</label>
              <input
                type="number"
                min={8}
                max={15}
                value={formConfig?.passingGrade ?? 10}
                onChange={(e) => setFormConfig({ ...formConfig, passingGrade: Number(e.target.value) })}
                className="w-full rounded-xl border border-slate-300 p-2 font-mono font-bold text-emerald-800"
              />
              <span className="text-[10px] text-slate-400">Média mínima legal: 10 valores</span>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Dispensa aos Exames Nacionais</label>
              <input
                type="number"
                min={10}
                max={20}
                value={formConfig?.examExemptionGrade ?? 14}
                onChange={(e) => setFormConfig({ ...formConfig, examExemptionGrade: Number(e.target.value) })}
                className="w-full rounded-xl border border-slate-300 p-2 font-mono font-bold text-sky-800"
              />
              <span className="text-[10px] text-slate-400">Dispensa oficial: 14 valores</span>
            </div>
          </div>
        </div>

        {/* Bloco 2: Fórmula Trimestral e Pesos Ponderados */}
        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-xs space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
            <Sliders className="h-5 w-5 text-emerald-600" />
            <h3 className="text-sm font-extrabold text-slate-900">
              Ponderação da Média Trimestral (MT)
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Peso MPT (Avaliações Contínuas / ACS)
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  step="0.05"
                  min="0"
                  max="1"
                  value={formConfig?.mptWeight ?? 0.4}
                  onChange={(e) => {
                    const mpt = Number(e.target.value);
                    setFormConfig({ ...formConfig, mptWeight: mpt, acpWeight: Number((1 - mpt).toFixed(2)) });
                  }}
                  className="w-full rounded-xl border border-slate-300 p-2 font-mono font-bold"
                />
                <span className="font-bold text-slate-500">({Math.round((formConfig?.mptWeight ?? 0.4) * 100)}%)</span>
              </div>
              <span className="text-[10px] text-slate-400">Regra nacional: 40%</span>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Peso ACP (Avaliação de Controlo Periódico)
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  step="0.05"
                  min="0"
                  max="1"
                  value={formConfig?.acpWeight ?? 0.6}
                  onChange={(e) => {
                    const acp = Number(e.target.value);
                    setFormConfig({ ...formConfig, acpWeight: acp, mptWeight: Number((1 - acp).toFixed(2)) });
                  }}
                  className="w-full rounded-xl border border-slate-300 p-2 font-mono font-bold"
                />
                <span className="font-bold text-slate-500">({Math.round((formConfig?.acpWeight ?? 0.6) * 100)}%)</span>
              </div>
              <span className="text-[10px] text-slate-400">Regra nacional: 60%</span>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Limite Legal de Faltas (%)
              </label>
              <input
                type="number"
                min="10"
                max="50"
                value={formConfig?.maxAbsencePercentage ?? 25}
                onChange={(e) => setFormConfig({ ...formConfig, maxAbsencePercentage: Number(e.target.value) })}
                className="w-full rounded-xl border border-slate-300 p-2 font-mono font-bold text-rose-800"
              />
              <span className="text-[10px] text-slate-400">Acima de 25% = Excluído por faltas</span>
            </div>
          </div>

          <div className="rounded-xl border border-emerald-200 bg-emerald-50/70 p-3 text-xs text-emerald-900">
            <strong>Fórmula em Vigor: </strong>
            <span className="font-mono font-extrabold">
              MT = (MPT × {formConfig?.mptWeight ?? 0.4}) + (ACP × {formConfig?.acpWeight ?? 0.6})
            </span>
          </div>
        </div>

        {/* Bloco 3: Estrutura dos Ciclos do Ensino Geral */}
        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-xs space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
            <BookOpen className="h-5 w-5 text-indigo-600" />
            <h3 className="text-sm font-extrabold text-slate-900">
              Estrutura de Ciclos e Exames Nacionais
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="rounded-xl border border-slate-200 p-3 bg-slate-50">
              <h4 className="font-extrabold text-slate-900 uppercase text-[11px] mb-2">
                Ensino Primário (1ª à 6ª Classe)
              </h4>
              <ul className="space-y-1.5 text-slate-600">
                <li>• 1º Ciclo: 1ª e 2ª classes (progressão normal)</li>
                <li>• 2º Ciclo: 3ª, 4ª e 5ª classes</li>
                <li>• 3º Ciclo: 6ª classe (exame de conclusão)</li>
              </ul>
            </div>

            <div className="rounded-xl border border-slate-200 p-3 bg-slate-50">
              <h4 className="font-extrabold text-slate-900 uppercase text-[11px] mb-2">
                Ensino Secundário Geral (7ª à 12ª Classe)
              </h4>
              <ul className="space-y-1.5 text-slate-600">
                <li>• 1º Ciclo do ESG: 7ª, 8ª e 9ª classes</li>
                <li>• 2º Ciclo do ESG: 10ª, 11ª e 12ª classes</li>
                <li>• Exames Nacionais: 10ª Classe e 12ª Classe</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="flex justify-end pt-2">
          <button
            type="submit"
            className="flex items-center gap-2 rounded-xl bg-sky-600 px-6 py-2.5 text-xs font-bold text-white hover:bg-sky-700 shadow-sm transition"
          >
            <Save className="h-4 w-4" />
            Gravar Configurações do SNE
          </button>
        </div>
      </form>
    </div>
  );
};
