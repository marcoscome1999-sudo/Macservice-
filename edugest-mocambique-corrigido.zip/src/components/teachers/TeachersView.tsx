/**
 * EduGest Moçambique - Gestão de Professores (TeachersView)
 * Registo de docentes, formações pedagógicas (UP, UEM, etc.),
 * alocação de disciplinas, turmas e acompanhamento da carga horária.
 */

import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { Teacher } from '../../types';
import {
  GraduationCap,
  UserPlus,
  Search,
  BookOpen,
  Phone,
  Mail,
  Award,
  Clock,
  Layers,
  CheckCircle2,
  X
} from 'lucide-react';

export const TeachersView: React.FC = () => {
  const { db, addTeacher, updateTeacher } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedTeacher, setSelectedTeacher] = useState<Teacher | null>(null);

  const [formData, setFormData] = useState<Omit<Teacher, 'id'>>({
    schoolId: db.schools[0]?.id || 'school-1',
    employeeNumber: `PROF-2026-${Math.floor(100 + Math.random() * 900)}`,
    fullName: '',
    gender: 'M',
    birthDate: '1985-05-15',
    phone: '+258 84 ',
    email: '',
    academicDegree: 'Licenciatura em Ensino',
    institutionGraduated: 'Universidade Pedagógica de Moçambique (UP)',
    subjects: ['Matemática'],
    assignedSections: ['Turma 10A'],
    weeklyHours: 24,
    hireDate: '2020-02-01',
    status: 'ACTIVO'
  });

  const filteredTeachers = useMemo(() => {
    return (db.teachers || []).filter(
      (t) => {
        const nameMatch = (t.fullName || '').toLowerCase().includes(searchTerm.toLowerCase());
        const numMatch = (t.employeeNumber || '').toLowerCase().includes(searchTerm.toLowerCase());
        const teacherSubjects = t.assignedSubjects || t.subjects || [];
        const subMatch = teacherSubjects.some((sub) => (sub || '').toLowerCase().includes(searchTerm.toLowerCase()));
        return nameMatch || numMatch || subMatch;
      }
    );
  }, [db.teachers, searchTerm]);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.fullName.trim()) return;

    addTeacher(formData);
    setIsModalOpen(false);
    setFormData({
      schoolId: db.schools[0]?.id || 'school-1',
      employeeNumber: `PROF-2026-${Math.floor(100 + Math.random() * 900)}`,
      fullName: '',
      gender: 'M',
      birthDate: '1985-05-15',
      phone: '+258 84 ',
      email: '',
      academicDegree: 'Licenciatura em Ensino',
      institutionGraduated: 'Universidade Pedagógica de Moçambique (UP)',
      subjects: ['Matemática'],
      assignedSections: ['Turma 10A'],
      weeklyHours: 24,
      hireDate: '2020-02-01',
      status: 'ACTIVO'
    });
  };

  return (
    <div className="space-y-6">
      {/* Cabeçalho */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
            <GraduationCap className="h-6 w-6 text-emerald-600" />
            Corpo Docente & Professores
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Formação académica, alocação de disciplinas curriculares e carga horária semanal.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-1.5 rounded-xl bg-emerald-600 px-3.5 py-2 text-xs font-bold text-white shadow-sm hover:bg-emerald-700 transition"
        >
          <UserPlus className="h-4 w-4" />
          Cadastrar Docente
        </button>
      </div>

      {/* Barra de Pesquisa */}
      <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
        <div className="relative">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Pesquisar por nome, nº de funcionário ou disciplina leccionada..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full rounded-xl border border-slate-200 py-2 pl-9 pr-4 text-xs text-slate-800 placeholder-slate-400 focus:border-emerald-500 focus:outline-none"
          />
        </div>
      </div>

      {/* Cartões dos Professores */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredTeachers.map((teacher) => (
          <div
            key={teacher.id}
            className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs hover:border-emerald-300 transition flex flex-col justify-between"
          >
            <div>
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2.5">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-100 text-emerald-800 font-extrabold text-sm">
                    {teacher.fullName.charAt(0)}
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900 text-sm leading-tight">{teacher.fullName}</h3>
                    <p className="font-mono text-[11px] text-emerald-700 font-bold">{teacher.employeeNumber}</p>
                  </div>
                </div>
                <span className="rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-bold text-emerald-700 border border-emerald-200">
                  {teacher.status}
                </span>
              </div>

              <div className="space-y-2 border-t border-slate-100 pt-3 text-xs text-slate-600">
                <div className="flex items-center gap-2">
                  <Award className="h-3.5 w-3.5 text-slate-400" />
                  <span className="font-medium text-slate-800">{teacher.academicDegree}</span>
                </div>
                <p className="text-[11px] text-slate-500 pl-5">{teacher.institutionGraduated}</p>

                <div className="flex items-center gap-2 pt-1">
                  <Clock className="h-3.5 w-3.5 text-slate-400" />
                  <span>Carga Semanal: <strong>{teacher.workloadHours || teacher.weeklyHours || 24} Horas Lectivas</strong></span>
                </div>

                <div className="flex items-center gap-2">
                  <Phone className="h-3.5 w-3.5 text-slate-400" />
                  <span>{teacher.phone}</span>
                </div>
              </div>

              {/* Disciplinas e Turmas */}
              <div className="mt-3 pt-3 border-t border-slate-100">
                <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                  Disciplinas Atribuídas:
                </p>
                <div className="flex flex-wrap gap-1">
                  {(teacher.assignedSubjects || teacher.subjects || []).map((sub) => (
                    <span
                      key={sub}
                      className="rounded-md bg-slate-100 px-2 py-0.5 text-[11px] font-semibold text-slate-700"
                    >
                      {sub}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
              <span className="text-[11px] text-slate-400 font-medium">Desde {teacher.hireDate || '2022-02-01'}</span>
              <button
                onClick={() => setSelectedTeacher(teacher)}
                className="text-xs font-bold text-emerald-700 hover:text-emerald-800"
              >
                Ver Detalhes →
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Modal de Cadastro de Professor */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
          <div className="relative w-full max-w-lg rounded-2xl bg-white shadow-2xl p-6">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-4">
              <h3 className="font-extrabold text-slate-900 text-base flex items-center gap-2">
                <GraduationCap className="h-5 w-5 text-emerald-600" />
                Cadastrar Docente no Sistema
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Nome Completo do Docente *</label>
                <input
                  type="text"
                  required
                  value={formData.fullName}
                  onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                  className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-emerald-500 focus:outline-none"
                  placeholder="ex: Dr. António Manuel Macamo"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Grau Académico *</label>
                  <select
                    value={formData.academicDegree}
                    onChange={(e) => setFormData({ ...formData, academicDegree: e.target.value })}
                    className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-emerald-500 focus:outline-none"
                  >
                    <option value="Bacharelato">Bacharelato</option>
                    <option value="Licenciatura em Ensino">Licenciatura em Ensino</option>
                    <option value="Mestrado">Mestrado</option>
                    <option value="Doutoramento">Doutoramento</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Instituição de Formação *</label>
                  <input
                    type="text"
                    required
                    value={formData.institutionGraduated}
                    onChange={(e) => setFormData({ ...formData, institutionGraduated: e.target.value })}
                    className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-emerald-500 focus:outline-none"
                    placeholder="ex: UP Maputo"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Contacto Telefónico *</label>
                  <input
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-emerald-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Carga Horária Semanal (Horas) *</label>
                  <input
                    type="number"
                    required
                    min={4}
                    max={40}
                    value={formData.weeklyHours}
                    onChange={(e) => setFormData({ ...formData, weeklyHours: Number(e.target.value) })}
                    className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-emerald-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Disciplinas Leccionadas (separadas por vírgula)</label>
                <input
                  type="text"
                  value={formData.subjects.join(', ')}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      subjects: e.target.value.split(',').map((s) => s.trim()).filter(Boolean)
                    })
                  }
                  className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-emerald-500 focus:outline-none"
                  placeholder="ex: Matemática, Física"
                />
              </div>

              <div className="flex justify-end gap-2 pt-4 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="rounded-xl bg-slate-100 px-4 py-2 font-bold text-slate-700 hover:bg-slate-200"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-emerald-600 px-5 py-2 font-bold text-white hover:bg-emerald-700 shadow-sm"
                >
                  Guardar Docente
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal de Detalhes do Docente */}
      {selectedTeacher && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
          <div className="relative w-full max-w-md rounded-2xl bg-white shadow-2xl p-6">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-4">
              <h3 className="font-extrabold text-slate-900 text-base">{selectedTeacher.fullName}</h3>
              <button onClick={() => setSelectedTeacher(null)} className="text-slate-400 hover:text-slate-600">
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="space-y-3 text-xs text-slate-700">
              <p><strong>Nº Funcionário:</strong> {selectedTeacher.employeeNumber}</p>
              <p><strong>Grau:</strong> {selectedTeacher.academicDegree}</p>
              <p><strong>Universidade:</strong> {selectedTeacher.institutionGraduated || 'Universidade Pedagógica (UP)'}</p>
              <p><strong>Carga Semanal:</strong> {selectedTeacher.workloadHours || selectedTeacher.weeklyHours || 24} horas/aula</p>
              <p><strong>Contacto:</strong> {selectedTeacher.phone}</p>
              <p><strong>Email:</strong> {selectedTeacher.email || 'Não informado'}</p>
              <p><strong>Disciplinas:</strong> {(selectedTeacher.assignedSubjects || selectedTeacher.subjects || []).join(', ')}</p>
              <p><strong>Turmas Vinculadas:</strong> {(selectedTeacher.assignedSections || []).join(', ')}</p>
            </div>
            <div className="mt-5 pt-3 border-t border-slate-200 text-right">
              <button
                onClick={() => setSelectedTeacher(null)}
                className="rounded-xl bg-slate-200 px-4 py-2 text-xs font-bold text-slate-800"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
