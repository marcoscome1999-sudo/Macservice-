/**
 * EduGest Moçambique - Lançamento de Notas (GradesSpreadsheetView)
 * Folha de cálculo interativa e moderna com:
 * - Alunos na vertical, avaliações na horizontal (ACS1, ACS2, Trabalho, ACP, MPT, MT)
 * - Escala oficial de 0 a 20 valores
 * - Gravação automática e cálculo imediato das médias (MPT e MT)
 * - Destaque visual: Verde (≥ 10) e Vermelho (< 10)
 * - Bloqueio de notas após validação da direcção
 * - Auditoria obrigatória para alteração de notas validadas (quem, quando e porquê)
 */

import React, { useState, useMemo, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { GradeEntry, Student } from '../../types';
import {
  Calculator,
  Save,
  Lock,
  Unlock,
  AlertCircle,
  FileSpreadsheet,
  CheckCircle2,
  History,
  X,
  Filter
} from 'lucide-react';

export const GradesSpreadsheetView: React.FC = () => {
  const {
    db,
    currentUser,
    batchUpdateGrades,
    lockSectionGrades,
    requestGradeChange
  } = useApp();

  // Seletores de Turma, Disciplina e Trimestre
  const [selectedSectionId, setSelectedSectionId] = useState<string>(db.sections[0]?.name || 'Turma 10A');
  const [selectedSubjectId, setSelectedSubjectId] = useState<string>(db.subjects[0]?.id || 'sub-1');
  const [selectedTerm, setSelectedTerm] = useState<1 | 2 | 3>(1);

  // Alunos da Turma Selecionada
  const studentsInClass = useMemo(() => {
    return db.students.filter((s) => s.currentSection === selectedSectionId);
  }, [db.students, selectedSectionId]);

  // Estado Local da Grelha para Edição Fluida em Tempo Real
  const [localGrades, setLocalGrades] = useState<Record<string, Partial<GradeEntry>>>({});
  const [saveStatus, setSaveStatus] = useState<'IDLE' | 'SAVING' | 'SAVED'>('IDLE');

  // Modal de Pedido / Justificação de Alteração de Nota
  const [auditModal, setAuditModal] = useState<{
    isOpen: boolean;
    studentId: string;
    studentName: string;
    field: string;
    oldVal: number | null;
    newVal: number | null;
    gradeEntryId: string;
    reason: string;
  }>({
    isOpen: false,
    studentId: '',
    studentName: '',
    field: '',
    oldVal: null,
    newVal: null,
    gradeEntryId: '',
    reason: ''
  });

  // Carregar dados existentes do banco para a grelha local
  useEffect(() => {
    const map: Record<string, Partial<GradeEntry>> = {};
    for (const student of studentsInClass) {
      const existing = db.grades.find(
        (g) =>
          g.studentId === student.id &&
          g.subjectId === selectedSubjectId &&
          g.term === selectedTerm
      );
      if (existing) {
        map[student.id] = { ...existing };
      } else {
        map[student.id] = {
          studentId: student.id,
          subjectId: selectedSubjectId,
          sectionId: selectedSectionId,
          term: selectedTerm,
          acs1: null,
          acs2: null,
          trabalho: null,
          acp: null,
          mpt: null,
          mt: null,
          status: 'RASCUNHO'
        };
      }
    }
    setLocalGrades(map);
  }, [studentsInClass, selectedSubjectId, selectedTerm, selectedSectionId, db.grades]);

  // Verificar se as notas da turma estão bloqueadas/validadas
  const isLocked = useMemo(() => {
    const values = Object.values(localGrades) as Partial<GradeEntry>[];
    const first = values[0];
    return first?.status === 'VALIDADA';
  }, [localGrades]);

  // Função para calcular MPT e MT
  const computeAverages = (entry: Partial<GradeEntry>) => {
    const { acs1, acs2, trabalho, acp } = entry;
    const items: number[] = [];
    if (typeof acs1 === 'number') items.push(acs1);
    if (typeof acs2 === 'number') items.push(acs2);
    if (typeof trabalho === 'number') items.push(trabalho);

    let mpt: number | null = null;
    if (items.length > 0) {
      const sum = items.reduce((a, b) => a + b, 0);
      mpt = Number((sum / items.length).toFixed(1));
    }

    let mt: number | null = null;
    if (mpt !== null && typeof acp === 'number') {
      // Fórmula Oficial MINEDH: MT = (MPT * 0.4) + (ACP * 0.6)
      mt = Number(((mpt * 0.4) + (acp * 0.6)).toFixed(1));
    } else if (mpt !== null) {
      mt = mpt;
    }
    return { mpt, mt };
  };

  // Alterar valor na célula
  const handleCellChange = (
    studentId: string,
    studentName: string,
    field: 'acs1' | 'acs2' | 'trabalho' | 'acp',
    valueStr: string
  ) => {
    const currentEntry = localGrades[studentId] || {};
    const oldVal = currentEntry[field] ?? null;

    let parsed: number | null = null;
    if (valueStr.trim() !== '') {
      const num = parseFloat(valueStr);
      if (isNaN(num) || num < 0 || num > 20) {
        return; // Fora da escala de 0 a 20 valores
      }
      parsed = Number(num.toFixed(1));
    }

    // Se já estiver validada/bloqueada, exige justificação formal de auditoria
    if (isLocked) {
      setAuditModal({
        isOpen: true,
        studentId,
        studentName,
        field,
        oldVal,
        newVal: parsed,
        gradeEntryId: currentEntry.id || '',
        reason: ''
      });
      return;
    }

    const updated = {
      ...currentEntry,
      [field]: parsed
    };
    const { mpt, mt } = computeAverages(updated);
    updated.mpt = mpt;
    updated.mt = mt;

    setLocalGrades((prev) => ({
      ...prev,
      [studentId]: updated
    }));

    // Auto-save com debounce visual
    setSaveStatus('SAVING');
    setTimeout(() => {
      setSaveStatus('SAVED');
    }, 400);
  };

  // Guardar todas as alterações na base de dados
  const handlePersistGrades = () => {
    const entriesToSave: GradeEntry[] = [];
    const timestamp = new Date().toISOString().replace('T', ' ').substring(0, 16);

    for (const [studentId, rawEntry] of Object.entries(localGrades)) {
      const entry = rawEntry as Partial<GradeEntry>;
      const computed = computeAverages(entry);
      entriesToSave.push({
        id: entry.id || 'grd-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
        schoolId: db.schools[0]?.id || 'school-1',
        academicYear: 2026,
        studentId,
        subjectId: selectedSubjectId,
        sectionId: selectedSectionId,
        term: selectedTerm,
        acs1: entry.acs1 ?? null,
        acs2: entry.acs2 ?? null,
        trabalho: entry.trabalho ?? null,
        acp: entry.acp ?? null,
        mpt: computed.mpt,
        mt: computed.mt,
        status: entry.status || 'RASCUNHO',
        lastModifiedBy: currentUser.name,
        lastModifiedAt: timestamp
      });
    }

    batchUpdateGrades(entriesToSave);
    setSaveStatus('SAVED');
  };

  // Confirmar alteração auditada em nota bloqueada
  const handleConfirmAuditChange = () => {
    if (!auditModal.reason.trim()) {
      alert('A justificação é obrigatória segundo as normas do SNE.');
      return;
    }

    requestGradeChange(
      auditModal.gradeEntryId,
      auditModal.studentName,
      db.subjects.find((s) => s.id === selectedSubjectId)?.name || 'Disciplina',
      auditModal.field,
      auditModal.oldVal,
      auditModal.newVal,
      auditModal.reason
    );

    setLocalGrades((prev) => {
      const cur = prev[auditModal.studentId] || {};
      const updated = { ...cur, [auditModal.field]: auditModal.newVal };
      const { mpt, mt } = computeAverages(updated);
      updated.mpt = mpt;
      updated.mt = mt;
      return { ...prev, [auditModal.studentId]: updated };
    });

    setAuditModal({
      isOpen: false,
      studentId: '',
      studentName: '',
      field: '',
      oldVal: null,
      newVal: null,
      gradeEntryId: '',
      reason: ''
    });
  };

  // Bloquear notas (Direcção / Secretaria)
  const handleToggleLock = () => {
    if (isLocked) {
      alert('Notas validadas. Contacte o Administrador Geral para reabertura de trimestre.');
    } else {
      if (confirm('Deseja validar e bloquear o lançamento de notas para esta turma?')) {
        handlePersistGrades();
        lockSectionGrades(selectedSectionId, selectedSubjectId, selectedTerm);
      }
    }
  };

  const currentSubject = db.subjects.find((s) => s.id === selectedSubjectId);

  return (
    <div className="space-y-6">
      {/* Cabeçalho */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
            <Calculator className="h-6 w-6 text-sky-600" />
            Lançamento de Avaliações & Folha de Notas
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Escala oficial de 0 a 20 valores • Fórmula SNE: MT = (MPT × 0.4) + (ACP × 0.6)
          </p>
        </div>

        <div className="flex items-center gap-2">
          {saveStatus === 'SAVED' && (
            <span className="flex items-center gap-1 rounded-lg bg-emerald-50 px-2.5 py-1 text-xs font-bold text-emerald-700 border border-emerald-200">
              <CheckCircle2 className="h-3.5 w-3.5" />
              Gravado
            </span>
          )}

          <button
            onClick={handlePersistGrades}
            className="flex items-center gap-1.5 rounded-xl bg-sky-600 px-3.5 py-2 text-xs font-bold text-white shadow-sm hover:bg-sky-700 transition"
          >
            <Save className="h-4 w-4" />
            Guardar Pauta
          </button>

          {(currentUser.role === 'ADMIN' || currentUser.role === 'DIRECAO') && (
            <button
              onClick={handleToggleLock}
              className={`flex items-center gap-1.5 rounded-xl px-3.5 py-2 text-xs font-bold transition shadow-sm ${
                isLocked
                  ? 'bg-amber-100 text-amber-800 border border-amber-300'
                  : 'bg-slate-900 text-white hover:bg-slate-800'
              }`}
            >
              {isLocked ? (
                <>
                  <Lock className="h-4 w-4 text-amber-600" />
                  Notas Bloqueadas
                </>
              ) : (
                <>
                  <Unlock className="h-4 w-4" />
                  Validar & Bloquear Notas
                </>
              )}
            </button>
          )}
        </div>
      </div>

      {/* Barra de Filtros: Turma, Disciplina e Trimestre */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
        <div>
          <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
            Turma / Classe
          </label>
          <select
            value={selectedSectionId}
            onChange={(e) => setSelectedSectionId(e.target.value)}
            className="w-full rounded-xl border border-slate-200 bg-slate-50 py-2 px-3 text-xs font-semibold text-slate-800 focus:border-sky-500 focus:outline-none"
          >
            {db.sections.map((s) => (
              <option key={s.id} value={s.name}>
                {s.gradeLevel} - {s.name} ({s.shift})
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
            Disciplina Curricular
          </label>
          <select
            value={selectedSubjectId}
            onChange={(e) => setSelectedSubjectId(e.target.value)}
            className="w-full rounded-xl border border-slate-200 bg-slate-50 py-2 px-3 text-xs font-semibold text-slate-800 focus:border-sky-500 focus:outline-none"
          >
            {db.subjects.map((sub) => (
              <option key={sub.id} value={sub.id}>
                {sub.name} ({sub.code})
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
            Trimestre Lectivo
          </label>
          <div className="grid grid-cols-3 gap-1.5">
            {[1, 2, 3].map((t) => (
              <button
                key={t}
                onClick={() => setSelectedTerm(t as 1 | 2 | 3)}
                className={`rounded-xl py-2 text-xs font-bold transition ${
                  selectedTerm === t
                    ? 'bg-sky-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {t}º Trimestre
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Folha de Cálculo das Notas */}
      <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-900 text-white font-bold uppercase text-[11px] tracking-wider">
              <tr>
                <th className="py-3.5 px-4 w-12 text-center border-r border-slate-800">#</th>
                <th className="py-3.5 px-4 min-w-[200px] border-r border-slate-800">Nome do Aluno</th>
                <th className="py-3.5 px-3 text-center border-r border-slate-800 w-24">
                  ACS 1 <span className="block text-[9px] text-slate-400 font-normal">0-20 val</span>
                </th>
                <th className="py-3.5 px-3 text-center border-r border-slate-800 w-24">
                  ACS 2 <span className="block text-[9px] text-slate-400 font-normal">0-20 val</span>
                </th>
                <th className="py-3.5 px-3 text-center border-r border-slate-800 w-24">
                  Trabalho (TI) <span className="block text-[9px] text-slate-400 font-normal">0-20 val</span>
                </th>
                <th className="py-3.5 px-3 text-center border-r border-slate-800 w-28 bg-sky-950">
                  MPT (Média Trab.) <span className="block text-[9px] text-sky-300 font-normal">Automática</span>
                </th>
                <th className="py-3.5 px-3 text-center border-r border-slate-800 w-24">
                  ACP (Prova) <span className="block text-[9px] text-slate-400 font-normal">0-20 val</span>
                </th>
                <th className="py-3.5 px-3 text-center border-r border-slate-800 w-28 bg-indigo-950">
                  MT (Média Trim.) <span className="block text-[9px] text-indigo-300 font-normal">MPT*0.4+ACP*0.6</span>
                </th>
                <th className="py-3.5 px-4 text-center">Situação</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {studentsInClass.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-400 font-medium">
                    Nenhum aluno alocado à {selectedSectionId}.
                  </td>
                </tr>
              ) : (
                studentsInClass.map((student, idx) => {
                  const entry = localGrades[student.id] || {};
                  const isPassing = (entry.mt ?? 0) >= 10;
                  const hasGrade = entry.mt !== null && entry.mt !== undefined;

                  return (
                    <tr key={student.id} className="hover:bg-slate-50/70 transition">
                      <td className="py-2.5 px-3 text-center font-mono text-slate-400 font-bold border-r border-slate-100">
                        {String(idx + 1).padStart(2, '0')}
                      </td>
                      <td className="py-2.5 px-4 font-bold text-slate-900 border-r border-slate-100">
                        <div>
                          <p>{student.fullName}</p>
                          <p className="text-[10px] text-slate-400 font-mono">{student.studentNumber}</p>
                        </div>
                      </td>

                      {/* ACS 1 */}
                      <td className="p-1.5 text-center border-r border-slate-100">
                        <input
                          type="number"
                          step="0.1"
                          min="0"
                          max="20"
                          disabled={isLocked && currentUser.role !== 'ADMIN'}
                          value={entry.acs1 ?? ''}
                          onChange={(e) =>
                            handleCellChange(student.id, student.fullName, 'acs1', e.target.value)
                          }
                          className={`w-16 rounded-lg py-1 px-1.5 text-center font-mono text-xs font-bold transition focus:outline-none focus:ring-2 focus:ring-sky-500 ${
                            typeof entry.acs1 === 'number'
                              ? entry.acs1 >= 10
                                ? 'bg-emerald-50 text-emerald-800 border border-emerald-300'
                                : 'bg-rose-50 text-rose-800 border border-rose-300'
                              : 'bg-slate-50 border border-slate-200'
                          }`}
                        />
                      </td>

                      {/* ACS 2 */}
                      <td className="p-1.5 text-center border-r border-slate-100">
                        <input
                          type="number"
                          step="0.1"
                          min="0"
                          max="20"
                          disabled={isLocked && currentUser.role !== 'ADMIN'}
                          value={entry.acs2 ?? ''}
                          onChange={(e) =>
                            handleCellChange(student.id, student.fullName, 'acs2', e.target.value)
                          }
                          className={`w-16 rounded-lg py-1 px-1.5 text-center font-mono text-xs font-bold transition focus:outline-none focus:ring-2 focus:ring-sky-500 ${
                            typeof entry.acs2 === 'number'
                              ? entry.acs2 >= 10
                                ? 'bg-emerald-50 text-emerald-800 border border-emerald-300'
                                : 'bg-rose-50 text-rose-800 border border-rose-300'
                              : 'bg-slate-50 border border-slate-200'
                          }`}
                        />
                      </td>

                      {/* Trabalho (TI) */}
                      <td className="p-1.5 text-center border-r border-slate-100">
                        <input
                          type="number"
                          step="0.1"
                          min="0"
                          max="20"
                          disabled={isLocked && currentUser.role !== 'ADMIN'}
                          value={entry.trabalho ?? ''}
                          onChange={(e) =>
                            handleCellChange(student.id, student.fullName, 'trabalho', e.target.value)
                          }
                          className={`w-16 rounded-lg py-1 px-1.5 text-center font-mono text-xs font-bold transition focus:outline-none focus:ring-2 focus:ring-sky-500 ${
                            typeof entry.trabalho === 'number'
                              ? entry.trabalho >= 10
                                ? 'bg-emerald-50 text-emerald-800 border border-emerald-300'
                                : 'bg-rose-50 text-rose-800 border border-rose-300'
                              : 'bg-slate-50 border border-slate-200'
                          }`}
                        />
                      </td>

                      {/* MPT (Calculado) */}
                      <td className="py-2.5 px-3 text-center font-mono font-bold border-r border-slate-100 bg-sky-50/40">
                        <span
                          className={`text-xs ${
                            entry.mpt !== null && entry.mpt !== undefined
                              ? entry.mpt >= 10
                                ? 'text-emerald-700 font-extrabold'
                                : 'text-rose-700 font-extrabold'
                              : 'text-slate-400'
                          }`}
                        >
                          {entry.mpt ?? '-'}
                        </span>
                      </td>

                      {/* ACP (Prova) */}
                      <td className="p-1.5 text-center border-r border-slate-100">
                        <input
                          type="number"
                          step="0.1"
                          min="0"
                          max="20"
                          disabled={isLocked && currentUser.role !== 'ADMIN'}
                          value={entry.acp ?? ''}
                          onChange={(e) =>
                            handleCellChange(student.id, student.fullName, 'acp', e.target.value)
                          }
                          className={`w-16 rounded-lg py-1 px-1.5 text-center font-mono text-xs font-bold transition focus:outline-none focus:ring-2 focus:ring-sky-500 ${
                            typeof entry.acp === 'number'
                              ? entry.acp >= 10
                                ? 'bg-emerald-50 text-emerald-800 border border-emerald-300'
                                : 'bg-rose-50 text-rose-800 border border-rose-300'
                              : 'bg-slate-50 border border-slate-200'
                          }`}
                        />
                      </td>

                      {/* MT (Média Trimestral Final) */}
                      <td className="py-2.5 px-3 text-center font-mono text-sm border-r border-slate-100 bg-indigo-50/40">
                        <span
                          className={`font-black ${
                            hasGrade
                              ? isPassing
                                ? 'text-emerald-700'
                                : 'text-rose-700'
                              : 'text-slate-400'
                          }`}
                        >
                          {entry.mt ?? '-'}
                        </span>
                      </td>

                      {/* Situação */}
                      <td className="py-2.5 px-4 text-center">
                        {hasGrade ? (
                          <span
                            className={`inline-flex rounded-full px-2.5 py-0.5 text-[10px] font-bold ${
                              isPassing
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-rose-100 text-rose-800'
                            }`}
                          >
                            {isPassing ? 'Aprovado' : 'Não Aprovado'}
                          </span>
                        ) : (
                          <span className="text-[10px] text-slate-400 font-medium">Incompleto</span>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL DE AUDITORIA DE NOTA BLOQUEADA */}
      {auditModal.isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
          <div className="relative w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-4">
              <h3 className="font-extrabold text-slate-900 text-base flex items-center gap-2">
                <History className="h-5 w-5 text-amber-600" />
                Auditoria de Alteração de Nota
              </h3>
              <button
                onClick={() => setAuditModal((prev) => ({ ...prev, isOpen: false }))}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs text-slate-600 mb-4">
              <p>
                <strong>Aluno:</strong> {auditModal.studentName}
              </p>
              <p>
                <strong>Campo:</strong> {auditModal.field.toUpperCase()}
              </p>
              <p>
                <strong>Nota Anterior:</strong>{' '}
                <span className="font-mono text-rose-600 font-bold">
                  {auditModal.oldVal ?? 'Sem registo'}
                </span>{' '}
                → <strong>Nova Nota:</strong>{' '}
                <span className="font-mono text-emerald-600 font-bold">
                  {auditModal.newVal ?? 'Vazio'}
                </span>
              </p>
              <div className="rounded-xl bg-amber-50 p-3 border border-amber-200 text-amber-800 text-[11px]">
                Esta pauta já foi homologada pela Direcção. Qualquer retificação exige parecer e justificativa formal nos termos do Regulamento de Avaliações do MINEDH.
              </div>

              <div>
                <label className="block font-bold text-slate-800 mb-1">
                  Justificativa Oficial / Motivo da Retificação *
                </label>
                <textarea
                  rows={3}
                  required
                  value={auditModal.reason}
                  onChange={(e) =>
                    setAuditModal((prev) => ({ ...prev, reason: e.target.value }))
                  }
                  className="w-full rounded-xl border border-slate-300 p-2.5 text-xs focus:border-sky-500 focus:outline-none"
                  placeholder="Ex: Erro de digitação constatado no confronto com a folha de prova original arquivada."
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setAuditModal((prev) => ({ ...prev, isOpen: false }))}
                className="rounded-xl bg-slate-100 px-4 py-2 font-bold text-slate-700 hover:bg-slate-200 text-xs"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleConfirmAuditChange}
                className="rounded-xl bg-amber-600 px-5 py-2 font-bold text-white hover:bg-amber-700 text-xs shadow-sm"
              >
                Confirmar e Registar em Log
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
