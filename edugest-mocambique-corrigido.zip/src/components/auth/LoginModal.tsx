/**
 * EduGest Moçambique - Modal e Ecrã de Autenticação Real
 * Ponto 1 e 18 do SNE: Autenticação por Código Único (PROF-2026-0001, ALU-2026-0001) e PIN.
 * Inclui atalhos para teste imediato de todos os 6 perfis previstos no SNE.
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { UserRole } from '../../types';
import {
  KeyRound,
  ShieldCheck,
  Building,
  CheckCircle,
  AlertCircle,
  Sparkles,
  ArrowRight,
  Lock,
  UserCheck,
  GraduationCap,
  Users
} from 'lucide-react';

interface LoginModalProps {
  isOpen: boolean;
  onClose?: () => void;
}

export const LoginModal: React.FC<LoginModalProps> = ({ isOpen, onClose }) => {
  const { db, currentSchool, loginWithCode } = useApp();

  const [accessCode, setAccessCode] = useState('');
  const [pin, setPin] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setIsLoading(true);

    setTimeout(() => {
      const result = loginWithCode(accessCode, pin);
      setIsLoading(false);

      if (result.success) {
        if (onClose) onClose();
      } else {
        setErrorMessage(result.error || 'Falha na autenticação. Verifique o código e PIN.');
      }
    }, 400);
  };

  // Preencher rapidamente para demonstração
  const handleQuickLogin = (code: string, userPin: string) => {
    setAccessCode(code);
    setPin(userPin);
    setErrorMessage(null);
    setIsLoading(true);

    setTimeout(() => {
      const result = loginWithCode(code, userPin);
      setIsLoading(false);
      if (result.success && onClose) {
        onClose();
      }
    }, 300);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 p-4 backdrop-blur-xs">
      <div className="relative w-full max-w-lg rounded-3xl bg-white p-6 sm:p-8 shadow-2xl border border-slate-100">
        {/* Cabeçalho */}
        <div className="text-center">
          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-slate-900 text-sky-400 shadow-md">
            <KeyRound className="h-7 w-7" />
          </div>
          <h2 className="mt-4 text-xl font-extrabold text-slate-900 tracking-tight">
            EduGest Moçambique
          </h2>
          <p className="mt-1 text-xs text-slate-500">
            Aceda com o seu Código Individual SNE e PIN de Segurança
          </p>
          <p className="text-[11px] font-bold text-sky-800 bg-sky-50 py-1 px-3 rounded-full mt-2 inline-block border border-sky-200">
            {currentSchool.name}
          </p>
        </div>

        {/* Mensagem de Erro */}
        {errorMessage && (
          <div className="mt-4 rounded-xl bg-rose-50 border border-rose-200 p-3 text-xs font-semibold text-rose-800 flex items-center gap-2">
            <AlertCircle className="h-4 w-4 text-rose-600 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Formulário de Login */}
        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Código de Acesso SNE *
            </label>
            <input
              type="text"
              required
              placeholder="ex: PROF-2026-0048 ou ALU-2026-0421"
              value={accessCode}
              onChange={(e) => setAccessCode(e.target.value.toUpperCase())}
              className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-xs sm:text-sm font-mono uppercase focus:border-sky-500 focus:outline-hidden"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Senha / PIN de Acesso *
            </label>
            <input
              type="password"
              required
              placeholder="••••"
              value={pin}
              onChange={(e) => setPin(e.target.value)}
              className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-xs sm:text-sm font-mono focus:border-sky-500 focus:outline-hidden"
            />
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full inline-flex items-center justify-center gap-2 rounded-xl bg-slate-900 py-3 text-xs sm:text-sm font-bold text-white hover:bg-slate-800 transition-colors shadow-sm disabled:opacity-50"
          >
            {isLoading ? 'A autenticar...' : 'Entrar no Sistema Escolar'}
            <ArrowRight className="h-4 w-4" />
          </button>
        </form>

        {/* Atalhos Rápidos para Demonstração de Todos os 6 Perfis */}
        <div className="mt-6 border-t border-slate-200 pt-4">
          <p className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400 text-center mb-2.5">
            Acesso Rápido para Avaliação (Todos os 6 Perfis)
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {[
              { label: 'Administrador', code: 'ADM-2026-0001', pin: '1234', role: 'ADMIN' },
              { label: 'Direção', code: 'DIR-2026-0001', pin: '1234', role: 'DIRECAO' },
              { label: 'Secretaria', code: 'SEC-2026-0001', pin: '1234', role: 'SECRETARIA' },
              { label: 'Professor', code: 'PROF-2026-0048', pin: '1234', role: 'PROFESSOR' },
              { label: 'Aluno', code: 'ALU-2026-0421', pin: '1234', role: 'ALUNO' },
              { label: 'Encarregado', code: 'ENC-2026-0012', pin: '1234', role: 'ENCARREGADO' }
            ].map((demo) => (
              <button
                key={demo.code}
                type="button"
                onClick={() => handleQuickLogin(demo.code, demo.pin)}
                className="flex flex-col items-start rounded-xl border border-slate-200 bg-slate-50 p-2 text-left hover:border-sky-400 hover:bg-sky-50/50 transition-colors"
              >
                <span className="text-[11px] font-extrabold text-slate-900">{demo.label}</span>
                <span className="font-mono text-[9px] text-slate-500">{demo.code}</span>
              </button>
            ))}
          </div>
        </div>

        {onClose && (
          <div className="mt-4 text-center">
            <button
              onClick={onClose}
              className="text-xs font-semibold text-slate-400 hover:text-slate-600"
            >
              Continuar Sessão Atual
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
