/**
 * EduGest Moçambique - Comunicação Escola-Família (CommunicationView)
 * Canais adaptados à realidade moçambicana:
 * - SMS (Vodacom, Movitel, Tmcel)
 * - WhatsApp
 * - Notificações do Portal / PWA
 * Envio de comunicados gerais, convocatórias de reuniões de encarregados,
 * alertas de faltas e avisos de propinas.
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { NotificationMessage } from '../../types';
import {
  MessageSquare,
  Send,
  Smartphone,
  Bell,
  Users,
  CheckCircle2,
  Calendar,
  AlertTriangle,
  FileText
} from 'lucide-react';

export const CommunicationView: React.FC = () => {
  const { db, sendNotification, currentSchool } = useApp();

  const [channel, setChannel] = useState<'ALL' | 'SMS' | 'WHATSAPP' | 'APP'>('SMS');
  const [targetAudience, setTargetAudience] = useState<'TODOS' | 'ENCARREGADOS' | 'PROFESSORES' | 'ALUNOS'>('ENCARREGADOS');
  const [category, setCategory] = useState<'AVISO_GERAL' | 'REUNIAO' | 'NOTAS' | 'FALTAS' | 'FINANCEIRO'>('REUNIAO');
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [successMsg, setSuccessMsg] = useState(false);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !body.trim()) return;

    sendNotification({
      schoolId: currentSchool.id,
      title,
      body,
      targetAudience,
      channel,
      category
    });

    setTitle('');
    setBody('');
    setSuccessMsg(true);
    setTimeout(() => setSuccessMsg(false), 3000);
  };

  // Predefinições rápidas para a realidade de Moçambique
  const applyTemplate = (type: 'REUNIAO' | 'FALTAS' | 'PROPINA' | 'AVALIACAO') => {
    if (type === 'REUNIAO') {
      setTitle('Convocatória: Reunião Geral de Pais e Encarregados de Educação');
      setBody('Convidamos todos os pais e encarregados de educação para a reunião trimestral que terá lugar no próximo sábado, às 08h:30m, no anfiteatro da escola.');
      setCategory('REUNIAO');
      setTargetAudience('ENCARREGADOS');
    } else if (type === 'FALTAS') {
      setTitle('Aviso de Limite de Assiduidade');
      setBody('Informamos aos encarregados que a ausência injustificada a mais de 25% das aulas letivas implica a exclusão aos exames finais segundo o regulamento do SNE.');
      setCategory('FALTAS');
      setTargetAudience('ENCARREGADOS');
    } else if (type === 'PROPINA') {
      setTitle('Lembrete de Liquidação de Propinas');
      setBody('Informamos que o prazo para pagamento das propinas escolares decorre até ao dia 10 deste mês. Utilize as contas M-Pesa ou e-Mola da escola para liquidação rápida.');
      setCategory('FINANCEIRO');
      setTargetAudience('ENCARREGADOS');
    } else if (type === 'AVALIACAO') {
      setTitle('Publicação das Pautas do 1º Trimestre');
      setBody('Informamos que as pautas de aproveitamento do 1º Trimestre já se encontram afixadas na vitrine escolar e disponíveis na plataforma EduGest.');
      setCategory('NOTAS');
      setTargetAudience('TODOS');
    }
  };

  return (
    <div className="space-y-6">
      {/* Cabeçalho */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
            <MessageSquare className="h-6 w-6 text-emerald-600" />
            Comunicação Escola-Família & Avisos Oficiais
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Envio em massa por SMS (Vodacom, Movitel, Tmcel), WhatsApp e notificações no Portal.
          </p>
        </div>
      </div>

      {successMsg && (
        <div className="rounded-xl border border-emerald-200 bg-emerald-50 p-4 text-xs font-bold text-emerald-800 flex items-center gap-2 shadow-xs">
          <CheckCircle2 className="h-5 w-5 text-emerald-600 shrink-0" />
          Mensagem transmitida com sucesso através dos canais selecionados para os destinatários!
        </div>
      )}

      {/* Grade Principal: Nova Mensagem + Histórico */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Formulário de Envio */}
        <div className="lg:col-span-2 rounded-2xl border border-slate-200 bg-white p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
              <Send className="h-4 w-4 text-emerald-600" />
              Compor Notificação ou Comunicado
            </h3>

            {/* Modelos Rápidos */}
            <div className="flex flex-wrap gap-1">
              <button
                type="button"
                onClick={() => applyTemplate('REUNIAO')}
                className="rounded-lg bg-slate-100 px-2 py-1 text-[11px] font-bold text-slate-700 hover:bg-slate-200"
              >
                + Reunião Pais
              </button>
              <button
                type="button"
                onClick={() => applyTemplate('PROPINA')}
                className="rounded-lg bg-emerald-50 px-2 py-1 text-[11px] font-bold text-emerald-800 hover:bg-emerald-100"
              >
                + Propinas
              </button>
              <button
                type="button"
                onClick={() => applyTemplate('AVALIACAO')}
                className="rounded-lg bg-sky-50 px-2 py-1 text-[11px] font-bold text-sky-800 hover:bg-sky-100"
              >
                + Pautas
              </button>
            </div>
          </div>

          <form onSubmit={handleSend} className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Canal de Transmissão</label>
                <select
                  value={channel}
                  onChange={(e) => setChannel(e.target.value as any)}
                  className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-emerald-500 focus:outline-none font-semibold"
                >
                  <option value="SMS">SMS (Redes Nacionais)</option>
                  <option value="WHATSAPP">WhatsApp Oficial</option>
                  <option value="APP">Portal Web & PWA</option>
                  <option value="ALL">Todos os Canais</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Destinatários</label>
                <select
                  value={targetAudience}
                  onChange={(e) => setTargetAudience(e.target.value as any)}
                  className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-emerald-500 focus:outline-none font-semibold"
                >
                  <option value="ENCARREGADOS">Encarregados de Educação</option>
                  <option value="PROFESSORES">Corpo Docente</option>
                  <option value="ALUNOS">Estudantes</option>
                  <option value="TODOS">Comunidade Escolar Toda</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Categoria do Aviso</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as any)}
                  className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-emerald-500 focus:outline-none font-semibold"
                >
                  <option value="REUNIAO">Convocatória / Reunião</option>
                  <option value="AVISO_GERAL">Aviso Geral</option>
                  <option value="NOTAS">Notas & Avaliações</option>
                  <option value="FALTAS">Assiduidade & Faltas</option>
                  <option value="FINANCEIRO">Cobrança de Propinas</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Título do Comunicado *</label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Ex: Convocatória para Reunião de Turma da 10ª Classe"
                className="w-full rounded-xl border border-slate-300 p-2.5 text-xs font-bold text-slate-900 focus:border-emerald-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Texto da Mensagem *</label>
              <textarea
                rows={4}
                required
                value={body}
                onChange={(e) => setBody(e.target.value)}
                placeholder="Escreva a mensagem clara e objectiva..."
                className="w-full rounded-xl border border-slate-300 p-2.5 text-xs text-slate-800 focus:border-emerald-500 focus:outline-none"
              />
              <div className="flex justify-between items-center text-[10px] text-slate-400 mt-1">
                <span>Total de caracteres: {body.length}</span>
                <span>Equivale a: {Math.ceil((body.length || 1) / 160)} SMS padrão</span>
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="submit"
                className="rounded-xl bg-emerald-600 px-6 py-2.5 text-xs font-bold text-white hover:bg-emerald-700 shadow-sm flex items-center gap-2 transition"
              >
                <Send className="h-4 w-4" />
                Disparar Comunicado Agora
              </button>
            </div>
          </form>
        </div>

        {/* Histórico Recente de Mensagens */}
        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-xs space-y-4">
          <h3 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
            <Bell className="h-4 w-4 text-sky-600" />
            Histórico de Avisos Enviados
          </h3>

          <div className="space-y-3 overflow-y-auto max-h-[460px] pr-1">
            {db.notifications.length === 0 ? (
              <p className="text-xs text-slate-400 text-center py-6">
                Nenhum comunicado enviado até ao momento.
              </p>
            ) : (
              db.notifications.map((notif) => (
                <div key={notif.id} className="rounded-xl border border-slate-200 p-3 bg-slate-50/50 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="rounded bg-sky-100 px-1.5 py-0.5 text-[9px] font-extrabold text-sky-800 uppercase">
                      {notif.channel} • {notif.targetAudience}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">{notif.date}</span>
                  </div>
                  <h4 className="text-xs font-bold text-slate-900">{notif.title}</h4>
                  <p className="text-[11px] text-slate-600 leading-relaxed">{notif.body}</p>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
