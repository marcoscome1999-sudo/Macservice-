/**
 * EduGest Moçambique - Gestão de Disciplinas (SubjectsView)
 * Disciplinas curriculares oficiais do SNE: Código, Carga horária,
 * Professor responsável, Tipo (Nuclear, Complementar, Opção) e Vinculação a classes.
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Subject } from '../../types';
import {
  BookOpen,
  Plus,
  Clock,
  UserCheck,
  CheckCircle2,
  Layers,
  X
} from 'lucide-react';

export const SubjectsView: React.FC = () => {
  const { db, addSubject } = useApp();
  const [isModalOpen, setIsModalOpen] = useState(false);

  const [formData, setFormData] = useState<Omit<Subject, 'id'>>({
    schoolId: db.schools[0]?.id || 'school-1',
    name: '',
    code: '',
    weeklyHours: 4,
    applicableGrades: ['10ª Classe'],
    type: 'NUCLEAR',
    isRequired: true,
    teacherId: db.teachers[0]?.id || 'prof-1',
    teacherName: db.teachers[0]?.fullName || 'Docente'
  });

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.code.trim()) return;

    const teacher = db.teachers.find((t) => t.id === formData.teacherId);
    addSubject({
      ...formData,
      teacherName: teacher?.fullName || formData.teacherName
    });
    setIsModalOpen(false);
    setFormData({
      schoolId: db.schools[0]?.id || 'school-1',
      name: '',
      code: '',
      weeklyHours: 4,
      applicableGrades: ['10ª Classe'],
      type: 'NUCLEAR',
      isRequired: true,
      teacherId: db.teachers[0]?.id || 'prof-1',
      teacherName: db.teachers[0]?.fullName || 'Docente'
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
            <BookOpen className="h-6 w-6 text-sky-600" />
            Matriz Curricular de Disciplinas (SNE)
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Disciplinas nucleares, complementares e opcionais do Sistema Nacional de Educação.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-1.5 rounded-xl bg-sky-600 px-3.5 py-2 text-xs font-bold text-white shadow-sm hover:bg-sky-700 transition"
        >
          <Plus className="h-4 w-4" />
          Adicionar Disciplina
        </button>
      </div>

      {/* Tabela de Disciplinas */}
      <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600">
            <thead className="border-b border-slate-200 bg-slate-50 font-bold uppercase tracking-wider text-slate-500">
              <tr>
                <th className="py-3 px-4">Código</th>
                <th className="py-3 px-4">Nome da Disciplina</th>
                <th className="py-3 px-4">Tipo Curricular</th>
                <th className="py-3 px-4">Carga Semanal</th>
                <th className="py-3 px-4">Classes Aplicáveis</th>
                <th className="py-3 px-4">Docente Responsável</th>
                <th className="py-3 px-4">Obrigatoriedade</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {(db.subjects || []).map((sub) => {
                const subGrades = sub.applicableGrades && sub.applicableGrades.length > 0
                  ? sub.applicableGrades
                  : [sub.gradeLevel || '10ª Classe'];
                const subType = sub.type || 'NUCLEAR';
                const subRequired = sub.isRequired ?? (!sub.isElective);

                return (
                  <tr key={sub.id} className="hover:bg-slate-50/80 transition">
                    <td className="py-3 px-4 font-mono font-bold text-sky-700">
                      {sub.code}
                    </td>
                    <td className="py-3 px-4 font-bold text-slate-900">
                      {sub.name}
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`inline-flex rounded-full px-2 py-0.5 text-[10px] font-bold ${
                          subType === 'NUCLEAR'
                            ? 'bg-sky-100 text-sky-800'
                            : subType === 'COMPLEMENTAR'
                            ? 'bg-indigo-100 text-indigo-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {subType}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-medium text-slate-700">
                      {sub.weeklyHours} Horas / Semana
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex flex-wrap gap-1">
                        {subGrades.map((g) => (
                          <span key={g} className="rounded bg-slate-100 px-1.5 py-0.5 text-[10px] text-slate-700">
                            {g}
                          </span>
                        ))}
                      </div>
                    </td>
                    <td className="py-3 px-4 font-medium text-slate-800">
                      {sub.teacherName || 'A atribuir'}
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${
                          subRequired ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {subRequired ? 'Obrigatória' : 'Opcional'}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Adicionar Disciplina */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
          <div className="relative w-full max-w-md rounded-2xl bg-white shadow-2xl p-6">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-4">
              <h3 className="font-extrabold text-slate-900 text-base flex items-center gap-2">
                <BookOpen className="h-5 w-5 text-sky-600" />
                Adicionar Disciplina ao Plano Curricular
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Nome da Disciplina *</label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-sky-500 focus:outline-none"
                  placeholder="ex: Filosofia"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Código Curricular *</label>
                  <input
                    type="text"
                    required
                    value={formData.code}
                    onChange={(e) => setFormData({ ...formData, code: e.target.value.toUpperCase() })}
                    className="w-full rounded-xl border border-slate-300 p-2 text-xs font-mono uppercase focus:border-sky-500 focus:outline-none"
                    placeholder="ex: FIL"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Carga Semanal (Horas) *</label>
                  <input
                    type="number"
                    required
                    min={1}
                    max={10}
                    value={formData.weeklyHours}
                    onChange={(e) => setFormData({ ...formData, weeklyHours: Number(e.target.value) })}
                    className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-sky-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Tipo Curricular *</label>
                  <select
                    value={formData.type}
                    onChange={(e) => setFormData({ ...formData, type: e.target.value as any })}
                    className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-sky-500 focus:outline-none"
                  >
                    <option value="NUCLEAR">Nuclear</option>
                    <option value="COMPLEMENTAR">Complementar</option>
                    <option value="OPCAO">Opção</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Obrigatoriedade *</label>
                  <select
                    value={formData.isRequired ? 'true' : 'false'}
                    onChange={(e) => setFormData({ ...formData, isRequired: e.target.value === 'true' })}
                    className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-sky-500 focus:outline-none"
                  >
                    <option value="true">Obrigatória</option>
                    <option value="false">Opcional</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Professor Responsável *</label>
                <select
                  value={formData.teacherId}
                  onChange={(e) => setFormData({ ...formData, teacherId: e.target.value })}
                  className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-sky-500 focus:outline-none"
                >
                  {db.teachers.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.fullName}
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-4 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="rounded-xl bg-slate-100 px-4 py-2 font-bold text-slate-700 hover:bg-slate-200"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-sky-600 px-5 py-2 font-bold text-white hover:bg-sky-700 shadow-sm"
                >
                  Guardar Disciplina
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
