import React from 'react';

export type BadgeVariant =
  | 'ACTIVO'
  | 'INACTIVO'
  | 'LICENCA'
  | 'TRANSFERIDO'
  | 'DESISTENTE'
  | 'GRADUADO'
  | 'PAGO'
  | 'PENDENTE'
  | 'ATRASADO'
  | 'CANCELADO'
  | 'PRESENTE'
  | 'FALTA'
  | 'JUSTIFICADA'
  | 'ATRASO'
  | 'APROVADO'
  | 'REPROVADO'
  | 'EXAME'
  | 'DISPENSADO'
  | 'HOMOLOGADA'
  | 'RASCUNHO'
  | 'EM_ANALISE'
  | 'CONFIRMADA'
  | 'CONCLUIDA'
  | 'REJEITADA'
  | 'AUTENTICO'
  | 'REVOGADO'
  | 'SUSPEITO';

interface StatusBadgeProps {
  status: string;
  variant?: BadgeVariant;
  size?: 'sm' | 'md';
  className?: string;
}

const BADGE_CONFIG: Record<
  string,
  { bg: string; text: string; border: string; dot: string; label?: string }
> = {
  // Estados de Entidade / Matrícula
  ACTIVO: {
    bg: 'bg-emerald-50',
    text: 'text-emerald-800',
    border: 'border-emerald-200',
    dot: 'bg-emerald-500',
    label: 'Activo'
  },
  INACTIVO: {
    bg: 'bg-slate-50',
    text: 'text-slate-600',
    border: 'border-slate-200',
    dot: 'bg-slate-400',
    label: 'Inactivo'
  },
  LICENCA: {
    bg: 'bg-amber-50',
    text: 'text-amber-800',
    border: 'border-amber-200',
    dot: 'bg-amber-500',
    label: 'Em Licença'
  },
  TRANSFERIDO: {
    bg: 'bg-sky-50',
    text: 'text-sky-800',
    border: 'border-sky-200',
    dot: 'bg-sky-500',
    label: 'Transferido'
  },
  DESISTENTE: {
    bg: 'bg-rose-50',
    text: 'text-rose-800',
    border: 'border-rose-200',
    dot: 'bg-rose-500',
    label: 'Desistente'
  },
  GRADUADO: {
    bg: 'bg-indigo-50',
    text: 'text-indigo-800',
    border: 'border-indigo-200',
    dot: 'bg-indigo-500',
    label: 'Graduado'
  },
  CONFIRMADA: {
    bg: 'bg-emerald-50',
    text: 'text-emerald-800',
    border: 'border-emerald-200',
    dot: 'bg-emerald-500',
    label: 'Confirmada'
  },
  CONCLUIDA: {
    bg: 'bg-emerald-50',
    text: 'text-emerald-800',
    border: 'border-emerald-200',
    dot: 'bg-emerald-500',
    label: 'Concluída'
  },
  EM_ANALISE: {
    bg: 'bg-amber-50',
    text: 'text-amber-800',
    border: 'border-amber-200',
    dot: 'bg-amber-500',
    label: 'Em Análise'
  },
  REJEITADA: {
    bg: 'bg-rose-50',
    text: 'text-rose-800',
    border: 'border-rose-200',
    dot: 'bg-rose-500',
    label: 'Rejeitada'
  },

  // Financeiro
  PAGO: {
    bg: 'bg-emerald-50',
    text: 'text-emerald-800',
    border: 'border-emerald-200',
    dot: 'bg-emerald-500',
    label: 'Pago'
  },
  PENDENTE: {
    bg: 'bg-amber-50',
    text: 'text-amber-800',
    border: 'border-amber-200',
    dot: 'bg-amber-500',
    label: 'Pendente'
  },
  ATRASADO: {
    bg: 'bg-rose-50',
    text: 'text-rose-800',
    border: 'border-rose-200',
    dot: 'bg-rose-500',
    label: 'Em Atraso'
  },
  CANCELADO: {
    bg: 'bg-slate-50',
    text: 'text-slate-600',
    border: 'border-slate-200',
    dot: 'bg-slate-400',
    label: 'Cancelado'
  },

  // Presenças
  PRESENTE: {
    bg: 'bg-emerald-50',
    text: 'text-emerald-800',
    border: 'border-emerald-200',
    dot: 'bg-emerald-500',
    label: 'Presente'
  },
  FALTA: {
    bg: 'bg-rose-50',
    text: 'text-rose-800',
    border: 'border-rose-200',
    dot: 'bg-rose-500',
    label: 'Falta Injustificada'
  },
  JUSTIFICADA: {
    bg: 'bg-sky-50',
    text: 'text-sky-800',
    border: 'border-sky-200',
    dot: 'bg-sky-500',
    label: 'Falta Justificada'
  },
  ATRASO: {
    bg: 'bg-amber-50',
    text: 'text-amber-800',
    border: 'border-amber-200',
    dot: 'bg-amber-500',
    label: 'Atraso'
  },

  // Pedagógico & Pautas
  APROVADO: {
    bg: 'bg-emerald-50',
    text: 'text-emerald-800',
    border: 'border-emerald-200',
    dot: 'bg-emerald-500',
    label: 'Aprovado'
  },
  REPROVADO: {
    bg: 'bg-rose-50',
    text: 'text-rose-800',
    border: 'border-rose-200',
    dot: 'bg-rose-500',
    label: 'Reprovado'
  },
  EXAME: {
    bg: 'bg-amber-50',
    text: 'text-amber-800',
    border: 'border-amber-200',
    dot: 'bg-amber-500',
    label: 'Admitido a Exame'
  },
  DISPENSADO: {
    bg: 'bg-indigo-50',
    text: 'text-indigo-800',
    border: 'border-indigo-200',
    dot: 'bg-indigo-500',
    label: 'Dispensado de Exame'
  },
  HOMOLOGADA: {
    bg: 'bg-emerald-50',
    text: 'text-emerald-800',
    border: 'border-emerald-200',
    dot: 'bg-emerald-500',
    label: 'Homologada'
  },
  RASCUNHO: {
    bg: 'bg-slate-50',
    text: 'text-slate-700',
    border: 'border-slate-200',
    dot: 'bg-slate-400',
    label: 'Rascunho'
  },

  // Documentos
  AUTENTICO: {
    bg: 'bg-emerald-50',
    text: 'text-emerald-800',
    border: 'border-emerald-200',
    dot: 'bg-emerald-500',
    label: 'Autêntico'
  },
  REVOGADO: {
    bg: 'bg-rose-50',
    text: 'text-rose-800',
    border: 'border-rose-200',
    dot: 'bg-rose-500',
    label: 'Revogado'
  },
  SUSPEITO: {
    bg: 'bg-amber-50',
    text: 'text-amber-800',
    border: 'border-amber-200',
    dot: 'bg-amber-500',
    label: 'Pendente Validação'
  }
};

export const StatusBadge: React.FC<StatusBadgeProps> = ({
  status,
  variant,
  size = 'md',
  className = ''
}) => {
  const key = (variant || status || '').toUpperCase();
  const config = BADGE_CONFIG[key] || {
    bg: 'bg-slate-100',
    text: 'text-slate-700',
    border: 'border-slate-200',
    dot: 'bg-slate-400',
    label: status
  };

  const sizeClasses = size === 'sm' ? 'px-2 py-0.5 text-[10px]' : 'px-2.5 py-1 text-xs';

  return (
    <span
      className={`inline-flex items-center gap-1.5 font-medium border rounded-md ${config.bg} ${config.text} ${config.border} ${sizeClasses} ${className}`}
    >
      <span className={`h-1.5 w-1.5 rounded-full ${config.dot} shrink-0`} />
      <span>{config.label || status}</span>
    </span>
  );
};
