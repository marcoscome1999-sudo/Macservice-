/**
 * EduGest Moçambique - Menu Lateral de Navegação (Sidebar)
 * Contém todos os módulos do sistema organizados por áreas lógicas,
 * respeitando os perfis de acesso do utilizador.
 */

import React from 'react';
import { useApp, NavSection } from '../../context/AppContext';
import {
  LayoutDashboard,
  Users,
  GraduationCap,
  ClipboardList,
  Layers,
  BookOpen,
  Calculator,
  FileSpreadsheet,
  CalendarCheck,
  Clock,
  Wallet,
  FileCheck,
  ShieldCheck,
  ArrowLeftRight,
  BarChart3,
  Megaphone,
  Sliders,
  History,
  Database,
  ChevronRight,
  Award,
  Calendar,
  Building,
  KeyRound,
  FileText
} from 'lucide-react';

interface NavItem {
  id: NavSection;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: string;
}

export const Sidebar: React.FC<{ isOpen: boolean; onCloseMobile?: () => void }> = ({
  isOpen,
  onCloseMobile
}) => {
  const { activeTab, setActiveTab, currentUser } = useApp();

  // Construção dos Grupos de Menus adaptados dinamicamente ao perfil ativo
  const navGroups: { groupName: string; items: NavItem[] }[] = React.useMemo(() => {
    const role = currentUser.role;

    if (role === 'ALUNO') {
      return [
        {
          groupName: 'Espaço do Aluno',
          items: [
            { id: 'portal-aluno', label: 'Meu Boletim & Notas', icon: Award },
            { id: 'calendario', label: 'Calendário Escolar', icon: Calendar },
            { id: 'comunicacao', label: 'Avisos da Escola', icon: Megaphone },
            { id: 'validar-documento', label: 'Validar Declaração (QR)', icon: ShieldCheck }
          ]
        }
      ];
    }

    if (role === 'ENCARREGADO') {
      return [
        {
          groupName: 'Acompanhamento Escolar',
          items: [
            { id: 'portal-encarregado', label: 'Painel do Educando', icon: Users },
            { id: 'calendario', label: 'Calendário Escolar', icon: Calendar },
            { id: 'comunicacao', label: 'Comunicados aos Pais', icon: Megaphone },
            { id: 'validar-documento', label: 'Validar Documentos', icon: ShieldCheck }
          ]
        }
      ];
    }

    if (role === 'PROFESSOR') {
      return [
        {
          groupName: 'Espaço Pedagógico Docente',
          items: [
            { id: 'portal-professor', label: 'Portal do Professor', icon: GraduationCap },
            { id: 'pautas', label: 'Pautas de Turma (SNE)', icon: FileSpreadsheet, badge: 'SNE' },
            { id: 'calendario', label: 'Calendário Escolar 2026', icon: Calendar },
            { id: 'comunicacao', label: 'Avisos & Comunicados', icon: Megaphone }
          ]
        }
      ];
    }

    if (role === 'DIRECAO') {
      return [
        {
          groupName: 'Gestão Executiva',
          items: [
            { id: 'portal-direcao', label: 'Painel da Direção', icon: Award, badge: 'HOMOLOGAÇÃO' },
            { id: 'dashboard', label: 'Visão Geral da Escola', icon: LayoutDashboard }
          ]
        },
        {
          groupName: 'Pedagógico & Pautas',
          items: [
            { id: 'pautas', label: 'Pautas Oficiais', icon: FileSpreadsheet },
            { id: 'professores', label: 'Corpo Docente', icon: GraduationCap },
            { id: 'turmas', label: 'Turmas & Salas', icon: Layers },
            { id: 'alunos', label: 'Efectivo de Alunos', icon: Users }
          ]
        },
        {
          groupName: 'Relatórios & Expediente',
          items: [
            { id: 'relatorios', label: 'Relatórios Estatísticos', icon: BarChart3 },
            { id: 'calendario', label: 'Calendário Escolar SNE', icon: Calendar },
            { id: 'comunicacao', label: 'Comunicados Oficiais', icon: Megaphone },
            { id: 'documentos', label: 'Emissão de Documentos', icon: FileCheck },
            { id: 'validar-documento', label: 'Validação Pública (QR)', icon: ShieldCheck }
          ]
        }
      ];
    }

    if (role === 'SECRETARIA') {
      return [
        {
          groupName: 'Secretaria Escolar',
          items: [
            { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
            { id: 'alunos', label: 'Registo de Alunos', icon: Users },
            { id: 'matriculas', label: 'Matrículas & Vagas', icon: ClipboardList },
            { id: 'turmas', label: 'Turmas & Salas', icon: Layers }
          ]
        },
        {
          groupName: 'Expediente & Documentação',
          items: [
            { id: 'documentos', label: 'Emissão de Documentos', icon: FileCheck },
            { id: 'validar-documento', label: 'Validação Pública (QR)', icon: ShieldCheck },
            { id: 'transferencias', label: 'Guias de Transferência', icon: ArrowLeftRight },
            { id: 'pagamentos', label: 'Propinas & Recibos', icon: Wallet }
          ]
        },
        {
          groupName: 'Planeamento & Comunicação',
          items: [
            { id: 'horarios', label: 'Horários Escolares', icon: Clock },
            { id: 'calendario', label: 'Calendário Escolar', icon: Calendar },
            { id: 'comunicacao', label: 'Comunicação & Avisos', icon: Megaphone }
          ]
        }
      ];
    }

    // Perfil ADMINISTRADOR (Acesso Integral)
    return [
      {
        groupName: 'Geral & Visão',
        items: [
          { id: 'dashboard', label: 'Dashboard Geral', icon: LayoutDashboard }
        ]
      },
      {
        groupName: 'Gestão Escolar',
        items: [
          { id: 'alunos', label: 'Alunos', icon: Users },
          { id: 'professores', label: 'Professores', icon: GraduationCap },
          { id: 'matriculas', label: 'Matrículas & Vagas', icon: ClipboardList },
          { id: 'turmas', label: 'Turmas & Salas', icon: Layers },
          { id: 'disciplinas', label: 'Disciplinas', icon: BookOpen }
        ]
      },
      {
        groupName: 'Pedagógico & Avaliação',
        items: [
          { id: 'avaliacoes', label: 'Lançamento de Notas', icon: Calculator },
          { id: 'pautas', label: 'Pautas Oficiais', icon: FileSpreadsheet, badge: 'SNE' },
          { id: 'assiduidade', label: 'Assiduidade & Presenças', icon: CalendarCheck },
          { id: 'horarios', label: 'Horários Escolares', icon: Clock }
        ]
      },
      {
        groupName: 'Finanças & Secretaria',
        items: [
          { id: 'pagamentos', label: 'Propinas & Pagamentos', icon: Wallet },
          { id: 'documentos', label: 'Emissão de Documentos', icon: FileCheck },
          { id: 'validar-documento', label: 'Validação Pública (QR)', icon: ShieldCheck },
          { id: 'transferencias', label: 'Transferências', icon: ArrowLeftRight }
        ]
      },
      {
        groupName: 'Relatórios & Calendário',
        items: [
          { id: 'relatorios', label: 'Relatórios Estatísticos', icon: BarChart3 },
          { id: 'calendario', label: 'Calendário Escolar SNE', icon: Calendar },
          { id: 'comunicacao', label: 'Comunicação & Avisos', icon: Megaphone }
        ]
      },
      {
        groupName: 'Administração & Segurança',
        items: [
          { id: 'utilizadores', label: 'Utilizadores & Códigos', icon: KeyRound, badge: 'ADMIN' },
          { id: 'sne-config', label: 'Configuração SNE Nacional', icon: Sliders, badge: 'MINEDH' },
          { id: 'auditoria', label: 'Logs de Auditoria', icon: History },
          { id: 'backup', label: 'Backup & Dados', icon: Database }
        ]
      }
    ];
  }, [currentUser.role]);

  const handleNavClick = (id: NavSection) => {
    setActiveTab(id);
    if (onCloseMobile) {
      onCloseMobile();
    }
  };

  return (
    <>
      {/* Backdrop para mobile */}
      {isOpen && (
        <div
          onClick={onCloseMobile}
          className="fixed inset-0 z-40 bg-slate-900/40 backdrop-blur-xs lg:hidden"
        />
      )}

      <aside
        className={`no-print fixed inset-y-0 left-0 z-40 flex w-64 flex-col border-r border-slate-200 bg-white transition-transform duration-300 lg:static lg:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Logotipo / Brand Header */}
        <div className="flex h-16 items-center justify-between border-b border-slate-200 px-4 bg-white">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-slate-900 text-white shadow-xs">
              <GraduationCap className="h-5 w-5 text-sky-400" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-sm tracking-tight text-slate-900">
                  EduGest Moçambique
                </span>
              </div>
              <p className="text-[10px] font-medium text-slate-500 uppercase tracking-wider truncate">
                SIGE • MINEDH / SNE
              </p>
            </div>
          </div>
        </div>

        {/* Lista de Navegação com Grupos */}
        <div className="flex-1 overflow-y-auto px-3 py-4 space-y-5 custom-scrollbar">
          {navGroups.map((group) => (
            <div key={group.groupName} className="space-y-0.5">
              <p className="px-2.5 pb-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                {group.groupName}
              </p>
              {group.items.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;

                return (
                  <button
                    key={item.id}
                    onClick={() => handleNavClick(item.id)}
                    className={`group flex w-full items-center justify-between rounded-md px-2.5 py-1.5 text-xs font-medium transition-colors ${
                      isActive
                        ? 'bg-slate-100 text-slate-900 font-semibold border-l-2 border-sky-600 pl-2'
                        : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <Icon
                        className={`h-4 w-4 shrink-0 transition-colors ${
                          isActive ? 'text-sky-700' : 'text-slate-400 group-hover:text-slate-600'
                        }`}
                      />
                      <span className="truncate">{item.label}</span>
                    </div>

                    {item.badge ? (
                      <span className="rounded bg-slate-100 px-1.5 py-0.2 text-[9px] font-semibold text-slate-600 border border-slate-200">
                        {item.badge}
                      </span>
                    ) : isActive ? (
                      <ChevronRight className="h-3 w-3 text-slate-400" />
                    ) : null}
                  </button>
                );
              })}
            </div>
          ))}
        </div>

        {/* Rodapé da Sidebar: Info da Sessão & Perfil */}
        <div className="border-t border-slate-200 p-3 bg-slate-50">
          <div className="rounded-lg border border-slate-200 bg-white p-2.5 shadow-xs">
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                Sessão Activa
              </span>
              <span className="rounded bg-slate-100 px-1.5 py-0.5 text-[9px] font-bold text-slate-700 border border-slate-200">
                {currentUser.role}
              </span>
            </div>
            <p className="truncate text-xs font-bold text-slate-900">{currentUser.name}</p>
            <p className="truncate text-[11px] text-slate-500">{currentUser.email}</p>
          </div>
        </div>
      </aside>
    </>
  );
};
