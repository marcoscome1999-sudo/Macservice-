/**
 * EduGest Moçambique - Cabeçalho Principal (Header)
 * Inclui alternador de escolas (SaaS), alternador de papéis (RBAC Demo),
 * notificações, pesquisa e botão de instalação PWA.
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { usePWAInstall, useOnlineStatus } from '../../hooks/usePWAInstall';
import { UserRole } from '../../types';
import { LoginModal } from '../auth/LoginModal';
import {
  School,
  UserCheck,
  Bell,
  Download,
  Wifi,
  WifiOff,
  Search,
  CheckCircle2,
  AlertTriangle,
  FileText,
  CreditCard,
  X,
  KeyRound,
  LogOut
} from 'lucide-react';

export const Header: React.FC<{ onSearchTrigger?: (term: string) => void }> = ({ onSearchTrigger }) => {
  const {
    currentSchool,
    currentUser,
    switchRole,
    switchSchool,
    db,
    setActiveTab,
    logout
  } = useApp();

  const { isInstallable, install, isIOS } = usePWAInstall();
  const isOnline = useOnlineStatus();
  const [showNotifications, setShowNotifications] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [showIOSPrompt, setShowIOSPrompt] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);

  const roles: { role: UserRole; label: string; desc: string }[] = [
    { role: 'ADMIN', label: 'Administrador Geral', desc: 'Acesso total e gestão de escolas' },
    { role: 'DIRECAO', label: 'Direcção Escolar', desc: 'Aprovação, pautas e estatísticas' },
    { role: 'SECRETARIA', label: 'Secretaria', desc: 'Matrículas, pagamentos e processos' },
    { role: 'PROFESSOR', label: 'Professor', desc: 'Notas, presenças e turmas' },
    { role: 'ENCARREGADO', label: 'Encarregado', desc: 'Acompanhamento do educando' },
    { role: 'ALUNO', label: 'Aluno', desc: 'Consulta de notas, faltas e avisos' }
  ];

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      if (onSearchTrigger) {
        onSearchTrigger(searchTerm.trim());
      } else {
        setActiveTab('alunos');
      }
    }
  };

  return (
    <header className="no-print sticky top-0 z-30 flex h-16 w-full items-center justify-between border-b border-slate-200 bg-white/95 px-4 backdrop-blur-md transition-all sm:px-6">
      {/* Lado Esquerdo: Identidade da Escola & Conectividade */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2">
          {/* Seletor de Escola (Multi-Escola SaaS) */}
          <div className="relative flex items-center">
            <School className="h-5 w-5 text-sky-600 mr-1.5 shrink-0" />
            <select
              aria-label="Selecionar Escola"
              value={currentSchool.id}
              onChange={(e) => switchSchool(e.target.value)}
              className="max-w-[180px] sm:max-w-xs truncate rounded-lg border border-slate-200 bg-slate-50 py-1.5 pl-2.5 pr-8 text-xs sm:text-sm font-semibold text-slate-800 focus:border-sky-500 focus:bg-white focus:outline-none focus:ring-1 focus:ring-sky-500"
            >
              {db.schools.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.province})
                </option>
              ))}
            </select>
          </div>

          <span className="hidden text-xs text-slate-400 md:inline">|</span>
          <span className="hidden rounded bg-emerald-50 px-2 py-0.5 text-xs font-semibold text-emerald-700 border border-emerald-200 md:inline">
            Ano 2026 • 1º Trimestre
          </span>
        </div>

        {/* Indicador Online / Offline */}
        <div className="hidden items-center gap-1.5 lg:flex">
          {isOnline ? (
            <span className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-2.5 py-0.5 text-[11px] font-medium text-slate-600">
              <Wifi className="h-3 w-3 text-emerald-500" />
              Sincronizado
            </span>
          ) : (
            <span className="inline-flex items-center gap-1 rounded-full bg-amber-100 px-2.5 py-0.5 text-[11px] font-medium text-amber-800 animate-pulse">
              <WifiOff className="h-3 w-3 text-amber-600" />
              Modo Offline (Cache Local)
            </span>
          )}
        </div>
      </div>

      {/* Barra de Pesquisa Rápida */}
      <div className="hidden max-w-xs flex-1 px-4 sm:block md:max-w-sm">
        <form onSubmit={handleSearch} className="relative">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Pesquisar por aluno, nº de processo, NUIT..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full rounded-lg border border-slate-200 bg-slate-50 py-1.5 pl-9 pr-8 text-xs text-slate-800 placeholder-slate-400 transition-colors focus:border-sky-500 focus:bg-white focus:outline-none focus:ring-1 focus:ring-sky-500"
          />
        </form>
      </div>

      {/* Lado Direito: PWA Install, Notificações, Seletor de Perfil RBAC */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Botão de Instalar PWA */}
        {isInstallable && (
          <button
            onClick={install}
            className="flex items-center gap-1.5 rounded-lg bg-slate-900 px-2.5 py-1.5 text-xs font-semibold text-white hover:bg-slate-800 transition"
            title="Instalar EduGest no seu dispositivo"
          >
            <Download className="h-3.5 w-3.5 text-sky-400" />
            <span className="hidden sm:inline">Instalar App</span>
          </button>
        )}

        {isIOS && (
          <button
            onClick={() => setShowIOSPrompt(true)}
            className="flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50"
          >
            <Download className="h-3.5 w-3.5 text-slate-500" />
            <span className="hidden sm:inline">App iOS</span>
          </button>
        )}

        {/* Notificações */}
        <div className="relative">
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="relative rounded-lg p-2 text-slate-600 hover:bg-slate-100 transition focus:outline-none"
            aria-label="Notificações da Escola"
          >
            <Bell className="h-4 w-4" />
            {db.notifications.length > 0 && (
              <span className="absolute right-1.5 top-1.5 flex h-2 w-2">
                <span className="relative inline-flex h-2 w-2 rounded-full bg-rose-600"></span>
              </span>
            )}
          </button>

          {/* Painel Dropdown de Notificações */}
          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 sm:w-96 rounded-lg border border-slate-200 bg-white p-4 shadow-lg z-50">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div className="flex items-center gap-2">
                  <Bell className="h-4 w-4 text-slate-700" />
                  <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wider">
                    Comunicados & Notificações
                  </h4>
                </div>
                <button
                  onClick={() => setShowNotifications(false)}
                  className="text-slate-400 hover:text-slate-600"
                  aria-label="Fechar"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
              <div className="mt-3 max-h-72 space-y-2 overflow-y-auto pr-1 text-xs">
                {(!db.notifications || db.notifications.length === 0) ? (
                  <p className="py-6 text-center text-xs text-slate-400">Nenhum alerta ou notificação recente.</p>
                ) : (
                  (db.notifications || []).map((notif) => (
                    <div
                      key={notif.id}
                      className="rounded-lg border border-slate-100 bg-slate-50 p-2.5 hover:bg-slate-100/80 transition"
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-semibold text-[10px] uppercase tracking-wide text-slate-600">
                          {notif.category} • {notif.channel}
                        </span>
                        <span className="text-[10px] text-slate-400">{notif.createdAt}</span>
                      </div>
                      <p className="font-semibold text-slate-900 mb-0.5">{notif.title}</p>
                      <p className="text-slate-600 text-[11px] line-clamp-2">{notif.body}</p>
                    </div>
                  ))
                )}
              </div>
              <div className="mt-3 pt-2 border-t border-slate-100 text-center">
                <button
                  onClick={() => {
                    setShowNotifications(false);
                    setActiveTab('comunicacao');
                  }}
                  className="text-xs font-semibold text-slate-700 hover:text-slate-900"
                >
                  Ver Todos os Comunicados →
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Alternador Rápido de Perfil / Role Switcher Demo */}
        <div className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-2 py-1">
          <div className="flex h-6 w-6 items-center justify-center rounded bg-slate-900 font-bold text-white text-[11px]">
            {currentUser.name.charAt(0)}
          </div>
          <div className="hidden text-left lg:block pr-1">
            <div className="flex items-center gap-1">
              <p className="text-xs font-bold text-slate-900 leading-tight">{currentUser.name}</p>
              {currentUser.accessCode && (
                <span className="font-mono text-[9px] font-bold text-sky-800 bg-sky-100/70 px-1 py-0.2 rounded">
                  {currentUser.accessCode}
                </span>
              )}
            </div>
            <p className="text-[9px] font-semibold text-slate-500 uppercase">{currentUser.role}</p>
          </div>
          <select
            aria-label="Alternar Perfil Demo"
            value={currentUser.role}
            onChange={(e) => switchRole(e.target.value as UserRole)}
            className="rounded border-0 bg-transparent py-0.5 pl-1 pr-6 text-xs font-semibold text-slate-700 focus:outline-none cursor-pointer"
          >
            {roles.map((r) => (
              <option key={r.role} value={r.role}>
                {r.role} - {r.label}
              </option>
            ))}
          </select>
        </div>

        {/* Botão para Abrir Login com Código SNE */}
        <button
          onClick={() => setShowLoginModal(true)}
          className="hidden sm:inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-bold text-slate-700 hover:bg-slate-50 transition"
          title="Autenticar com Código Único ou Testar Perfis"
        >
          <KeyRound className="h-3.5 w-3.5 text-sky-600" />
          <span>Login SNE</span>
        </button>

        {/* Botão de Terminar Sessão */}
        <button
          onClick={logout}
          className="inline-flex items-center justify-center rounded-lg border border-slate-200 p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 transition"
          title="Terminar Sessão"
        >
          <LogOut className="h-4 w-4" />
        </button>
      </div>

      {/* Modal de Autenticação Real */}
      <LoginModal isOpen={showLoginModal} onClose={() => setShowLoginModal(false)} />

      {/* Modal Guia iOS Safari */}
      {showIOSPrompt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-sm rounded-2xl bg-white p-6 shadow-2xl">
            <h3 className="text-lg font-bold text-slate-900">Instalar EduGest no iPhone / iPad</h3>
            <p className="mt-2 text-sm text-slate-600 leading-relaxed">
              1. Toque no botão de <strong>Partilhar</strong> (ícone do quadrado com seta para cima) na barra do Safari.<br />
              2. Desça a lista e selecione <strong>Adicionar ao Ecrã Principal</strong>.<br />
              3. O EduGest Moçambique ficará acessível como uma aplicação nativa!
            </p>
            <button
              onClick={() => setShowIOSPrompt(false)}
              className="mt-5 w-full rounded-xl bg-sky-600 py-2.5 text-sm font-semibold text-white hover:bg-sky-700"
            >
              Entendido
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
