/**
 * EduGest Moçambique - Horários Escolares (SchedulesView)
 * Grelha de horários por turma, por professor e por sala.
 * Deteção automática e em tempo real de conflitos:
 * - Professor em duas turmas no mesmo horário
 * - Sala de aula ocupada no mesmo tempo
 * - Turma com sobreposição de aulas simultâneas
 */

import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { ScheduleSlot } from '../../types';
import {
  Clock,
  Plus,
  Trash2,
  AlertTriangle,
  Layers,
  GraduationCap,
  DoorOpen,
  CheckCircle2,
  X
} from 'lucide-react';

const DAYS = ['Segunda-Feira', 'Terça-Feira', 'Quarta-Feira', 'Quinta-Feira', 'Sexta-Feira'];
const SLOTS = [
  { slot: 1, time: '07:00 - 07:45' },
  { slot: 2, time: '07:50 - 08:35' },
  { slot: 3, time: '08:45 - 09:30' },
  { slot: 4, time: '09:35 - 10:20' },
  { slot: 5, time: '10:40 - 11:25' },
  { slot: 6, time: '11:30 - 12:15' }
];

export const SchedulesView: React.FC = () => {
  const { db, addScheduleSlot, deleteScheduleSlot } = useApp();

  const [viewMode, setViewMode] = useState<'TURMA' | 'PROFESSOR' | 'SALA'>('TURMA');
  const [selectedEntity, setSelectedEntity] = useState<string>(db.sections[0]?.name || 'Turma 10A');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [conflictAlert, setConflictAlert] = useState<string | null>(null);

  const [slotForm, setSlotForm] = useState<Omit<ScheduleSlot, 'id'>>({
    schoolId: db.schools[0]?.id || 'school-1',
    sectionId: db.sections[0]?.name || 'Turma 10A',
    subjectId: db.subjects[0]?.name || 'Matemática',
    teacherId: db.teachers[0]?.id || 'prof-1',
    teacherName: db.teachers[0]?.fullName || 'Professor',
    dayOfWeek: 'Segunda-Feira',
    slotNumber: 1,
    startTime: '07:00',
    endTime: '07:45',
    classroom: 'Sala 05'
  });

  // Horários filtrados segundo o modo de visualização
  const filteredSlots = useMemo(() => {
    return db.schedules.filter((s) => {
      if (viewMode === 'TURMA') return s.sectionId === selectedEntity;
      if (viewMode === 'PROFESSOR') return s.teacherId === selectedEntity || s.teacherName === selectedEntity;
      if (viewMode === 'SALA') return s.classroom.toLowerCase() === selectedEntity.toLowerCase();
      return true;
    });
  }, [db.schedules, viewMode, selectedEntity]);

  const handleAddSlot = (e: React.FormEvent) => {
    e.preventDefault();
    setConflictAlert(null);

    const teacher = db.teachers.find((t) => t.id === slotForm.teacherId);
    const selectedSlotTime = SLOTS.find((s) => s.slot === slotForm.slotNumber);

    const result = addScheduleSlot({
      ...slotForm,
      teacherName: teacher?.fullName || slotForm.teacherName,
      startTime: selectedSlotTime?.time.split(' - ')[0] || '07:00',
      endTime: selectedSlotTime?.time.split(' - ')[1] || '07:45'
    });

    if (result.success) {
      setIsModalOpen(false);
    } else {
      setConflictAlert(result.conflictReason || 'Conflito de horário detectado.');
    }
  };

  return (
    <div className="space-y-6">
      {/* Cabeçalho */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
            <Clock className="h-6 w-6 text-sky-600" />
            Horários Escolares & Gestão de Tempos
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Deteção inteligente de choques de horário, sobreposições de docentes e ocupação de salas.
          </p>
        </div>

        <button
          onClick={() => {
            setConflictAlert(null);
            setIsModalOpen(true);
          }}
          className="flex items-center gap-1.5 rounded-xl bg-sky-600 px-3.5 py-2 text-xs font-bold text-white shadow-sm hover:bg-sky-700 transition"
        >
          <Plus className="h-4 w-4" />
          Alocar Tempo de Aula
        </button>
      </div>

      {/* Controles de Visualização: Turma, Professor ou Sala */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setViewMode('TURMA');
              setSelectedEntity(db.sections[0]?.name || 'Turma 10A');
            }}
            className={`rounded-xl px-3 py-1.5 text-xs font-bold transition ${
              viewMode === 'TURMA' ? 'bg-sky-600 text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            Por Turma
          </button>
          <button
            onClick={() => {
              setViewMode('PROFESSOR');
              setSelectedEntity(db.teachers[0]?.id || 'prof-1');
            }}
            className={`rounded-xl px-3 py-1.5 text-xs font-bold transition ${
              viewMode === 'PROFESSOR' ? 'bg-sky-600 text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            Por Docente
          </button>
          <button
            onClick={() => {
              setViewMode('SALA');
              setSelectedEntity('Sala 05');
            }}
            className={`rounded-xl px-3 py-1.5 text-xs font-bold transition ${
              viewMode === 'SALA' ? 'bg-sky-600 text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            Por Sala
          </button>
        </div>

        {/* Seletor da Entidade */}
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-slate-500">Selecionar:</span>
          {viewMode === 'TURMA' && (
            <select
              value={selectedEntity}
              onChange={(e) => setSelectedEntity(e.target.value)}
              className="rounded-xl border border-slate-200 bg-slate-50 py-1.5 px-3 text-xs font-bold text-slate-800 focus:border-sky-500 focus:outline-none"
            >
              {db.sections.map((s) => (
                <option key={s.id} value={s.name}>
                  {s.gradeLevel} - {s.name}
                </option>
              ))}
            </select>
          )}

          {viewMode === 'PROFESSOR' && (
            <select
              value={selectedEntity}
              onChange={(e) => setSelectedEntity(e.target.value)}
              className="rounded-xl border border-slate-200 bg-slate-50 py-1.5 px-3 text-xs font-bold text-slate-800 focus:border-sky-500 focus:outline-none"
            >
              {db.teachers.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.fullName}
                </option>
              ))}
            </select>
          )}

          {viewMode === 'SALA' && (
            <select
              value={selectedEntity}
              onChange={(e) => setSelectedEntity(e.target.value)}
              className="rounded-xl border border-slate-200 bg-slate-50 py-1.5 px-3 text-xs font-bold text-slate-800 focus:border-sky-500 focus:outline-none"
            >
              <option value="Sala 05">Sala 05</option>
              <option value="Sala 08">Sala 08</option>
              <option value="Laboratório">Laboratório de Ciências</option>
              <option value="Sala de Informática">Sala de Informática</option>
            </select>
          )}
        </div>
      </div>

      {/* Grelha Semanal de Horários */}
      <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-900 text-white font-bold uppercase text-[11px]">
              <tr>
                <th className="py-3 px-3 w-28 text-center border-r border-slate-800">Tempo / Horário</th>
                {DAYS.map((day) => (
                  <th key={day} className="py-3 px-3 border-r border-slate-800 text-center min-w-[150px]">
                    {day}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {SLOTS.map((slot) => (
                <tr key={slot.slot} className="hover:bg-slate-50/50">
                  {/* Coluna do Horário */}
                  <td className="py-3 px-2 text-center font-bold bg-slate-50 border-r border-slate-200">
                    <span className="block text-slate-900 font-extrabold">{slot.slot}º Tempo</span>
                    <span className="text-[10px] text-slate-500 font-mono">{slot.time}</span>
                  </td>

                  {/* Células dos Dias */}
                  {DAYS.map((day) => {
                    const match = filteredSlots.find(
                      (s) => s.dayOfWeek === day && s.slotNumber === slot.slot
                    );

                    return (
                      <td key={day} className="p-2 border-r border-slate-200 align-top">
                        {match ? (
                          <div className="rounded-xl border border-sky-200 bg-sky-50/80 p-2 text-xs shadow-xs relative group">
                            <p className="font-extrabold text-sky-900 leading-tight">{match.subjectId}</p>
                            <p className="text-[11px] text-slate-700 font-medium mt-0.5">{match.teacherName}</p>
                            <div className="flex items-center justify-between text-[10px] text-slate-500 mt-1 pt-1 border-t border-sky-200/60">
                              <span>{match.sectionId}</span>
                              <span className="font-bold text-sky-800">{match.classroom}</span>
                            </div>

                            <button
                              onClick={() => deleteScheduleSlot(match.id)}
                              className="absolute top-1.5 right-1.5 opacity-0 group-hover:opacity-100 text-rose-500 hover:text-rose-700 transition"
                              title="Remover Tempo"
                            >
                              <Trash2 className="h-3 w-3" />
                            </button>
                          </div>
                        ) : (
                          <div className="h-14 rounded-xl border border-dashed border-slate-200 bg-slate-50/40 flex items-center justify-center text-[10px] text-slate-400">
                            Livre
                          </div>
                        )}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Alocar Tempo com Verificação de Conflitos */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
          <div className="relative w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-4">
              <h3 className="font-extrabold text-slate-900 text-base flex items-center gap-2">
                <Clock className="h-5 w-5 text-sky-600" />
                Alocar Tempo no Horário Escolar
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="h-5 w-5" />
              </button>
            </div>

            {conflictAlert && (
              <div className="mb-4 rounded-xl border border-rose-200 bg-rose-50 p-3 text-xs text-rose-800 flex items-start gap-2">
                <AlertTriangle className="h-4 w-4 text-rose-600 shrink-0 mt-0.5" />
                <div>
                  <strong className="block font-bold">Impossível alocar este tempo:</strong>
                  {conflictAlert}
                </div>
              </div>
            )}

            <form onSubmit={handleAddSlot} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Turma *</label>
                <select
                  value={slotForm.sectionId}
                  onChange={(e) => setSlotForm({ ...slotForm, sectionId: e.target.value })}
                  className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-sky-500 focus:outline-none"
                >
                  {db.sections.map((s) => (
                    <option key={s.id} value={s.name}>
                      {s.gradeLevel} - {s.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Dia da Semana *</label>
                  <select
                    value={slotForm.dayOfWeek}
                    onChange={(e) => setSlotForm({ ...slotForm, dayOfWeek: e.target.value })}
                    className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-sky-500 focus:outline-none"
                  >
                    {DAYS.map((d) => (
                      <option key={d} value={d}>{d}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Tempo de Aula *</label>
                  <select
                    value={slotForm.slotNumber}
                    onChange={(e) => setSlotForm({ ...slotForm, slotNumber: Number(e.target.value) })}
                    className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-sky-500 focus:outline-none"
                  >
                    {SLOTS.map((s) => (
                      <option key={s.slot} value={s.slot}>
                        {s.slot}º Tempo ({s.time})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Disciplina Curricular *</label>
                <select
                  value={slotForm.subjectId}
                  onChange={(e) => setSlotForm({ ...slotForm, subjectId: e.target.value })}
                  className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-sky-500 focus:outline-none"
                >
                  {db.subjects.map((sub) => (
                    <option key={sub.id} value={sub.name}>
                      {sub.name} ({sub.code})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Docente *</label>
                  <select
                    value={slotForm.teacherId}
                    onChange={(e) => setSlotForm({ ...slotForm, teacherId: e.target.value })}
                    className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-sky-500 focus:outline-none"
                  >
                    {db.teachers.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.fullName}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Sala de Aula *</label>
                  <input
                    type="text"
                    required
                    value={slotForm.classroom}
                    onChange={(e) => setSlotForm({ ...slotForm, classroom: e.target.value })}
                    className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-sky-500 focus:outline-none"
                    placeholder="Sala 05"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-4 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="rounded-xl bg-slate-100 px-4 py-2 font-bold text-slate-700 hover:bg-slate-200 text-xs"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-sky-600 px-5 py-2 font-bold text-white hover:bg-sky-700 text-xs shadow-sm"
                >
                  Validar e Alocar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
