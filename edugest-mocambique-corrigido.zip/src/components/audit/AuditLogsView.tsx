/**
 * EduGest Moçambique - Auditoria do Sistema & Cópias de Segurança (AuditLogsView)
 * Registo de todas as ações sensíveis (alterações de notas, emissão de documentos,
 * transações financeiras, matrículas) com carimbo de data/hora, perfil e utilizador.
 * Ferramenta completa de Backup JSON e Restauração de Dados.
 */

import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import {
  ShieldAlert,
  Search,
  Database,
  Download,
  Upload,
  RotateCcw,
  CheckCircle2,
  Clock,
  User,
  Filter
} from 'lucide-react';

export const AuditLogsView: React.FC = () => {
  const { db, currentSchool, restoreDatabase, resetToSampleData } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRoleFilter, setSelectedRoleFilter] = useState('ALL');
  const [notificationMsg, setNotificationMsg] = useState<string | null>(null);

  const filteredLogs = useMemo(() => {
    return db.auditLogs.filter((log) => {
      const matchSearch =
        log.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        log.action.toLowerCase().includes(searchTerm.toLowerCase()) ||
        log.details.toLowerCase().includes(searchTerm.toLowerCase());

      const matchRole = selectedRoleFilter === 'ALL' || log.userRole === selectedRoleFilter;

      return matchSearch && matchRole;
    });
  }, [db.auditLogs, searchTerm, selectedRoleFilter]);

  // Exportar Backup JSON
  const handleExportBackup = () => {
    const jsonStr = JSON.stringify(db, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute(
      'download',
      `EduGest_MZ_Backup_${currentSchool.name.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.json`
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setNotificationMsg('Cópia de segurança gerada e descarregada com sucesso.');
    setTimeout(() => setNotificationMsg(null), 3000);
  };

  // Importar / Restaurar Backup JSON
  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const parsed = JSON.parse(evt.target?.result as string);
        if (parsed.students && parsed.schools) {
          restoreDatabase(parsed);
          setNotificationMsg('Dados restaurados com sucesso a partir do ficheiro de backup.');
        } else {
          setNotificationMsg('Ficheiro inválido: Formato de base de dados EduGest não reconhecido.');
        }
      } catch (err) {
        setNotificationMsg('Erro ao ler ficheiro JSON.');
      }
      setTimeout(() => setNotificationMsg(null), 3000);
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6">
      {/* Cabeçalho */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
            <ShieldAlert className="h-6 w-6 text-sky-600" />
            Auditoria de Segurança & Cópias de Segurança (Backup)
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Rastreabilidade total de operações, alteração de notas, recibos emitidos e cópias de segurança.
          </p>
        </div>
      </div>

      {notificationMsg && (
        <div className="rounded-xl border border-sky-200 bg-sky-50 p-3 text-xs font-bold text-sky-900 flex items-center gap-2 shadow-xs">
          <CheckCircle2 className="h-4 w-4 text-sky-600 shrink-0" />
          {notificationMsg}
        </div>
      )}

      {/* Cartões de Backup e Restauração */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 text-sky-600 mb-2">
              <Download className="h-5 w-5" />
              <h4 className="font-extrabold text-slate-900 text-xs uppercase">Descarregar Backup</h4>
            </div>
            <p className="text-xs text-slate-500 leading-relaxed">
              Exporte todos os alunos, notas, pautas, pagamentos e configurações num ficheiro JSON seguro.
            </p>
          </div>

          <button
            onClick={handleExportBackup}
            className="mt-4 w-full rounded-xl bg-sky-600 py-2 text-xs font-bold text-white hover:bg-sky-700 transition flex items-center justify-center gap-1.5 shadow-xs"
          >
            <Download className="h-4 w-4" />
            Exportar Base de Dados
          </button>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 text-emerald-600 mb-2">
              <Upload className="h-5 w-5" />
              <h4 className="font-extrabold text-slate-900 text-xs uppercase">Restaurar Ficheiro</h4>
            </div>
            <p className="text-xs text-slate-500 leading-relaxed">
              Restaure um backup anterior previamente guardado para recuperar registos de anos lectivos.
            </p>
          </div>

          <label className="mt-4 w-full rounded-xl border border-slate-300 py-2 text-xs font-bold text-slate-700 hover:bg-slate-50 transition flex items-center justify-center gap-1.5 cursor-pointer">
            <Upload className="h-4 w-4 text-slate-500" />
            Importar Ficheiro JSON
            <input type="file" accept=".json" onChange={handleImportBackup} className="hidden" />
          </label>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 text-rose-600 mb-2">
              <RotateCcw className="h-5 w-5" />
              <h4 className="font-extrabold text-slate-900 text-xs uppercase">Repor Dados Demonstração</h4>
            </div>
            <p className="text-xs text-slate-500 leading-relaxed">
              Reinicializa o sistema com escolas moçambicanas, docentes e pautas completas do SNE.
            </p>
          </div>

          <button
            onClick={() => {
              if (window.confirm('Tem a certeza que deseja repor os dados de exemplo do SNE?')) {
                resetToSampleData();
                setNotificationMsg('Sistema reinicializado com os dados padrão de Moçambique.');
                setTimeout(() => setNotificationMsg(null), 3000);
              }
            }}
            className="mt-4 w-full rounded-xl bg-slate-100 py-2 text-xs font-bold text-slate-700 hover:bg-slate-200 transition"
          >
            Repor Dados Iniciais SNE
          </button>
        </div>
      </div>

      {/* Tabela de Logs de Auditoria */}
      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <h3 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
            <Clock className="h-4 w-4 text-slate-500" />
            Registo Cronológico de Atividades ({filteredLogs.length} eventos)
          </h3>

          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-2 h-3.5 w-3.5 text-slate-400" />
              <input
                type="text"
                placeholder="Filtrar eventos..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="rounded-xl border border-slate-200 py-1.5 pl-8 pr-3 text-xs text-slate-800 placeholder-slate-400 focus:border-sky-500 focus:outline-none"
              />
            </div>

            <select
              value={selectedRoleFilter}
              onChange={(e) => setSelectedRoleFilter(e.target.value)}
              className="rounded-xl border border-slate-200 bg-slate-50 py-1.5 px-3 text-xs font-semibold text-slate-700 focus:border-sky-500 focus:outline-none"
            >
              <option value="ALL">Todos os Perfis</option>
              <option value="ADMIN_SISTEMA">Administrador</option>
              <option value="DIRECAO_ESCOLA">Direção</option>
              <option value="SECRETARIA">Secretaria</option>
              <option value="PROFESSOR">Professor</option>
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600">
            <thead className="border-b border-slate-200 bg-slate-50 font-bold uppercase tracking-wider text-slate-500">
              <tr>
                <th className="py-2.5 px-3">Data / Hora</th>
                <th className="py-2.5 px-3">Utilizador & Perfil</th>
                <th className="py-2.5 px-3">Ação Executada</th>
                <th className="py-2.5 px-3">Detalhes Técnicos</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredLogs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-50/80">
                  <td className="py-2.5 px-3 font-mono text-slate-500 text-[11px] whitespace-nowrap">
                    {log.timestamp}
                  </td>
                  <td className="py-2.5 px-3 font-medium text-slate-800">
                    <p className="font-bold">{log.userName}</p>
                    <span className="rounded bg-slate-100 px-1.5 py-0.2 text-[9px] font-mono text-slate-500">
                      {log.userRole}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 font-bold text-sky-800">
                    {log.action}
                  </td>
                  <td className="py-2.5 px-3 text-slate-600 text-[11px] max-w-md truncate">
                    {log.details}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
