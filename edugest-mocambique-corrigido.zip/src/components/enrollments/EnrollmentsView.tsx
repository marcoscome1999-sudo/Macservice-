/**
 * EduGest Moçambique - Matrículas & Gestão de Vagas (EnrollmentsView)
 * Processo de matrícula e renovação anual, confirmação documental,
 * emissão de comprovativo de matrícula e controlo de vagas por classe.
 */

import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { Enrollment } from '../../types';
import {
  ClipboardCheck,
  UserPlus,
  Search,
  CheckCircle2,
  Clock,
  Printer,
  FileText,
  Download,
  Filter,
  X
} from 'lucide-react';

export const EnrollmentsView: React.FC = () => {
  const { db, createEnrollment, updateEnrollmentStatus, currentSchool } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<'ALL' | 'CONFIRMADA' | 'PENDENTE' | 'CANCELADA'>('ALL');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [receiptToPrint, setReceiptToPrint] = useState<Enrollment | null>(null);

  const [formData, setFormData] = useState({
    studentId: db.students[0]?.id || 'std-1',
    gradeLevel: '10ª Classe',
    sectionName: 'Turma A',
    academicYear: 2026,
    date: new Date().toISOString().split('T')[0],
    guardianName: '',
    guardianPhone: '+258 84 ',
    documentsDelivered: ['BI / Cédula', 'Certificado Anterior', 'Fotografias tipo passe']
  });

  const filteredEnrollments = useMemo(() => {
    return db.enrollments.filter((enr) => {
      const matchSearch =
        enr.studentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        enr.enrollmentNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        enr.guardianName.toLowerCase().includes(searchTerm.toLowerCase());

      const matchStatus = selectedStatus === 'ALL' || enr.status === selectedStatus;

      return matchSearch && matchStatus;
    });
  }, [db.enrollments, searchTerm, selectedStatus]);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const student = db.students.find((s) => s.id === formData.studentId);
    if (!student) return;

    const newEnr = createEnrollment({
      studentId: student.id,
      studentName: student.fullName,
      academicYear: formData.academicYear,
      gradeLevel: formData.gradeLevel,
      sectionName: formData.sectionName,
      date: formData.date,
      status: 'CONFIRMADA',
      guardianName: formData.guardianName || student.guardianName,
      guardianPhone: formData.guardianPhone || student.guardianPhone,
      documentsDelivered: formData.documentsDelivered
    });

    setIsModalOpen(false);
    setReceiptToPrint(newEnr);
  };

  return (
    <div className="space-y-6">
      {/* Cabeçalho */}
      <div className="no-print flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
            <ClipboardCheck className="h-6 w-6 text-sky-600" />
            Matrículas & Confirmação de Vagas
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Registo de novas matrículas, renovações e emissão de comprovativos oficiais do SNE.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-1.5 rounded-xl bg-sky-600 px-3.5 py-2 text-xs font-bold text-white shadow-sm hover:bg-sky-700 transition"
        >
          <UserPlus className="h-4 w-4" />
          Registar Nova Matrícula
        </button>
      </div>

      {/* Filtros */}
      <div className="no-print flex flex-col sm:flex-row sm:items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Pesquisar por aluno, nº de matrícula ou encarregado..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full rounded-xl border border-slate-200 py-2 pl-9 pr-4 text-xs text-slate-800 placeholder-slate-400 focus:border-sky-500 focus:outline-none"
          />
        </div>

        <select
          value={selectedStatus}
          onChange={(e) => setSelectedStatus(e.target.value as any)}
          className="rounded-xl border border-slate-200 bg-slate-50 py-2 px-3 text-xs font-semibold text-slate-700 focus:border-sky-500 focus:outline-none"
        >
          <option value="ALL">Todos os Estados</option>
          <option value="CONFIRMADA">Confirmadas</option>
          <option value="PENDENTE">Pendentes</option>
          <option value="CANCELADA">Canceladas</option>
        </select>
      </div>

      {/* Tabela de Matrículas */}
      <div className="no-print overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600">
            <thead className="border-b border-slate-200 bg-slate-50 font-bold uppercase tracking-wider text-slate-500">
              <tr>
                <th className="py-3 px-4">Nº Matrícula</th>
                <th className="py-3 px-4">Aluno</th>
                <th className="py-3 px-4">Classe Pretendida</th>
                <th className="py-3 px-4">Turma Atribuída</th>
                <th className="py-3 px-4">Encarregado & Contacto</th>
                <th className="py-3 px-4">Data</th>
                <th className="py-3 px-4">Estado</th>
                <th className="py-3 px-4 text-center">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredEnrollments.map((enr) => (
                <tr key={enr.id} className="hover:bg-slate-50/80 transition">
                  <td className="py-3 px-4 font-mono font-bold text-sky-700">
                    {enr.enrollmentNumber}
                  </td>
                  <td className="py-3 px-4 font-bold text-slate-900">
                    {enr.studentName}
                  </td>
                  <td className="py-3 px-4 font-medium text-slate-800">
                    {enr.gradeLevel}
                  </td>
                  <td className="py-3 px-4 text-slate-600">
                    {enr.sectionName}
                  </td>
                  <td className="py-3 px-4">
                    <p className="font-medium text-slate-800">{enr.guardianName}</p>
                    <p className="text-[10px] text-slate-400">{enr.guardianPhone}</p>
                  </td>
                  <td className="py-3 px-4 text-slate-500">
                    {enr.date}
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className={`inline-flex rounded-full px-2.5 py-0.5 text-[10px] font-bold ${
                        enr.status === 'CONFIRMADA'
                          ? 'bg-emerald-100 text-emerald-800'
                          : enr.status === 'PENDENTE'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-rose-100 text-rose-800'
                      }`}
                    >
                      {enr.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-center">
                    <div className="flex items-center justify-center gap-1.5">
                      <button
                        onClick={() => setReceiptToPrint(enr)}
                        className="rounded-lg bg-sky-50 px-2 py-1 text-xs font-bold text-sky-700 hover:bg-sky-100 transition flex items-center gap-1"
                      >
                        <Printer className="h-3.5 w-3.5" />
                        Comprovativo
                      </button>

                      {enr.status === 'PENDENTE' && (
                        <button
                          onClick={() => updateEnrollmentStatus(enr.id, 'CONFIRMADA')}
                          className="rounded-lg bg-emerald-600 px-2 py-1 text-xs font-bold text-white hover:bg-emerald-700"
                        >
                          Confirmar
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Nova Matrícula */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
          <div className="relative w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-4">
              <h3 className="font-extrabold text-slate-900 text-base flex items-center gap-2">
                <ClipboardCheck className="h-5 w-5 text-sky-600" />
                Efectuar Matrícula Escolar
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Aluno Candidato *</label>
                <select
                  value={formData.studentId}
                  onChange={(e) => setFormData({ ...formData, studentId: e.target.value })}
                  className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-sky-500 focus:outline-none"
                >
                  {db.students.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.fullName} ({s.studentNumber})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Classe a Matricular *</label>
                  <select
                    value={formData.gradeLevel}
                    onChange={(e) => setFormData({ ...formData, gradeLevel: e.target.value })}
                    className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-sky-500 focus:outline-none"
                  >
                    <option value="7ª Classe">7ª Classe</option>
                    <option value="8ª Classe">8ª Classe</option>
                    <option value="9ª Classe">9ª Classe</option>
                    <option value="10ª Classe">10ª Classe</option>
                    <option value="11ª Classe">11ª Classe</option>
                    <option value="12ª Classe">12ª Classe</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Turma Proposta *</label>
                  <select
                    value={formData.sectionName}
                    onChange={(e) => setFormData({ ...formData, sectionName: e.target.value })}
                    className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-sky-500 focus:outline-none"
                  >
                    <option value="Turma A">Turma A</option>
                    <option value="Turma B">Turma B</option>
                    <option value="Turma C">Turma C</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Documentos Entregues</label>
                <div className="space-y-1 rounded-xl bg-slate-50 p-2.5 border border-slate-200">
                  {['BI / Cédula', 'Certificado da Classe Anterior', 'Fotografias', 'Boletim de Vacinas'].map((doc) => (
                    <label key={doc} className="flex items-center gap-2 cursor-pointer">
                      <input type="checkbox" defaultChecked className="rounded text-sky-600" />
                      <span>{doc}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-4 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="rounded-xl bg-slate-100 px-4 py-2 font-bold text-slate-700 hover:bg-slate-200 text-xs"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-sky-600 px-5 py-2 font-bold text-white hover:bg-sky-700 text-xs shadow-sm"
                >
                  Confirmar Matrícula
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* COMPROVATIVO DE MATRÍCULA IMPRESSO */}
      {receiptToPrint && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
          <div className="relative w-full max-w-lg rounded-2xl bg-white p-8 shadow-2xl print:border-none print:shadow-none">
            <div className="border-b-2 border-slate-900 pb-4 text-center">
              <h4 className="font-extrabold text-sm uppercase tracking-wider text-slate-900">
                REPÚBLICA DE MOÇAMBIQUE
              </h4>
              <p className="text-xs font-bold text-slate-700 uppercase">{currentSchool.name}</p>
              <div className="mt-2 inline-block rounded-md bg-sky-100 px-3 py-0.5 text-xs font-extrabold text-sky-900 uppercase">
                COMPROVATIVO OFICIAL DE MATRÍCULA
              </div>
            </div>

            <div className="my-5 space-y-2 text-xs text-slate-800">
              <div className="flex justify-between border-b border-slate-100 pb-1">
                <span>Nº de Matrícula:</span>
                <strong className="font-mono text-sky-800 text-sm">{receiptToPrint.enrollmentNumber}</strong>
              </div>
              <div className="flex justify-between border-b border-slate-100 pb-1">
                <span>Nome do Aluno:</span>
                <strong>{receiptToPrint.studentName}</strong>
              </div>
              <div className="flex justify-between border-b border-slate-100 pb-1">
                <span>Ano Lectivo:</span>
                <strong>{receiptToPrint.academicYear}</strong>
              </div>
              <div className="flex justify-between border-b border-slate-100 pb-1">
                <span>Classe / Turma:</span>
                <strong>{receiptToPrint.gradeLevel} ({receiptToPrint.sectionName})</strong>
              </div>
              <div className="flex justify-between border-b border-slate-100 pb-1">
                <span>Encarregado:</span>
                <strong>{receiptToPrint.guardianName} ({receiptToPrint.guardianPhone})</strong>
              </div>
              <div className="flex justify-between border-b border-slate-100 pb-1">
                <span>Data de Confirmação:</span>
                <strong>{receiptToPrint.date}</strong>
              </div>
            </div>

            <div className="mt-6 border-t border-slate-300 pt-4 text-center text-xs text-slate-600">
              <p>Autenticado pela Secretaria Escolar • EduGest Moçambique</p>
              <div className="mt-5 flex justify-between gap-2 no-print">
                <button
                  onClick={() => setReceiptToPrint(null)}
                  className="rounded-xl bg-slate-100 px-4 py-2 font-bold text-slate-700 hover:bg-slate-200"
                >
                  Fechar
                </button>
                <button
                  onClick={() => window.print()}
                  className="rounded-xl bg-sky-600 px-5 py-2 font-bold text-white hover:bg-sky-700 flex items-center gap-1.5"
                >
                  <Printer className="h-4 w-4" />
                  Imprimir Comprovativo
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
