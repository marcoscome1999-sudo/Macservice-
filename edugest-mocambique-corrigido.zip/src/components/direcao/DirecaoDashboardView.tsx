/**
 * EduGest Moçambique - Painel Executivo da Direção
 * Ponto 3 do SNE: Visão estratégica da escola, homologação de pautas,
 * aprovação de relatórios oficiais e controlo pedagógico institucional.
 */

import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { PautaApproval } from '../../types';
import { StatusBadge } from '../common/StatusBadge';
import { ConfirmDialog } from '../common/ConfirmDialog';
import {
  Award,
  CheckCircle,
  XCircle,
  FileCheck2,
  Users,
  GraduationCap,
  TrendingUp,
  AlertTriangle,
  Clock,
  Send,
  Building,
  Calendar,
  Eye,
  Lock,
  Download,
  Printer,
  ChevronRight
} from 'lucide-react';

export const DirecaoDashboardView: React.FC = () => {
  const {
    db,
    currentUser,
    currentSchool,
    approvePauta,
    rejectPauta,
    sendNotification,
    setActiveTab
  } = useApp();

  // Estados
  const [activeTabSub, setActiveTabSub] = useState<'HOMOLOGACAO' | 'ESTATISTICAS' | 'COMUNICADOS'>('HOMOLOGACAO');
  const [selectedPautaToReject, setSelectedPautaToReject] = useState<PautaApproval | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');
  const [selectedPautaToApprove, setSelectedPautaToApprove] = useState<PautaApproval | null>(null);
  const [inspectPauta, setInspectPauta] = useState<PautaApproval | null>(null);

  // Formulário de Comunicado da Direção
  const [noticeForm, setNoticeForm] = useState({
    title: '',
    content: '',
    targetAudience: 'TODOS' as 'TODOS' | 'PROFESSORES' | 'ENCARREGADOS' | 'ALUNOS',
    channel: 'PORTAL' as 'SMS' | 'EMAIL' | 'PORTAL' | 'MURAL'
  });
  const [noticeSuccess, setNoticeSuccess] = useState(false);

  // Pautas registradas
  const pautas = db.pautaApprovals || [];
  const pendingPautas = pautas.filter((p) => p.status === 'PENDENTE');
  const approvedPautas = pautas.filter((p) => p.status === 'HOMOLOGADA');

  // Cálculos Estatísticos Globais
  const totalStudents = db.students.length;
  const maleStudents = db.students.filter((s) => s.gender === 'M').length;
  const femaleStudents = db.students.filter((s) => s.gender === 'F').length;
  const totalTeachers = db.teachers.length;
  const totalClasses = db.classes.length;

  // Rendimento médio escolar aproximado
  const averageGrade = useMemo(() => {
    const validGrades = db.grades.filter((g) => g.finalGrade !== null && g.finalGrade !== undefined);
    if (validGrades.length === 0) return 12.4;
    const sum = validGrades.reduce((acc, g) => acc + (g.finalGrade || 0), 0);
    return (sum / validGrades.length).toFixed(1);
  }, [db.grades]);

  // Taxa de aprovação
  const passRate = useMemo(() => {
    const validGrades = db.grades.filter((g) => g.finalGrade !== null);
    if (validGrades.length === 0) return 84;
    const passed = validGrades.filter((g) => (g.finalGrade || 0) >= 10).length;
    return Math.round((passed / validGrades.length) * 100);
  }, [db.grades]);

  // Tratar aprovação de pauta
  const handleConfirmApprove = () => {
    if (selectedPautaToApprove) {
      approvePauta(selectedPautaToApprove.id, currentUser.name);
      setSelectedPautaToApprove(null);
    }
  };

  // Tratar rejeição de pauta
  const handleConfirmReject = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedPautaToReject && rejectionReason.trim()) {
      rejectPauta(selectedPautaToReject.id, rejectionReason.trim());
      setSelectedPautaToReject(null);
      setRejectionReason('');
    }
  };

  // Publicar comunicado
  const handlePublishNotice = (e: React.FormEvent) => {
    e.preventDefault();
    if (!noticeForm.title.trim() || !noticeForm.content.trim()) return;

    sendNotification({
      title: noticeForm.title.trim(),
      message: noticeForm.content.trim(),
      targetAudience: noticeForm.targetAudience,
      channel: noticeForm.channel,
      authorName: `${currentUser.name} (Direção Pedagógica)`
    });

    setNoticeSuccess(true);
    setNoticeForm({
      title: '',
      content: '',
      targetAudience: 'TODOS',
      channel: 'PORTAL'
    });
    setTimeout(() => setNoticeSuccess(false), 3500);
  };

  return (
    <div className="space-y-6">
      {/* Cabeçalho da Direção */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
            <Award className="h-6 w-6 text-sky-600" />
            Painel Executivo da Direção Escolar
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Escola: <strong className="text-slate-700">{currentSchool.name}</strong> • Diretor(a): {currentSchool.directorName} • Ano Letivo 2026
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('pautas')}
            className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3.5 py-2 text-xs sm:text-sm font-bold text-slate-700 hover:bg-slate-50 shadow-xs"
          >
            <FileCheck2 className="h-4 w-4 text-sky-600" />
            Ver Todas as Pautas SNE
          </button>
        </div>
      </div>

      {/* Cartões de Indicadores Estratégicos */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Efectivo Escolar</span>
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-sky-50 text-sky-600">
              <Users className="h-5 w-5" />
            </div>
          </div>
          <p className="mt-2 text-2xl font-extrabold text-slate-900">{totalStudents}</p>
          <div className="mt-1 flex items-center gap-2 text-xs text-slate-500">
            <span>M: <strong className="text-slate-700">{maleStudents}</strong></span>
            <span>•</span>
            <span>F: <strong className="text-slate-700">{femaleStudents}</strong> ({Math.round((femaleStudents / (totalStudents || 1)) * 100)}%)</span>
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Aproveitamento Global</span>
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-emerald-50 text-emerald-600">
              <TrendingUp className="h-5 w-5" />
            </div>
          </div>
          <p className="mt-2 text-2xl font-extrabold text-emerald-600">{passRate}%</p>
          <p className="mt-1 text-xs text-slate-500">
            Média escolar: <strong className="text-slate-700">{averageGrade}</strong> valores (Escala 0-20)
          </p>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Pautas a Homologar</span>
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-amber-50 text-amber-600">
              <Clock className="h-5 w-5" />
            </div>
          </div>
          <p className="mt-2 text-2xl font-extrabold text-amber-600">{pendingPautas.length}</p>
          <p className="mt-1 text-xs text-slate-500">
            {pendingPautas.length > 0 ? 'Aguardando validação da direção' : 'Todas as pautas em dia'}
          </p>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Corpo Docente Ativo</span>
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-indigo-50 text-indigo-600">
              <GraduationCap className="h-5 w-5" />
            </div>
          </div>
          <p className="mt-2 text-2xl font-extrabold text-slate-900">{totalTeachers}</p>
          <p className="mt-1 text-xs text-slate-500">
            Distribuídos em <strong className="text-slate-700">{totalClasses}</strong> turmas lectivas
          </p>
        </div>
      </div>

      {/* Navegação entre Abas */}
      <div className="flex items-center gap-2 border-b border-slate-200">
        <button
          onClick={() => setActiveTabSub('HOMOLOGACAO')}
          className={`flex items-center gap-2 border-b-2 px-4 py-2.5 text-xs sm:text-sm font-bold transition-colors ${
            activeTabSub === 'HOMOLOGACAO'
              ? 'border-sky-600 text-sky-600'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <FileCheck2 className="h-4 w-4" />
          Homologação de Pautas Trimestrais
          {pendingPautas.length > 0 && (
            <span className="ml-1 rounded-full bg-amber-100 text-amber-800 px-2 py-0.5 text-[10px] font-extrabold">
              {pendingPautas.length}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTabSub('ESTATISTICAS')}
          className={`flex items-center gap-2 border-b-2 px-4 py-2.5 text-xs sm:text-sm font-bold transition-colors ${
            activeTabSub === 'ESTATISTICAS'
              ? 'border-sky-600 text-sky-600'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <TrendingUp className="h-4 w-4" />
          Relatório Executivo de Rendimento
        </button>

        <button
          onClick={() => setActiveTabSub('COMUNICADOS')}
          className={`flex items-center gap-2 border-b-2 px-4 py-2.5 text-xs sm:text-sm font-bold transition-colors ${
            activeTabSub === 'COMUNICADOS'
              ? 'border-sky-600 text-sky-600'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <Send className="h-4 w-4" />
          Comunicados Oficiais da Direção
        </button>
      </div>

      {/* ABA 1: HOMOLOGAÇÃO DE PAUTAS */}
      {activeTabSub === 'HOMOLOGACAO' && (
        <div className="space-y-4">
          <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-extrabold text-slate-900 text-sm sm:text-base">
                  Processos de Homologação de Pautas Trimestrais
                </h3>
                <p className="text-xs text-slate-500">
                  A homologação pela Direção confere validade jurídica e oficial às notas do SNE e tranca automaticamente qualquer alteração posterior.
                </p>
              </div>
            </div>
          </div>

          <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-left text-xs sm:text-sm">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50/80 font-bold text-slate-600">
                    <th className="py-3.5 pl-4 pr-3">Turma</th>
                    <th className="px-3 py-3.5">Trimestre</th>
                    <th className="px-3 py-3.5">Submetido por</th>
                    <th className="px-3 py-3.5">Alunos / Média</th>
                    <th className="px-3 py-3.5">Estado</th>
                    <th className="px-3 py-3.5">Data Submissão</th>
                    <th className="py-3.5 pl-3 pr-4 text-right">Decisão da Direção</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                  {pautas.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="p-8 text-center text-slate-400">
                        Nenhuma pauta foi submetida até ao momento.
                      </td>
                    </tr>
                  ) : (
                    pautas.map((pauta) => (
                      <tr key={pauta.id} className="hover:bg-slate-50/60 transition-colors">
                        <td className="py-3.5 pl-4 pr-3">
                          <p className="font-bold text-slate-900">{pauta.sectionName}</p>
                          <p className="text-[11px] text-slate-500">Ano Letivo {pauta.academicYear}</p>
                        </td>

                        <td className="px-3 py-3.5">
                          <span className="font-bold text-sky-700 bg-sky-50 px-2 py-0.5 rounded-md text-xs border border-sky-200">
                            {pauta.term}º Trimestre
                          </span>
                        </td>

                        <td className="px-3 py-3.5">
                          <p className="font-semibold text-slate-800">{pauta.teacherName}</p>
                          <p className="text-[11px] text-slate-400">Professor / Diretor de Turma</p>
                        </td>

                        <td className="px-3 py-3.5">
                          <div className="text-xs">
                            <span className="font-bold text-slate-900">{pauta.totalStudents}</span> alunos •{' '}
                            <span className="font-bold text-emerald-700">{pauta.averageGrade}</span> val.
                          </div>
                        </td>

                        <td className="px-3 py-3.5">
                          <StatusBadge status={pauta.status} />
                          {pauta.rejectionReason && (
                            <p className="text-[11px] text-rose-600 mt-1 max-w-xs truncate" title={pauta.rejectionReason}>
                              Motivo: {pauta.rejectionReason}
                            </p>
                          )}
                          {pauta.approvedBy && (
                            <p className="text-[11px] text-emerald-700 mt-0.5">
                              Por: {pauta.approvedBy}
                            </p>
                          )}
                        </td>

                        <td className="px-3 py-3.5 text-xs text-slate-500">
                          {pauta.submittedAt}
                        </td>

                        <td className="py-3.5 pl-3 pr-4 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            {/* Inspecionar Pauta */}
                            <button
                              onClick={() => setInspectPauta(pauta)}
                              title="Visualizar Pauta Completa"
                              className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100 hover:text-slate-800 transition-colors"
                            >
                              <Eye className="h-4 w-4" />
                            </button>

                            {pauta.status === 'PENDENTE' && (
                              <>
                                {/* Rejeitar */}
                                <button
                                  onClick={() => {
                                    setSelectedPautaToReject(pauta);
                                    setRejectionReason('');
                                  }}
                                  title="Devolver para Correção"
                                  className="rounded-lg p-1.5 text-rose-600 hover:bg-rose-50 transition-colors"
                                >
                                  <XCircle className="h-4 w-4" />
                                </button>

                                {/* Homologar */}
                                <button
                                  onClick={() => setSelectedPautaToApprove(pauta)}
                                  className="inline-flex items-center gap-1 rounded-lg bg-emerald-600 px-2.5 py-1 text-xs font-bold text-white shadow-xs hover:bg-emerald-700 transition-colors"
                                >
                                  <CheckCircle className="h-3.5 w-3.5" />
                                  Homologar
                                </button>
                              </>
                            )}

                            {pauta.status === 'HOMOLOGADA' && (
                              <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-1 rounded-md border border-emerald-200">
                                <Lock className="h-3 w-3" />
                                Homologada & Trancada
                              </span>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ABA 2: ESTATÍSTICAS E RENDIMENTO SNE */}
      {activeTabSub === 'ESTATISTICAS' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
            {/* Aproveitamento por Turma */}
            <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
              <h3 className="font-extrabold text-slate-900 text-sm sm:text-base mb-4 flex items-center gap-2">
                <GraduationCap className="h-5 w-5 text-sky-600" />
                Rendimento por Turma (Ano Letivo 2026)
              </h3>
              <div className="space-y-3">
                {db.classes.map((cls) => {
                  const classStudents = db.students.filter((s) => s.currentClass === cls.name);
                  const enrolledCount = classStudents.length || cls.enrolledCount || 0;
                  const estimatedPass = 80 + (cls.gradeYear % 4) * 3;

                  return (
                    <div key={cls.id} className="rounded-xl border border-slate-100 bg-slate-50/60 p-3">
                      <div className="flex items-center justify-between text-xs font-bold text-slate-800">
                        <span>{cls.name} ({cls.gradeYear}ª Classe • Turno {cls.shift})</span>
                        <span className="text-emerald-700">{estimatedPass}% Aprovação</span>
                      </div>
                      <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-slate-200">
                        <div
                          className="h-full bg-emerald-500 rounded-full"
                          style={{ width: `${estimatedPass}%` }}
                        />
                      </div>
                      <div className="mt-1.5 flex justify-between text-[11px] text-slate-500">
                        <span>Capacidade: {enrolledCount}/{cls.maxCapacity} Alunos</span>
                        <span>Sala {cls.roomNumber}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Quadro de Professores & Carga Horária */}
            <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
              <h3 className="font-extrabold text-slate-900 text-sm sm:text-base mb-4 flex items-center gap-2">
                <Users className="h-5 w-5 text-indigo-600" />
                Quadro Docente & Cumprimento Pedagógico
              </h3>
              <div className="space-y-3">
                {db.teachers.slice(0, 5).map((teacher) => (
                  <div key={teacher.id} className="flex items-center justify-between rounded-xl border border-slate-100 bg-slate-50/60 p-3 text-xs">
                    <div>
                      <p className="font-bold text-slate-900">{teacher.fullName}</p>
                      <p className="text-slate-500 text-[11px]">
                        Nº {teacher.employeeNumber} • Especialidade: {teacher.specialization}
                      </p>
                    </div>
                    <div className="text-right">
                      <span className="rounded-md bg-sky-50 border border-sky-200 px-2 py-0.5 font-bold text-sky-800">
                        {teacher.subjectsTaught.join(', ')}
                      </span>
                      <p className="mt-1 text-[11px] text-emerald-600 font-bold">100% Pautas em dia</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ABA 3: COMUNICADOS OFICIAIS */}
      {activeTabSub === 'COMUNICADOS' && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          <div className="lg:col-span-1 rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
            <h3 className="font-extrabold text-slate-900 text-sm sm:text-base mb-3 flex items-center gap-2">
              <Send className="h-4 w-4 text-sky-600" />
              Publicar Aviso Oficial da Direção
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Envio imediato de comunicados para todos os perfis da comunidade escolar.
            </p>

            {noticeSuccess && (
              <div className="mb-4 rounded-xl bg-emerald-50 border border-emerald-200 p-3 text-xs font-semibold text-emerald-800 flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-emerald-600" />
                Comunicado oficial emitido com sucesso!
              </div>
            )}

            <form onSubmit={handlePublishNotice} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Título do Aviso *</label>
                <input
                  type="text"
                  required
                  placeholder="ex: Reunião Geral de Encarregados de Educação"
                  value={noticeForm.title}
                  onChange={(e) => setNoticeForm({ ...noticeForm, title: e.target.value })}
                  className="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-sky-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Destinatários *</label>
                <select
                  value={noticeForm.targetAudience}
                  onChange={(e) => setNoticeForm({ ...noticeForm, targetAudience: e.target.value as any })}
                  className="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs font-semibold focus:border-sky-500 focus:outline-hidden"
                >
                  <option value="TODOS">Toda a Comunidade Escolar</option>
                  <option value="ENCARREGADOS">Apenas Encarregados de Educação</option>
                  <option value="PROFESSORES">Apenas Corpo Docente</option>
                  <option value="ALUNOS">Apenas Alunos</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Canal de Difusão *</label>
                <select
                  value={noticeForm.channel}
                  onChange={(e) => setNoticeForm({ ...noticeForm, channel: e.target.value as any })}
                  className="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs font-semibold focus:border-sky-500 focus:outline-hidden"
                >
                  <option value="PORTAL">Portal Escolar & Painel</option>
                  <option value="SMS">Notificação SMS</option>
                  <option value="MURAL">Mural Oficial Afixado</option>
                  <option value="EMAIL">Correio Eletrónico</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Conteúdo da Mensagem *</label>
                <textarea
                  required
                  rows={4}
                  placeholder="Escreva os termos oficiais do comunicado..."
                  value={noticeForm.content}
                  onChange={(e) => setNoticeForm({ ...noticeForm, content: e.target.value })}
                  className="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-sky-500 focus:outline-hidden"
                />
              </div>

              <button
                type="submit"
                className="w-full rounded-xl bg-slate-900 py-2 text-xs font-bold text-white hover:bg-slate-800 transition-colors shadow-xs"
              >
                Emitir Comunicado Oficial
              </button>
            </form>
          </div>

          <div className="lg:col-span-2 rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
            <h3 className="font-extrabold text-slate-900 text-sm sm:text-base mb-3">
              Histórico de Comunicados Emitidos
            </h3>
            <div className="space-y-3">
              {db.notifications.map((msg) => (
                <div key={msg.id} className="rounded-xl border border-slate-100 bg-slate-50/60 p-4">
                  <div className="flex items-center justify-between">
                    <h4 className="font-bold text-slate-900 text-xs sm:text-sm">{msg.title}</h4>
                    <span className="rounded-md bg-sky-50 text-sky-800 border border-sky-200 px-2 py-0.5 text-[10px] font-bold">
                      {msg.targetAudience}
                    </span>
                  </div>
                  <p className="mt-1 text-xs text-slate-600 leading-relaxed">{msg.message}</p>
                  <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400">
                    <span>Emitido por: {msg.authorName || 'Direção'}</span>
                    <span>{msg.createdAt}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* MODAL: MOTIVO DE REJEIÇÃO DA PAUTA */}
      {selectedPautaToReject && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
          <div className="relative w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-4">
              <h3 className="font-extrabold text-slate-900 text-base flex items-center gap-2 text-rose-700">
                <AlertTriangle className="h-5 w-5" />
                Devolver Pauta para Correção
              </h3>
              <button onClick={() => setSelectedPautaToReject(null)} className="text-slate-400 hover:text-slate-600">
                ✕
              </button>
            </div>

            <form onSubmit={handleConfirmReject} className="space-y-4">
              <p className="text-xs text-slate-600">
                Turma: <strong>{selectedPautaToReject.sectionName}</strong> ({selectedPautaToReject.term}º Trimestre)
                <br />
                Professor responsável: <strong>{selectedPautaToReject.teacherName}</strong>
              </p>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Motivo da Devolução / Observações para o Docente *
                </label>
                <textarea
                  required
                  rows={3}
                  placeholder="ex: Verificou-se ausência de notas de ACS2 de 3 alunos e divergência na média do aluno nº 14."
                  value={rejectionReason}
                  onChange={(e) => setRejectionReason(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-rose-500 focus:outline-hidden"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setSelectedPautaToReject(null)}
                  className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-50"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-rose-600 px-4 py-2 text-xs font-bold text-white hover:bg-rose-700 shadow-xs"
                >
                  Devolver Pauta ao Professor
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CONFIRMAÇÃO DE HOMOLOGAÇÃO */}
      <ConfirmDialog
        isOpen={!!selectedPautaToApprove}
        title="Homologação Oficial da Pauta Trimestral"
        message={`Confirma a homologação da pauta da turma "${selectedPautaToApprove?.sectionName}" (${selectedPautaToApprove?.term}º Trimestre)? Esta ação atribuirá o carimbo digital da Direção e bloqueará permanentemente a edição de notas desta turma.`}
        confirmText="Sim, Homologar Oficialmente"
        cancelText="Cancelar"
        variant="primary"
        onConfirm={handleConfirmApprove}
        onCancel={() => setSelectedPautaToApprove(null)}
      />
    </div>
  );
};
