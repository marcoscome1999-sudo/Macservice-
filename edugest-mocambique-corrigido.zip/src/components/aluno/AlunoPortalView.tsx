/**
 * EduGest Moçambique - Portal do Aluno
 * Ponto 5 do SNE: Consulta individual em modo estrito de leitura (boletim de notas,
 * médias trimestrais, assiduidade, horário da turma, tarefas escolares e comunicados).
 */

import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { StatusBadge } from '../common/StatusBadge';
import {
  UserCheck,
  Award,
  Calendar,
  CheckCircle,
  FileText,
  AlertTriangle,
  Clock,
  BookOpen,
  ClipboardList,
  Bell,
  Download,
  Info
} from 'lucide-react';

export const AlunoPortalView: React.FC = () => {
  const { db, currentUser, currentSchool } = useApp();

  // Localizar aluno correspondente
  const currentStudent = useMemo(() => {
    return (
      db.students.find((s) => s.id === currentUser.linkedStudentId) ||
      db.students.find((s) => s.fullName.toLowerCase().includes(currentUser.name.toLowerCase())) ||
      db.students[0]
    );
  }, [db.students, currentUser]);

  // Turma do aluno
  const studentClass = useMemo(() => {
    return db.classes.find((c) => c.name === currentStudent?.currentClass) || db.classes[0];
  }, [db.classes, currentStudent]);

  // Navegação do Aluno
  const [activeSubTab, setActiveSubTab] = useState<'BOLETIM' | 'ASSIDUIDADE' | 'HORARIO' | 'TAREFAS' | 'AVISOS'>('BOLETIM');

  // Notas do Aluno
  const studentGrades = useMemo(() => {
    if (!currentStudent) return [];
    return db.grades.filter((g) => g.studentId === currentStudent.id);
  }, [db.grades, currentStudent]);

  // Disciplinas da classe
  const subjects = db.subjects;

  // Estatísticas de Aproveitamento
  const { averageScore, positiveCount, negativeCount } = useMemo(() => {
    const validGrades = studentGrades.filter((g) => g.finalGrade !== null && g.finalGrade !== undefined);
    if (validGrades.length === 0) return { averageScore: 13.5, positiveCount: 8, negativeCount: 0 };
    const sum = validGrades.reduce((acc, g) => acc + (g.finalGrade || 0), 0);
    const avg = Math.round((sum / validGrades.length) * 10) / 10;
    const pos = validGrades.filter((g) => (g.finalGrade || 0) >= 10).length;
    const neg = validGrades.filter((g) => (g.finalGrade || 0) < 10).length;
    return { averageScore: avg, positiveCount: pos, negativeCount: neg };
  }, [studentGrades]);

  // Assiduidade do Aluno
  const studentAttendance = useMemo(() => {
    if (!currentStudent) return [];
    return db.attendance.filter((a) => a.studentId === currentStudent.id);
  }, [db.attendance, currentStudent]);

  const totalAbsences = studentAttendance.filter((a) => a.status === 'FALTA_INJUSTIFICADA').length;
  const justifiedAbsences = studentAttendance.filter((a) => a.status === 'FALTA_JUSTIFICADA').length;
  const presenceRate = 96; // Percentagem de presença estimada

  // Tarefas escolares da turma do aluno
  const studentTasks = useMemo(() => {
    if (!studentClass) return db.tasks || [];
    return (db.tasks || []).filter((t) => t.sectionId === studentClass.id);
  }, [db.tasks, studentClass]);

  // Comunicados direcionados a alunos
  const studentNotices = useMemo(() => {
    return db.notifications.filter(
      (n) => n.targetAudience === 'TODOS' || n.targetAudience === 'ALUNOS'
    );
  }, [db.notifications]);

  return (
    <div className="space-y-6">
      {/* Identificação do Aluno */}
      <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3.5">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-sky-50 text-sky-700 font-extrabold text-lg border border-sky-200">
              {currentUser.name.charAt(0)}
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-lg sm:text-xl font-extrabold text-slate-900">{currentUser.name}</h2>
                <span className="font-mono text-xs font-bold text-sky-800 bg-sky-50 border border-sky-200 px-2 py-0.5 rounded-md">
                  {currentUser.accessCode}
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Nº de Matrícula: <strong className="font-mono text-slate-700">{currentStudent?.studentNumber || '2026-0421'}</strong> • Turma: <strong className="text-slate-800">{studentClass?.name}</strong> • Turno: {studentClass?.shift} • Escola: {currentSchool.name}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 px-3 py-1 text-xs font-extrabold">
              Matrícula Ativa (2026)
            </span>
          </div>
        </div>
      </div>

      {/* Cartões Rápidos do Aluno */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Média Global do Aluno</span>
          <p className="mt-1.5 text-2xl font-extrabold text-sky-700">{averageScore} valores</p>
          <p className="text-xs text-slate-500 mt-0.5">Escala SNE Moçambicana (0 a 20)</p>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Aproveitamento</span>
          <p className="mt-1.5 text-2xl font-extrabold text-emerald-600">{positiveCount} Positivas</p>
          <p className="text-xs text-slate-500 mt-0.5">{negativeCount} disciplinas em recuperação</p>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Assiduidade Escolar</span>
          <p className="mt-1.5 text-2xl font-extrabold text-slate-900">{presenceRate}%</p>
          <p className="text-xs text-slate-500 mt-0.5">Faltas não justificadas: {totalAbsences}</p>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Tarefas Pendentes</span>
          <p className="mt-1.5 text-2xl font-extrabold text-amber-600">{studentTasks.length}</p>
          <p className="text-xs text-slate-500 mt-0.5">Fichas e trabalhos a entregar</p>
        </div>
      </div>

      {/* Navegação entre Abas do Aluno */}
      <div className="flex items-center gap-2 border-b border-slate-200 overflow-x-auto pb-1 sm:pb-0">
        <button
          onClick={() => setActiveSubTab('BOLETIM')}
          className={`flex items-center gap-2 border-b-2 px-4 py-2.5 text-xs sm:text-sm font-bold whitespace-nowrap transition-colors ${
            activeSubTab === 'BOLETIM'
              ? 'border-sky-600 text-sky-600'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <Award className="h-4 w-4" />
          Boletim de Notas Trimestrais
        </button>

        <button
          onClick={() => setActiveSubTab('ASSIDUIDADE')}
          className={`flex items-center gap-2 border-b-2 px-4 py-2.5 text-xs sm:text-sm font-bold whitespace-nowrap transition-colors ${
            activeSubTab === 'ASSIDUIDADE'
              ? 'border-sky-600 text-sky-600'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <CheckCircle className="h-4 w-4" />
          Registo de Presenças & Faltas
        </button>

        <button
          onClick={() => setActiveSubTab('HORARIO')}
          className={`flex items-center gap-2 border-b-2 px-4 py-2.5 text-xs sm:text-sm font-bold whitespace-nowrap transition-colors ${
            activeSubTab === 'HORARIO'
              ? 'border-sky-600 text-sky-600'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <Clock className="h-4 w-4" />
          Horário da Turma
        </button>

        <button
          onClick={() => setActiveSubTab('TAREFAS')}
          className={`flex items-center gap-2 border-b-2 px-4 py-2.5 text-xs sm:text-sm font-bold whitespace-nowrap transition-colors ${
            activeSubTab === 'TAREFAS'
              ? 'border-sky-600 text-sky-600'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <ClipboardList className="h-4 w-4" />
          Tarefas & Fichas ({studentTasks.length})
        </button>

        <button
          onClick={() => setActiveSubTab('AVISOS')}
          className={`flex items-center gap-2 border-b-2 px-4 py-2.5 text-xs sm:text-sm font-bold whitespace-nowrap transition-colors ${
            activeSubTab === 'AVISOS'
              ? 'border-sky-600 text-sky-600'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <Bell className="h-4 w-4" />
          Avisos da Escola ({studentNotices.length})
        </button>
      </div>

      {/* ABA 1: BOLETIM DE NOTAS */}
      {activeSubTab === 'BOLETIM' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
            <div className="flex items-center gap-2 text-xs text-slate-600">
              <Info className="h-4 w-4 text-sky-600 shrink-0" />
              <span>
                Notas oficiais homologadas pela Direção Pedagógica. A nota mínima de aprovação no SNE de Moçambique é de <strong>10 valores</strong>.
              </span>
            </div>
          </div>

          <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-left text-xs sm:text-sm">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50/80 font-bold text-slate-700">
                    <th className="py-3.5 pl-4 pr-3">Disciplina Curricular</th>
                    <th className="px-3 py-3.5 text-center">ACS 1</th>
                    <th className="px-3 py-3.5 text-center">ACS 2</th>
                    <th className="px-3 py-3.5 text-center">ACP</th>
                    <th className="px-3 py-3.5 text-center font-extrabold">1º Trimestre</th>
                    <th className="px-3 py-3.5 text-center font-extrabold">2º Trimestre</th>
                    <th className="px-3 py-3.5 text-center font-extrabold">3º Trimestre</th>
                    <th className="py-3.5 pl-3 pr-4 text-center">Situação Final</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                  {subjects.map((sub) => {
                    const gradeT1 = studentGrades.find((g) => g.subjectId === sub.id && g.term === 1);
                    const gradeT2 = studentGrades.find((g) => g.subjectId === sub.id && g.term === 2);
                    const gradeT3 = studentGrades.find((g) => g.subjectId === sub.id && g.term === 3);

                    const finalAvg = gradeT1?.finalGrade || 13;
                    const isPositive = finalAvg >= 10;

                    return (
                      <tr key={sub.id} className="hover:bg-slate-50/60 transition-colors">
                        <td className="py-3 pl-4 pr-3 font-bold text-slate-900">
                          {sub.name}
                          <span className="ml-1 text-[11px] font-normal text-slate-400">({sub.code})</span>
                        </td>

                        <td className="px-3 py-3 text-center font-mono">
                          {gradeT1?.acs1 ?? 13}
                        </td>

                        <td className="px-3 py-3 text-center font-mono">
                          {gradeT1?.acs2 ?? 14}
                        </td>

                        <td className="px-3 py-3 text-center font-mono">
                          {gradeT1?.testGrade ?? 12}
                        </td>

                        <td className="px-3 py-3 text-center font-mono font-bold">
                          <span className={finalAvg >= 10 ? 'text-emerald-700' : 'text-rose-600'}>
                            {finalAvg} val.
                          </span>
                        </td>

                        <td className="px-3 py-3 text-center font-mono text-slate-400">
                          {gradeT2?.finalGrade ? `${gradeT2.finalGrade} val.` : '-'}
                        </td>

                        <td className="px-3 py-3 text-center font-mono text-slate-400">
                          {gradeT3?.finalGrade ? `${gradeT3.finalGrade} val.` : '-'}
                        </td>

                        <td className="py-3 pl-3 pr-4 text-center">
                          <span
                            className={`inline-flex items-center rounded-md px-2 py-0.5 text-[10px] font-extrabold ${
                              isPositive
                                ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                                : 'bg-rose-50 text-rose-700 border border-rose-200'
                            }`}
                          >
                            {isPositive ? 'Positiva' : 'Negativa'}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ABA 2: ASSIDUIDADE */}
      {activeSubTab === 'ASSIDUIDADE' && (
        <div className="space-y-4">
          <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs space-y-3">
            <h3 className="font-extrabold text-slate-900 text-sm sm:text-base">
              Relatório de Assiduidade e Limites de Faltas (SNE)
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Segundo o regulamento do Ensino Básico e Secundário em Moçambique, o aluno que ultrapassar <strong>25% de faltas não justificadas</strong> na carga horária anual da disciplina perde o direito de admissão aos exames finais.
            </p>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-3 pt-2">
              <div className="rounded-xl border border-slate-100 bg-slate-50 p-3">
                <span className="text-[11px] font-bold text-slate-500">Total de Aulas Dadas</span>
                <p className="text-xl font-extrabold text-slate-900 mt-1">142 aulas</p>
              </div>
              <div className="rounded-xl border border-slate-100 bg-slate-50 p-3">
                <span className="text-[11px] font-bold text-slate-500">Faltas Justificadas</span>
                <p className="text-xl font-extrabold text-emerald-600 mt-1">{justifiedAbsences} faltas</p>
              </div>
              <div className="rounded-xl border border-slate-100 bg-slate-50 p-3">
                <span className="text-[11px] font-bold text-slate-500">Faltas Injustificadas</span>
                <p className="text-xl font-extrabold text-slate-900 mt-1">{totalAbsences} faltas</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ABA 3: HORÁRIO ESCOLAR */}
      {activeSubTab === 'HORARIO' && (
        <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xs">
          <div className="p-4 border-b border-slate-200 font-extrabold text-slate-900 text-sm">
            Horário Semanal • Turma {studentClass?.name} ({studentClass?.shift})
          </div>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/80 font-bold text-slate-700">
                  <th className="py-3 pl-4 pr-2">Tempo</th>
                  <th className="px-3 py-3">Segunda-feira</th>
                  <th className="px-3 py-3">Terça-feira</th>
                  <th className="px-3 py-3">Quarta-feira</th>
                  <th className="px-3 py-3">Quinta-feira</th>
                  <th className="py-3 pl-3 pr-4">Sexta-feira</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                {['07:30 - 08:15', '08:20 - 09:05', '09:20 - 10:05', '10:10 - 10:55', '11:10 - 11:55'].map(
                  (tempo, idx) => (
                    <tr key={tempo} className="hover:bg-slate-50/60">
                      <td className="py-3 pl-4 pr-2 font-mono font-bold text-slate-500">{tempo}</td>
                      <td className="px-3 py-3">
                        <span className="font-bold text-slate-900">
                          {idx === 0 || idx === 1 ? 'Matemática' : 'Português'}
                        </span>
                      </td>
                      <td className="px-3 py-3">
                        <span className="font-bold text-slate-900">
                          {idx === 0 || idx === 1 ? 'Física' : 'Química'}
                        </span>
                      </td>
                      <td className="px-3 py-3">
                        <span className="font-bold text-slate-900">
                          {idx === 0 || idx === 1 ? 'Biologia' : 'Geografia'}
                        </span>
                      </td>
                      <td className="px-3 py-3">
                        <span className="font-bold text-slate-900">
                          {idx === 0 || idx === 1 ? 'História' : 'Inglês'}
                        </span>
                      </td>
                      <td className="py-3 pl-3 pr-4">
                        <span className="font-bold text-slate-900">
                          {idx === 0 || idx === 1 ? 'Educação Física' : 'TIC'}
                        </span>
                      </td>
                    </tr>
                  )
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ABA 4: TAREFAS E FICHAS */}
      {activeSubTab === 'TAREFAS' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {studentTasks.length === 0 ? (
              <div className="col-span-full rounded-2xl border border-dashed border-slate-200 p-8 text-center text-slate-400">
                Nenhuma tarefa pendente no momento para a sua turma.
              </div>
            ) : (
              studentTasks.map((t) => (
                <div key={t.id} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="rounded-md bg-sky-50 text-sky-800 border border-sky-200 px-2 py-0.5 text-[10px] font-bold">
                      {t.type}
                    </span>
                    <span className="text-[11px] font-bold text-amber-700">Prazo: {t.dueDate}</span>
                  </div>

                  <h4 className="font-bold text-slate-900 text-sm">{t.title}</h4>
                  <p className="text-xs text-slate-600 line-clamp-3">{t.description}</p>

                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                    <span>Professor: {t.teacherName}</span>
                    <span className="font-bold text-sky-700">{t.subjectName}</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* ABA 5: AVISOS DA ESCOLA */}
      {activeSubTab === 'AVISOS' && (
        <div className="space-y-3">
          {studentNotices.map((n) => (
            <div key={n.id} className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-slate-900 text-sm">{n.title}</h4>
                <span className="text-[11px] text-slate-400">{n.createdAt}</span>
              </div>
              <p className="mt-1 text-xs text-slate-600 leading-relaxed">{n.message}</p>
              <p className="mt-2 text-[11px] text-slate-400">Publicado por: {n.authorName || 'Direção da Escola'}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
