/**
 * EduGest Moçambique - Gestão de Turmas & Salas (ClassesView)
 * Criação de turmas por classe (7ª à 12ª), turno (Diurno, Vespertino, Noturno),
 * directores de turma, limite máximo de alunos e estatísticas (M/F).
 */

import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { ClassSection } from '../../types';
import {
  Layers,
  Plus,
  Users,
  Clock,
  DoorOpen,
  UserCheck,
  Search,
  CheckCircle2,
  X
} from 'lucide-react';

export const ClassesView: React.FC = () => {
  const { db, addSection, updateSection } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedShift, setSelectedShift] = useState('ALL');
  const [isModalOpen, setIsModalOpen] = useState(false);

  const [formData, setFormData] = useState<Omit<ClassSection, 'id'>>({
    schoolId: db.schools[0]?.id || 'school-1',
    name: 'Turma B',
    gradeLevel: '10ª Classe',
    shift: 'DIURNO',
    academicYear: 2026,
    maxCapacity: 45,
    currentCount: 0,
    classroom: 'Sala 05',
    directorTeacherId: db.teachers[0]?.id || 'prof-1',
    directorTeacherName: db.teachers[0]?.fullName || 'Docente Coordenador'
  });

  const filteredSections = useMemo(() => {
    return db.sections.filter((sec) => {
      const matchSearch =
        sec.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        sec.gradeLevel.toLowerCase().includes(searchTerm.toLowerCase()) ||
        sec.directorTeacherName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        sec.classroom.toLowerCase().includes(searchTerm.toLowerCase());

      const matchShift = selectedShift === 'ALL' || sec.shift === selectedShift;

      return matchSearch && matchShift;
    });
  }, [db.sections, searchTerm, selectedShift]);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const teacher = db.teachers.find((t) => t.id === formData.directorTeacherId);
    addSection({
      ...formData,
      directorTeacherName: teacher?.fullName || formData.directorTeacherName
    });
    setIsModalOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Cabeçalho */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
            <Layers className="h-6 w-6 text-indigo-600" />
            Gestão de Turmas & Salas de Aula
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Organização de turmas por ciclo do SNE, turnos lectivos, salas e directores de turma.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-1.5 rounded-xl bg-indigo-600 px-3.5 py-2 text-xs font-bold text-white shadow-sm hover:bg-indigo-700 transition"
        >
          <Plus className="h-4 w-4" />
          Criar Nova Turma
        </button>
      </div>

      {/* Filtros */}
      <div className="flex flex-col gap-3 rounded-2xl border border-slate-200 bg-white p-4 shadow-xs sm:flex-row sm:items-center sm:justify-between">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Pesquisar por turma, classe, director de turma ou sala..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full rounded-xl border border-slate-200 py-2 pl-9 pr-4 text-xs text-slate-800 placeholder-slate-400 focus:border-indigo-500 focus:outline-none"
          />
        </div>

        <select
          value={selectedShift}
          onChange={(e) => setSelectedShift(e.target.value)}
          className="rounded-xl border border-slate-200 bg-slate-50 py-2 px-3 text-xs font-semibold text-slate-700 focus:border-indigo-500 focus:outline-none"
        >
          <option value="ALL">Todos os Turnos</option>
          <option value="DIURNO">Turno Diurno</option>
          <option value="VESPERTINO">Turno Vespertino</option>
          <option value="NOTURNO">Turno Noturno</option>
        </select>
      </div>

      {/* Cartões das Turmas */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredSections.map((sec) => {
          // Estatísticas da turma (rapazes, raparigas) calculadas a partir dos alunos
          const enrolledStudents = db.students.filter(
            (s) => s.currentClass === sec.gradeLevel && s.currentSection === sec.name
          );
          const maleCount = enrolledStudents.filter((s) => s.gender === 'M').length;
          const femaleCount = enrolledStudents.filter((s) => s.gender === 'F').length;
          const totalCount = enrolledStudents.length;
          const occupancyRate = Math.round((totalCount / sec.maxCapacity) * 100);

          return (
            <div
              key={sec.id}
              className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs hover:border-indigo-300 transition"
            >
              <div className="flex items-start justify-between mb-2">
                <div>
                  <span className="rounded-md bg-indigo-50 px-2 py-0.5 text-[10px] font-bold text-indigo-700 border border-indigo-200">
                    {sec.gradeLevel}
                  </span>
                  <h3 className="text-lg font-extrabold text-slate-900 mt-1">{sec.name}</h3>
                </div>
                <span className="rounded-full bg-slate-100 px-2.5 py-1 text-[10px] font-bold text-slate-700">
                  {sec.shift}
                </span>
              </div>

              <div className="space-y-2 border-t border-slate-100 pt-3 text-xs text-slate-600">
                <div className="flex items-center gap-2">
                  <DoorOpen className="h-4 w-4 text-slate-400" />
                  <span>Espaço: <strong>{sec.classroom}</strong></span>
                </div>

                <div className="flex items-center gap-2">
                  <UserCheck className="h-4 w-4 text-slate-400" />
                  <span className="truncate">Director: <strong>{sec.directorTeacherName}</strong></span>
                </div>
              </div>

              {/* Estatísticas de Alunos (M/F e Capacidade) */}
              <div className="mt-4 rounded-xl bg-slate-50 p-3 border border-slate-100 space-y-2">
                <div className="flex justify-between text-xs font-semibold">
                  <span className="text-slate-600">Ocupação da Turma:</span>
                  <span className="font-bold text-slate-900">
                    {totalCount} / {sec.maxCapacity} Alunos ({occupancyRate}%)
                  </span>
                </div>
                <div className="h-2 w-full rounded-full bg-slate-200 overflow-hidden">
                  <div
                    className={`h-full rounded-full ${occupancyRate > 90 ? 'bg-amber-500' : 'bg-indigo-600'}`}
                    style={{ width: `${Math.min(occupancyRate, 100)}%` }}
                  />
                </div>
                <div className="flex justify-between text-[11px] text-slate-500 pt-1">
                  <span>Rapazes: <strong className="text-slate-700">{maleCount}</strong></span>
                  <span>Raparigas: <strong className="text-slate-700">{femaleCount}</strong></span>
                  <span>Vagas: <strong className="text-emerald-700">{Math.max(0, sec.maxCapacity - totalCount)}</strong></span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal de Criação de Turma */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
          <div className="relative w-full max-w-md rounded-2xl bg-white shadow-2xl p-6">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-4">
              <h3 className="font-extrabold text-slate-900 text-base flex items-center gap-2">
                <Layers className="h-5 w-5 text-indigo-600" />
                Criar Nova Turma Escolar
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Classe do SNE *</label>
                <select
                  value={formData.gradeLevel}
                  onChange={(e) => setFormData({ ...formData, gradeLevel: e.target.value })}
                  className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-indigo-500 focus:outline-none"
                >
                  <option value="7ª Classe">7ª Classe</option>
                  <option value="8ª Classe">8ª Classe</option>
                  <option value="9ª Classe">9ª Classe</option>
                  <option value="10ª Classe">10ª Classe</option>
                  <option value="11ª Classe">11ª Classe</option>
                  <option value="12ª Classe">12ª Classe</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Identificação / Nome *</label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-indigo-500 focus:outline-none"
                    placeholder="ex: Turma C"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Turno Lectivo *</label>
                  <select
                    value={formData.shift}
                    onChange={(e) => setFormData({ ...formData, shift: e.target.value as any })}
                    className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-indigo-500 focus:outline-none"
                  >
                    <option value="DIURNO">Diurno (Manhã)</option>
                    <option value="VESPERTINO">Vespertino (Tarde)</option>
                    <option value="NOTURNO">Noturno (Noite)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Sala de Aula *</label>
                  <input
                    type="text"
                    required
                    value={formData.classroom}
                    onChange={(e) => setFormData({ ...formData, classroom: e.target.value })}
                    className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-indigo-500 focus:outline-none"
                    placeholder="ex: Sala 08"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Capacidade Máxima *</label>
                  <input
                    type="number"
                    required
                    min={10}
                    max={60}
                    value={formData.maxCapacity}
                    onChange={(e) => setFormData({ ...formData, maxCapacity: Number(e.target.value) })}
                    className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-indigo-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Director de Turma *</label>
                <select
                  value={formData.directorTeacherId}
                  onChange={(e) => setFormData({ ...formData, directorTeacherId: e.target.value })}
                  className="w-full rounded-xl border border-slate-300 p-2 text-xs focus:border-indigo-500 focus:outline-none"
                >
                  {db.teachers.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.fullName} ({t.academicDegree})
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-4 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="rounded-xl bg-slate-100 px-4 py-2 font-bold text-slate-700 hover:bg-slate-200"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-indigo-600 px-5 py-2 font-bold text-white hover:bg-indigo-700 shadow-sm"
                >
                  Criar Turma
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
