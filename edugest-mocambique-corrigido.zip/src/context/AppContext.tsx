/**
 * EduGest Moçambique - AppContext Principal
 * Gestão de estado reativo, controlo de permissões RBAC, auditoria automática e operações CRUD.
 */

import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import {
  DatabaseState,
  loadInitialDatabase,
  saveDatabase,
  STORAGE_KEY,
  INITIAL_SCHOOLS,
  INITIAL_USERS,
  INITIAL_SNE_CONFIG
} from '../services/storage';
import {
  UserProfile,
  UserRole,
  RolePermissions,
  School,
  Student,
  Teacher,
  ClassSection,
  Subject,
  Enrollment,
  GradeEntry,
  AttendanceRecord,
  ScheduleSlot,
  PaymentItem,
  DocumentRecord,
  TransferRecord,
  NotificationMessage,
  SNEConfig,
  AuditLog,
  SchoolTask,
  PautaApproval
} from '../types';

export type NavSection =
  | 'dashboard'
  | 'alunos'
  | 'professores'
  | 'matriculas'
  | 'turmas'
  | 'disciplinas'
  | 'avaliacoes'
  | 'pautas'
  | 'assiduidade'
  | 'horarios'
  | 'pagamentos'
  | 'documentos'
  | 'validar-documento'
  | 'transferencias'
  | 'relatorios'
  | 'comunicacao'
  | 'calendario'
  | 'escola-info'
  | 'utilizadores'
  | 'permissoes'
  | 'portal-professor'
  | 'portal-aluno'
  | 'portal-encarregado'
  | 'portal-direcao'
  | 'sne-config'
  | 'auditoria'
  | 'backup';

interface AppContextType {
  db: DatabaseState;
  currentUser: UserProfile;
  currentSchool: School;
  activeTab: NavSection;
  setActiveTab: (tab: NavSection) => void;
  switchRole: (role: UserRole) => void;
  switchSchool: (schoolId: string) => void;
  
  // Alunos
  addStudent: (student: Omit<Student, 'id' | 'createdAt'>) => Student;
  updateStudent: (student: Student) => void;
  deleteStudent: (id: string) => void;
  
  // Professores
  addTeacher: (teacher: Omit<Teacher, 'id'>) => Teacher;
  updateTeacher: (teacher: Teacher) => void;
  
  // Turmas & Disciplinas
  addSection: (section: Omit<ClassSection, 'id'>) => ClassSection;
  updateSection: (section: ClassSection) => void;
  addSubject: (subject: Omit<Subject, 'id'>) => Subject;
  
  // Matrículas
  createEnrollment: (enrollment: Omit<Enrollment, 'id' | 'enrollmentNumber'>) => Enrollment;
  updateEnrollmentStatus: (id: string, status: Enrollment['status']) => void;
  
  // Notas e Avaliações
  updateGradeEntry: (entry: Partial<GradeEntry> & { studentId: string; subjectId: string; sectionId: string; term: 1 | 2 | 3 }) => void;
  batchUpdateGrades: (entries: GradeEntry[]) => void;
  requestGradeChange: (gradeEntryId: string, studentName: string, subjectName: string, field: string, oldValue: number | null, newValue: number | null, reason: string) => void;
  lockSectionGrades: (sectionId: string, subjectId: string, term: 1 | 2 | 3) => void;
  
  // Assiduidade
  saveAttendance: (attendance: Omit<AttendanceRecord, 'id'>) => void;
  
  // Horários
  addScheduleSlot: (slot: Omit<ScheduleSlot, 'id'>) => { success: boolean; conflictReason?: string };
  deleteScheduleSlot: (id: string) => void;
  
  // Finanças e Propinas
  recordPayment: (paymentId: string, method: PaymentItem['paymentMethod'], transactionRef?: string) => void;
  createNewCharge: (charge: Omit<PaymentItem, 'id'>) => PaymentItem;
  
  // Documentos Oficiais
  generateDocument: (doc: Omit<DocumentRecord, 'id' | 'documentNumber' | 'securityHash' | 'issueDate' | 'status'>) => DocumentRecord;
  findDocumentByCode: (codeOrHash: string) => DocumentRecord | null;
  
  // Transferências
  submitTransfer: (transfer: Omit<TransferRecord, 'id' | 'transferGuideNumber' | 'requestDate' | 'status'>) => TransferRecord;
  updateTransferStatus: (id: string, status: TransferRecord['status']) => void;
  
  // Comunicação & Notificações
  sendNotification: (notification: Omit<NotificationMessage, 'id' | 'createdAt'>) => void;
  
  // Configuração SNE
  sneConfig: SNEConfig;
  updateSNEConfig: (config: SNEConfig) => void;
  
  // Gestão de Utilizadores, Códigos e Segurança (Admin)
  addUser: (user: Omit<UserProfile, 'id' | 'accessCode'>) => UserProfile;
  updateUser: (user: UserProfile) => void;
  deleteUser: (id: string) => void;
  toggleUserStatus: (id: string) => void;
  resetUserPin: (id: string, newPin?: string) => string;
  revokeUserAccess: (id: string) => void;
  updateRolePermissions: (role: UserRole, permissions: Partial<RolePermissions>) => void;
  updateSchool: (school: School) => void;

  // Pautas & Aprovações (Direção & Docentes)
  submitPautaForApproval: (submission: Omit<PautaApproval, 'id' | 'submittedAt' | 'status'>) => PautaApproval;
  approvePauta: (id: string, approvedBy: string) => void;
  rejectPauta: (id: string, reason: string) => void;

  // Tarefas & Materiais Escolares (Docentes & Alunos)
  createTask: (task: Omit<SchoolTask, 'id' | 'createdAt'>) => SchoolTask;
  deleteTask: (id: string) => void;

  // Sessão & Autenticação
  loginWithCode: (accessCode: string, pin: string) => { success: boolean; error?: string };
  logout: () => void;
  isLoggedIn: boolean;
  
  // Backup & Restauro
  exportData: () => string;
  importData: (jsonStr: string) => boolean;
  resetToDefaults: () => void;
  restoreDatabase: (data: DatabaseState) => void;
  resetToSampleData: () => void;
}

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [db, setDb] = useState<DatabaseState>(loadInitialDatabase);
  const [activeTab, setActiveTab] = useState<NavSection>('dashboard');
  
  // Utilizador e Escola activos
  const [currentUser, setCurrentUser] = useState<UserProfile>(() => {
    return db.users[0] || INITIAL_USERS[0];
  });

  const [currentSchool, setCurrentSchool] = useState<School>(() => {
    return db.schools.find(s => s.id === currentUser.schoolId) || db.schools[0] || INITIAL_SCHOOLS[0];
  });

  // Guardar alterações automaticamente
  useEffect(() => {
    saveDatabase(db);
  }, [db]);

  // Auditoria interna
  const logAudit = useCallback((action: string, module: string, details: string) => {
    const newLog: AuditLog = {
      id: 'log-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
      schoolId: currentSchool.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      action,
      module,
      details,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
      ipAddress: '197.249.4.' + Math.floor(Math.random() * 200 + 1) + ' (Moçambique)'
    };
    setDb(prev => ({
      ...prev,
      auditLogs: [newLog, ...prev.auditLogs]
    }));
  }, [currentSchool.id, currentUser.name, currentUser.role]);

  // Trocar papel/perfil para fins de demonstração
  const switchRole = useCallback((role: UserRole) => {
    const foundUser = db.users.find(u => u.role === role);
    if (foundUser) {
      setCurrentUser(foundUser);
      logAudit('TROCA_PERFIL', 'SISTEMA', `Sessão alternada para o perfil de ${role} (${foundUser.name}).`);
    } else {
      // Criar fallback se necessário
      const fallback: UserProfile = {
        id: 'user-' + role.toLowerCase(),
        name: `Utilizador ${role}`,
        email: `${role.toLowerCase()}@edugest.co.mz`,
        role,
        accessCode: `${role.slice(0, 4).toUpperCase()}-2026-0099`,
        pin: '1234',
        status: 'ACTIVO',
        schoolId: currentSchool.id
      };
      setCurrentUser(fallback);
    }

    // Encaminhar para a tela mais apropriada do perfil
    if (role === 'ALUNO') setActiveTab('portal-aluno');
    else if (role === 'ENCARREGADO') setActiveTab('portal-encarregado');
    else if (role === 'PROFESSOR') setActiveTab('portal-professor');
    else if (role === 'DIRECAO') setActiveTab('portal-direcao');
    else setActiveTab('dashboard');
  }, [db.users, currentSchool.id, logAudit]);

  // Trocar escola (Multi-SaaS)
  const switchSchool = useCallback((schoolId: string) => {
    const school = db.schools.find(s => s.id === schoolId);
    if (school) {
      setCurrentSchool(school);
      logAudit('TROCA_ESCOLA', 'SISTEMA', `Ambiente alternado para a instituição ${school.name}.`);
    }
  }, [db.schools, logAudit]);

  // 1. Alunos
  const addStudent = useCallback((data: Omit<Student, 'id' | 'createdAt'>): Student => {
    const id = 'std-' + Date.now();
    const newStudent: Student = {
      ...data,
      id,
      schoolId: currentSchool.id,
      createdAt: new Date().toISOString().split('T')[0]
    };
    setDb(prev => ({
      ...prev,
      students: [newStudent, ...prev.students]
    }));
    logAudit('CRIOU_ALUNO', 'ALUNOS', `Cadastrou o aluno ${data.fullName} (${data.studentNumber}).`);
    return newStudent;
  }, [currentSchool.id, logAudit]);

  const updateStudent = useCallback((updated: Student) => {
    setDb(prev => ({
      ...prev,
      students: prev.students.map(s => s.id === updated.id ? updated : s)
    }));
    logAudit('ACTUALIZOU_ALUNO', 'ALUNOS', `Actualizou dados cadastrais de ${updated.fullName}.`);
  }, [logAudit]);

  const deleteStudent = useCallback((id: string) => {
    const student = db.students.find(s => s.id === id);
    setDb(prev => ({
      ...prev,
      students: prev.students.filter(s => s.id !== id)
    }));
    logAudit('REMOVEU_ALUNO', 'ALUNOS', `Eliminou o registo do aluno ${student?.fullName || id}.`);
  }, [db.students, logAudit]);

  // 2. Professores
  const addTeacher = useCallback((data: Omit<Teacher, 'id'>): Teacher => {
    const id = 'prof-' + Date.now();
    const newTeacher: Teacher = { ...data, id, schoolId: currentSchool.id };
    setDb(prev => ({
      ...prev,
      teachers: [newTeacher, ...prev.teachers]
    }));
    logAudit('CRIOU_PROFESSOR', 'PROFESSORES', `Cadastrou o docente ${data.fullName} (${data.employeeNumber}).`);
    return newTeacher;
  }, [currentSchool.id, logAudit]);

  const updateTeacher = useCallback((updated: Teacher) => {
    setDb(prev => ({
      ...prev,
      teachers: prev.teachers.map(t => t.id === updated.id ? updated : t)
    }));
    logAudit('ACTUALIZOU_PROFESSOR', 'PROFESSORES', `Actualizou dados do docente ${updated.fullName}.`);
  }, [logAudit]);

  // 3. Turmas & Disciplinas
  const addSection = useCallback((data: Omit<ClassSection, 'id'>): ClassSection => {
    const id = 'sec-' + Date.now();
    const newSection: ClassSection = { ...data, id, schoolId: currentSchool.id };
    setDb(prev => ({
      ...prev,
      sections: [...prev.sections, newSection]
    }));
    logAudit('CRIOU_TURMA', 'TURMAS', `Criou a turma ${data.gradeLevel} ${data.name}.`);
    return newSection;
  }, [currentSchool.id, logAudit]);

  const updateSection = useCallback((updated: ClassSection) => {
    setDb(prev => ({
      ...prev,
      sections: prev.sections.map(s => s.id === updated.id ? updated : s)
    }));
    logAudit('ACTUALIZOU_TURMA', 'TURMAS', `Actualizou configurações da turma ${updated.gradeLevel} ${updated.name}.`);
  }, [logAudit]);

  const addSubject = useCallback((data: Omit<Subject, 'id'>): Subject => {
    const id = 'sub-' + Date.now();
    const newSub: Subject = { ...data, id, schoolId: currentSchool.id };
    setDb(prev => ({
      ...prev,
      subjects: [...prev.subjects, newSub]
    }));
    logAudit('CRIOU_DISCIPLINA', 'DISCIPLINAS', `Criou a disciplina ${data.name} (${data.code}).`);
    return newSub;
  }, [currentSchool.id, logAudit]);

  // 4. Matrículas
  const createEnrollment = useCallback((data: Omit<Enrollment, 'id' | 'enrollmentNumber'>): Enrollment => {
    const num = 'MAT-2026-' + Math.floor(1000 + Math.random() * 9000);
    const id = 'enr-' + Date.now();
    const newEnr: Enrollment = {
      ...data,
      id,
      enrollmentNumber: num,
      schoolId: currentSchool.id
    };
    setDb(prev => ({
      ...prev,
      enrollments: [newEnr, ...prev.enrollments]
    }));
    logAudit('NOVA_MATRICULA', 'MATRICULAS', `Gerada matrícula ${num} para ${data.studentName}.`);
    return newEnr;
  }, [currentSchool.id, logAudit]);

  const updateEnrollmentStatus = useCallback((id: string, status: Enrollment['status']) => {
    setDb(prev => ({
      ...prev,
      enrollments: prev.enrollments.map(e => e.id === id ? { ...e, status } : e)
    }));
    logAudit('ESTADO_MATRICULA', 'MATRICULAS', `Matrícula ${id} alterada para ${status}.`);
  }, [logAudit]);

  // 5. Notas & Avaliações (Cálculo SNE Moçambique)
  const calculateGrades = (entry: Partial<GradeEntry>): { mpt: number | null; mt: number | null } => {
    const { acs1, acs2, trabalho, acp } = entry;
    const items: number[] = [];
    if (typeof acs1 === 'number') items.push(acs1);
    if (typeof acs2 === 'number') items.push(acs2);
    if (typeof trabalho === 'number') items.push(trabalho);

    let mpt: number | null = null;
    if (items.length > 0) {
      const sum = items.reduce((a, b) => a + b, 0);
      mpt = Number((sum / items.length).toFixed(1));
    }

    let mt: number | null = null;
    if (mpt !== null && typeof acp === 'number') {
      // Fórmula Oficial Ponderada MINEDH: MT = (MPT * 0.4) + (ACP * 0.6)
      mt = Number(((mpt * 0.4) + (acp * 0.6)).toFixed(1));
    } else if (mpt !== null) {
      mt = mpt;
    }

    return { mpt, mt };
  };

  const updateGradeEntry = useCallback((data: Partial<GradeEntry> & { studentId: string; subjectId: string; sectionId: string; term: 1 | 2 | 3 }) => {
    setDb(prev => {
      const existingIdx = prev.grades.findIndex(
        g => g.studentId === data.studentId && g.subjectId === data.subjectId && g.term === data.term
      );

      const computed = calculateGrades(data);
      const timestamp = new Date().toISOString().replace('T', ' ').substring(0, 16);

      if (existingIdx >= 0) {
        const current = prev.grades[existingIdx];
        if (current.status === 'BLOQUEADA') {
          return prev; // Não altera se estiver bloqueada sem pedido prévio
        }
        const updated: GradeEntry = {
          ...current,
          ...data,
          mpt: computed.mpt,
          mt: computed.mt,
          lastModifiedBy: currentUser.name,
          lastModifiedAt: timestamp
        };
        const updatedGrades = [...prev.grades];
        updatedGrades[existingIdx] = updated;
        return { ...prev, grades: updatedGrades };
      } else {
        const newEntry: GradeEntry = {
          id: 'grd-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
          schoolId: currentSchool.id,
          academicYear: 2026,
          studentId: data.studentId,
          subjectId: data.subjectId,
          sectionId: data.sectionId,
          term: data.term,
          acs1: data.acs1 ?? null,
          acs2: data.acs2 ?? null,
          trabalho: data.trabalho ?? null,
          acp: data.acp ?? null,
          mpt: computed.mpt,
          mt: computed.mt,
          status: 'RASCUNHO',
          lastModifiedBy: currentUser.name,
          lastModifiedAt: timestamp
        };
        return { ...prev, grades: [...prev.grades, newEntry] };
      }
    });
  }, [currentSchool.id, currentUser.name]);

  const batchUpdateGrades = useCallback((entries: GradeEntry[]) => {
    setDb(prev => {
      const copy = [...prev.grades];
      for (const entry of entries) {
        const computed = calculateGrades(entry);
        const idx = copy.findIndex(g => g.id === entry.id || (g.studentId === entry.studentId && g.subjectId === entry.subjectId && g.term === entry.term));
        const finalEntry: GradeEntry = {
          ...entry,
          mpt: computed.mpt,
          mt: computed.mt,
          lastModifiedBy: currentUser.name,
          lastModifiedAt: new Date().toISOString().replace('T', ' ').substring(0, 16)
        };
        if (idx >= 0) {
          copy[idx] = finalEntry;
        } else {
          copy.push(finalEntry);
        }
      }
      return { ...prev, grades: copy };
    });
    logAudit('LANCAMENTO_LOTE_NOTAS', 'NOTAS', `Actualização em lote de ${entries.length} notas.`);
  }, [currentUser.name, logAudit]);

  const lockSectionGrades = useCallback((sectionId: string, subjectId: string, term: 1 | 2 | 3) => {
    setDb(prev => ({
      ...prev,
      grades: prev.grades.map(g => {
        if (g.sectionId === sectionId && g.subjectId === subjectId && g.term === term) {
          return { ...g, status: 'VALIDADA' };
        }
        return g;
      })
    }));
    logAudit('VALIDOU_NOTAS', 'NOTAS', `Validou e bloqueou as notas da turma ${sectionId} na disciplina ${subjectId}.`);
  }, [logAudit]);

  const requestGradeChange = useCallback((
    gradeEntryId: string,
    studentName: string,
    subjectName: string,
    field: string,
    oldValue: number | null,
    newValue: number | null,
    reason: string
  ) => {
    const auditItem = {
      id: 'audit-' + Date.now(),
      gradeEntryId,
      studentName,
      subjectName,
      fieldChanged: field,
      oldValue,
      newValue,
      changedBy: currentUser.name,
      reason,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16)
    };
    setDb(prev => ({
      ...prev,
      gradeAudits: [auditItem, ...prev.gradeAudits],
      grades: prev.grades.map(g => {
        if (g.id === gradeEntryId) {
          const updated = { ...g, [field]: newValue };
          const computed = calculateGrades(updated);
          return {
            ...updated,
            mpt: computed.mpt,
            mt: computed.mt,
            lastModifiedBy: currentUser.name,
            lastModifiedAt: auditItem.timestamp
          };
        }
        return g;
      })
    }));
    logAudit('ALTERACAO_NOTA_SOLICITADA', 'NOTAS', `Alterou ${field} de ${oldValue} para ${newValue} para o aluno ${studentName}. Motivo: ${reason}`);
  }, [currentUser.name, logAudit]);

  // 6. Assiduidade
  const saveAttendance = useCallback((data: Omit<AttendanceRecord, 'id'>) => {
    const id = 'att-' + Date.now();
    const newRecord: AttendanceRecord = { ...data, id };
    setDb(prev => {
      // Substituir se já houver registo para a mesma data/turma/disciplina
      const filtered = prev.attendance.filter(
        a => !(a.date === data.date && a.sectionId === data.sectionId && a.subjectId === data.subjectId)
      );
      return {
        ...prev,
        attendance: [newRecord, ...filtered]
      };
    });
    logAudit('CHAMADA_PRESENCAS', 'ASSIDUIDADE', `Registo de presenças para a turma ${data.sectionId} em ${data.date}.`);
  }, [logAudit]);

  // 7. Horários com verificação automática de conflito
  const addScheduleSlot = useCallback((slotData: Omit<ScheduleSlot, 'id'>): { success: boolean; conflictReason?: string } => {
    const conflicts = db.schedules.filter(s => s.dayOfWeek === slotData.dayOfWeek && s.slotNumber === slotData.slotNumber);
    
    // Conflito 1: Professor em duas turmas no mesmo horário
    const profConflict = conflicts.find(s => s.teacherId === slotData.teacherId);
    if (profConflict) {
      return {
        success: false,
        conflictReason: `Conflito de Docente: O professor já se encontra leccionando na turma ${profConflict.sectionId} no mesmo horário.`
      };
    }

    // Conflito 2: Sala de aula ocupada
    const roomConflict = conflicts.find(s => s.classroom.toLowerCase() === slotData.classroom.toLowerCase());
    if (roomConflict) {
      return {
        success: false,
        conflictReason: `Conflito de Espaço: A ${slotData.classroom} já está reservada para outra aula no mesmo tempo.`
      };
    }

    // Conflito 3: A própria turma com duas aulas
    const sectionConflict = conflicts.find(s => s.sectionId === slotData.sectionId);
    if (sectionConflict) {
      return {
        success: false,
        conflictReason: `Conflito de Turma: Esta turma já possui a disciplina ${sectionConflict.subjectId} neste mesmo tempo.`
      };
    }

    const id = 'sch-' + Date.now();
    const newSlot: ScheduleSlot = { ...slotData, id, schoolId: currentSchool.id };
    setDb(prev => ({
      ...prev,
      schedules: [...prev.schedules, newSlot]
    }));
    logAudit('CRIOU_HORARIO', 'HORARIOS', `Alocou tempo ${slotData.slotNumber} para a turma ${slotData.sectionId}.`);
    return { success: true };
  }, [db.schedules, currentSchool.id, logAudit]);

  const deleteScheduleSlot = useCallback((id: string) => {
    setDb(prev => ({
      ...prev,
      schedules: prev.schedules.filter(s => s.id !== id)
    }));
    logAudit('REMOVEU_HORARIO', 'HORARIOS', `Removeu o tempo de aula ${id}.`);
  }, [logAudit]);

  // 8. Finanças e Propinas
  const recordPayment = useCallback((paymentId: string, method: PaymentItem['paymentMethod'], transactionRef?: string) => {
    const receiptNum = 'REC-MZ-2026-' + Math.floor(1000 + Math.random() * 9000);
    const dateStr = new Date().toISOString().split('T')[0];

    setDb(prev => ({
      ...prev,
      payments: prev.payments.map(p => {
        if (p.id === paymentId) {
          return {
            ...p,
            status: 'PAGO',
            paidDate: dateStr,
            paymentMethod: method,
            transactionRef: transactionRef || `REF-${Date.now().toString().slice(-6)}`,
            receiptNumber: receiptNum
          };
        }
        return p;
      })
    }));
    logAudit('REGISTOU_PAGAMENTO', 'FINANCAS', `Confirmou pagamento de propina/taxa para o item ${paymentId} via ${method}. Recibo ${receiptNum}`);
  }, [logAudit]);

  const createNewCharge = useCallback((chargeData: Omit<PaymentItem, 'id'>): PaymentItem => {
    const id = 'pay-' + Date.now();
    const newCharge: PaymentItem = { ...chargeData, id, schoolId: currentSchool.id };
    setDb(prev => ({
      ...prev,
      payments: [newCharge, ...prev.payments]
    }));
    logAudit('LANCAMENTO_COBRANCA', 'FINANCAS', `Lançou encargo de ${chargeData.amount} MT para o aluno ${chargeData.studentName}.`);
    return newCharge;
  }, [currentSchool.id, logAudit]);

  // 9. Documentos Oficiais
  const generateDocument = useCallback((docData: Omit<DocumentRecord, 'id' | 'documentNumber' | 'securityHash' | 'issueDate' | 'status'>): DocumentRecord => {
    const docNum = 'DOC-MZ-2026-' + Math.floor(1000 + Math.random() * 9000);
    const securityHash = 'MZ' + Math.random().toString(36).substring(2, 8).toUpperCase() + Date.now().toString().slice(-4);
    const issueDate = new Date().toISOString().split('T')[0];

    const newDoc: DocumentRecord = {
      ...docData,
      id: 'doc-' + Date.now(),
      schoolId: currentSchool.id,
      documentNumber: docNum,
      securityHash,
      issueDate,
      status: 'VALIDO'
    };

    setDb(prev => ({
      ...prev,
      documents: [newDoc, ...prev.documents]
    }));
    logAudit('EMITIU_DOCUMENTO', 'DOCUMENTOS', `Emitiu ${docData.type} nº ${docNum} para ${docData.studentName}.`);
    return newDoc;
  }, [currentSchool.id, logAudit]);

  const findDocumentByCode = useCallback((codeOrHash: string): DocumentRecord | null => {
    const clean = codeOrHash.trim().toUpperCase();
    return db.documents.find(d => d.documentNumber.toUpperCase() === clean || d.securityHash.toUpperCase() === clean) || null;
  }, [db.documents]);

  // 10. Transferências
  const submitTransfer = useCallback((data: Omit<TransferRecord, 'id' | 'transferGuideNumber' | 'requestDate' | 'status'>): TransferRecord => {
    const guideNum = 'GT-' + (data.type === 'ENTRADA' ? 'ENT' : 'SAI') + '-2026-' + Math.floor(1000 + Math.random() * 9000);
    const id = 'trf-' + Date.now();
    const newTransfer: TransferRecord = {
      ...data,
      id,
      schoolId: currentSchool.id,
      transferGuideNumber: guideNum,
      requestDate: new Date().toISOString().split('T')[0],
      status: 'PENDENTE'
    };
    setDb(prev => ({
      ...prev,
      transfers: [newTransfer, ...prev.transfers]
    }));
    logAudit('SOLICITOU_TRANSFERENCIA', 'TRANSFERENCIAS', `Guia ${guideNum} registada para ${data.studentName}.`);
    return newTransfer;
  }, [currentSchool.id, logAudit]);

  const updateTransferStatus = useCallback((id: string, status: TransferRecord['status']) => {
    setDb(prev => ({
      ...prev,
      transfers: prev.transfers.map(t => t.id === id ? { ...t, status, processDate: new Date().toISOString().split('T')[0] } : t)
    }));
    logAudit('ESTADO_TRANSFERENCIA', 'TRANSFERENCIAS', `Processo de transferência ${id} actualizado para ${status}.`);
  }, [logAudit]);

  // 11. Comunicação
  const sendNotification = useCallback((data: Omit<NotificationMessage, 'id' | 'createdAt'>) => {
    const id = 'notif-' + Date.now();
    const newMsg: NotificationMessage = {
      ...data,
      id,
      schoolId: currentSchool.id,
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 16)
    };
    setDb(prev => ({
      ...prev,
      notifications: [newMsg, ...prev.notifications]
    }));
    logAudit('ENVIOU_COMUNICADO', 'COMUNICACAO', `Publicou aviso "${data.title}" destinado a ${data.targetAudience} via ${data.channel}.`);
  }, [currentSchool.id, logAudit]);

  // 12. Configuração SNE
  const updateSNEConfig = useCallback((config: SNEConfig) => {
    setDb(prev => ({ ...prev, sneConfig: config }));
    logAudit('ACTUALIZOU_SNE', 'SNE', 'Actualizou matriz e directrizes curriculares do Sistema Nacional de Educação.');
  }, [logAudit]);

  // 13. Gestão de Utilizadores, Códigos de Acesso e Segurança (Admin)
  const addUser = useCallback((userData: Omit<UserProfile, 'id' | 'accessCode'>): UserProfile => {
    const id = 'user-' + Date.now();
    const prefixMap: Record<UserRole, string> = {
      ADMIN: 'ADM',
      DIRECAO: 'DIR',
      SECRETARIA: 'SEC',
      PROFESSOR: 'PROF',
      ALUNO: 'ALU',
      ENCARREGADO: 'ENC'
    };
    const prefix = prefixMap[userData.role] || 'USR';
    const roleCount = db.users.filter(u => u.role === userData.role).length + 1;
    const accessCode = `${prefix}-2026-${String(roleCount).padStart(4, '0')}`;
    
    const newUser: UserProfile = {
      ...userData,
      id,
      accessCode,
      pin: userData.pin || '1234',
      status: userData.status || 'ACTIVO',
      schoolId: userData.schoolId || currentSchool.id,
      lastLogin: new Date().toISOString().replace('T', ' ').substring(0, 16)
    };

    setDb(prev => ({
      ...prev,
      users: [newUser, ...prev.users]
    }));

    logAudit('CRIOU_UTILIZADOR', 'SEGURANCA', `Criou conta para ${newUser.name} com código ${accessCode} e perfil ${newUser.role}.`);
    return newUser;
  }, [currentSchool.id, db.users, logAudit]);

  const updateUser = useCallback((user: UserProfile) => {
    setDb(prev => ({
      ...prev,
      users: prev.users.map(u => u.id === user.id ? user : u)
    }));
    if (currentUser.id === user.id) {
      setCurrentUser(user);
    }
    logAudit('ACTUALIZOU_UTILIZADOR', 'SEGURANCA', `Actualizou dados cadastrais de ${user.name} (${user.accessCode}).`);
  }, [currentUser.id, logAudit]);

  const deleteUser = useCallback((id: string) => {
    const target = db.users.find(u => u.id === id);
    setDb(prev => ({
      ...prev,
      users: prev.users.filter(u => u.id !== id)
    }));
    logAudit('ELIMINOU_UTILIZADOR', 'SEGURANCA', `Removeu o utilizador ${target?.name || id} do sistema.`);
  }, [db.users, logAudit]);

  const toggleUserStatus = useCallback((id: string) => {
    setDb(prev => ({
      ...prev,
      users: prev.users.map(u => {
        if (u.id === id) {
          const nextStatus: UserProfile['status'] = u.status === 'ACTIVO' ? 'BLOQUEADO' : 'ACTIVO';
          logAudit('ALTEROU_ESTADO_UTILIZADOR', 'SEGURANCA', `Alterou estado de ${u.name} para ${nextStatus}.`);
          return { ...u, status: nextStatus };
        }
        return u;
      })
    }));
  }, [logAudit]);

  const resetUserPin = useCallback((id: string, newPin?: string): string => {
    const pinToSet = newPin || '1234';
    setDb(prev => ({
      ...prev,
      users: prev.users.map(u => {
        if (u.id === id) {
          logAudit('REDEFINIU_PIN', 'SEGURANCA', `Redefiniu senha/PIN de segurança de ${u.name}.`);
          return { ...u, pin: pinToSet };
        }
        return u;
      })
    }));
    return pinToSet;
  }, [logAudit]);

  const revokeUserAccess = useCallback((id: string) => {
    setDb(prev => ({
      ...prev,
      users: prev.users.map(u => {
        if (u.id === id) {
          logAudit('REVOGOU_ACESSO', 'SEGURANCA', `Revogou credenciais e código de acesso de ${u.name}.`);
          return { ...u, isRevoked: true, status: 'BLOQUEADO' };
        }
        return u;
      })
    }));
  }, [logAudit]);

  const updateRolePermissions = useCallback((role: UserRole, permissions: Partial<RolePermissions>) => {
    setDb(prev => {
      const currentRolePerms = prev.rolePermissions?.[role] || {
        canManageUsers: false,
        canManageSchool: false,
        canManageStudents: false,
        canManageTeachers: false,
        canManageEnrollments: false,
        canManageClasses: false,
        canManageSubjects: false,
        canManageSchedules: false,
        canLaunchGrades: false,
        canApprovePautas: false,
        canManageAttendance: false,
        canManageFinance: false,
        canIssueDocuments: false,
        canManageTransfers: false,
        canViewReports: false,
        canPublishAnnouncements: false,
        canConfigureSNE: false,
        canViewAuditLogs: false
      };
      return {
        ...prev,
        rolePermissions: {
          ...prev.rolePermissions,
          [role]: {
            ...currentRolePerms,
            ...permissions
          }
        }
      };
    });
    logAudit('ALTEROU_PERMISSOES', 'SEGURANCA', `Modificou matriz de permissões para a função ${role}.`);
  }, [logAudit]);

  const updateSchool = useCallback((school: School) => {
    setDb(prev => ({
      ...prev,
      schools: prev.schools.map(s => s.id === school.id ? school : s)
    }));
    if (currentSchool.id === school.id) {
      setCurrentSchool(school);
    }
    logAudit('ACTUALIZOU_ESCOLA', 'ADMINISTRACAO', `Actualizou dados institucionais da escola ${school.name}.`);
  }, [currentSchool.id, logAudit]);

  // 14. Pautas & Aprovações (Direção & Docentes)
  const submitPautaForApproval = useCallback((submission: Omit<PautaApproval, 'id' | 'submittedAt' | 'status'>): PautaApproval => {
    const id = 'papp-' + Date.now();
    const newApproval: PautaApproval = {
      ...submission,
      id,
      submittedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
      status: 'PENDENTE'
    };

    setDb(prev => ({
      ...prev,
      pautaApprovals: [newApproval, ...(prev.pautaApprovals || [])]
    }));

    logAudit('SUBMETEU_PAUTA', 'PAUTAS', `Professor submeteu pauta da turma ${submission.sectionName} (${submission.term}º Trimestre) para homologação da Direcção.`);
    return newApproval;
  }, [logAudit]);

  const approvePauta = useCallback((id: string, approvedBy: string) => {
    setDb(prev => ({
      ...prev,
      pautaApprovals: (prev.pautaApprovals || []).map(p => {
        if (p.id === id) {
          return {
            ...p,
            status: 'HOMOLOGADA' as const,
            approvedBy,
            approvedAt: new Date().toISOString().replace('T', ' ').substring(0, 16)
          };
        }
        return p;
      }),
      // Bloquear edição das notas correspondentes
      grades: prev.grades.map(g => {
        const approval = (prev.pautaApprovals || []).find(pa => pa.id === id);
        if (approval && g.sectionId === approval.sectionId && g.term === approval.term) {
          return { ...g, status: 'BLOQUEADA' as const };
        }
        return g;
      })
    }));
    logAudit('HOMOLOGOU_PAUTA', 'DIRECAO', `A Direcção (${approvedBy}) homologou oficialmente a pauta e bloqueou a edição de notas.`);
  }, [logAudit]);

  const rejectPauta = useCallback((id: string, reason: string) => {
    setDb(prev => ({
      ...prev,
      pautaApprovals: (prev.pautaApprovals || []).map(p => {
        if (p.id === id) {
          return {
            ...p,
            status: 'REJEITADA' as const,
            rejectionReason: reason
          };
        }
        return p;
      })
    }));
    logAudit('REJEITOU_PAUTA', 'DIRECAO', `A Direcção devolveu a pauta para correcção: "${reason}".`);
  }, [logAudit]);

  // 15. Tarefas & Materiais Didáticos
  const createTask = useCallback((taskData: Omit<SchoolTask, 'id' | 'createdAt'>): SchoolTask => {
    const id = 'task-' + Date.now();
    const newTask: SchoolTask = {
      ...taskData,
      id,
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 16)
    };
    setDb(prev => ({
      ...prev,
      tasks: [newTask, ...(prev.tasks || [])]
    }));
    logAudit('PUBLICOU_TAREFA', 'PEDAGOGICO', `Professor ${taskData.teacherName} publicou tarefa/conteúdo "${taskData.title}" para ${taskData.sectionName}.`);
    return newTask;
  }, [logAudit]);

  const deleteTask = useCallback((id: string) => {
    setDb(prev => ({
      ...prev,
      tasks: (prev.tasks || []).filter(t => t.id !== id)
    }));
    logAudit('ELIMINOU_TAREFA', 'PEDAGOGICO', `Removeu tarefa escolar ${id}.`);
  }, [logAudit]);

  // 16. Autenticação & Controlo de Acesso
  const [isLoggedIn, setIsLoggedIn] = useState(true);

  const loginWithCode = useCallback((accessCode: string, pin: string): { success: boolean; error?: string } => {
    const cleanCode = accessCode.trim().toUpperCase();
    const cleanPin = pin.trim();

    const found = db.users.find(u => u.accessCode.toUpperCase() === cleanCode);
    if (!found) {
      logAudit('FALHA_LOGIN', 'SEGURANCA', `Tentativa de login com código inexistente: ${cleanCode}.`);
      return { success: false, error: 'Código de acesso não encontrado no sistema escolar.' };
    }

    if (found.status === 'BLOQUEADO' || found.isRevoked) {
      logAudit('LOGIN_BLOQUEADO', 'SEGURANCA', `Tentativa de acesso por conta bloqueada: ${cleanCode}.`);
      return { success: false, error: 'Esta conta encontra-se bloqueada ou o acesso foi revogado pela administração.' };
    }

    if (found.pin && found.pin !== cleanPin) {
      logAudit('FALHA_PIN', 'SEGURANCA', `PIN incorreto para o utilizador ${found.name} (${cleanCode}).`);
      return { success: false, error: 'Senha/PIN de acesso incorrecto.' };
    }

    const timestamp = new Date().toISOString().replace('T', ' ').substring(0, 16);
    const updatedUser = { ...found, lastLogin: timestamp };

    setDb(prev => ({
      ...prev,
      users: prev.users.map(u => u.id === found.id ? updatedUser : u)
    }));

    setCurrentUser(updatedUser);
    setIsLoggedIn(true);

    if (found.role === 'ALUNO') setActiveTab('portal-aluno');
    else if (found.role === 'ENCARREGADO') setActiveTab('portal-encarregado');
    else if (found.role === 'PROFESSOR') setActiveTab('portal-professor');
    else if (found.role === 'DIRECAO') setActiveTab('portal-direcao');
    else setActiveTab('dashboard');

    logAudit('LOGIN_SUCESSO', 'SEGURANCA', `Início de sessão bem-sucedido de ${found.name} (${found.role}).`);
    return { success: true };
  }, [db.users, logAudit]);

  const logout = useCallback(() => {
    logAudit('LOGOUT', 'SEGURANCA', `Utilizador ${currentUser.name} encerrou a sessão.`);
    setIsLoggedIn(false);
  }, [currentUser.name, logAudit]);

  // 17. Backup & Restauro
  const exportData = useCallback((): string => {
    logAudit('EXPORT_BACKUP', 'SISTEMA', 'Exportou backup completo da base de dados escolar em formato JSON.');
    return JSON.stringify(db, null, 2);
  }, [db, logAudit]);

  const importData = useCallback((jsonStr: string): boolean => {
    try {
      const parsed = JSON.parse(jsonStr);
      if (parsed && parsed.schools && parsed.students) {
        setDb(parsed);
        logAudit('IMPORT_BACKUP', 'SISTEMA', 'Restaurou com sucesso a base de dados a partir de ficheiro externo.');
        return true;
      }
      return false;
    } catch {
      return false;
    }
  }, [logAudit]);

  const resetToDefaults = useCallback(() => {
    if (typeof window !== 'undefined') {
      localStorage.removeItem(STORAGE_KEY);
    }
    const fresh = loadInitialDatabase();
    setDb(fresh);
    setCurrentUser(fresh.users[0]);
    setCurrentSchool(fresh.schools[0]);
  }, []);

  return (
    <AppContext.Provider
      value={{
        db,
        currentUser,
        currentSchool,
        activeTab,
        setActiveTab,
        switchRole,
        switchSchool,
        addStudent,
        updateStudent,
        deleteStudent,
        addTeacher,
        updateTeacher,
        addSection,
        updateSection,
        addSubject,
        createEnrollment,
        updateEnrollmentStatus,
        updateGradeEntry,
        batchUpdateGrades,
        lockSectionGrades,
        requestGradeChange,
        saveAttendance,
        addScheduleSlot,
        deleteScheduleSlot,
        recordPayment,
        createNewCharge,
        generateDocument,
        findDocumentByCode,
        submitTransfer,
        updateTransferStatus,
        sendNotification,
        updateSNEConfig,
        sneConfig: db.sneConfig || INITIAL_SNE_CONFIG,
        addUser,
        updateUser,
        deleteUser,
        toggleUserStatus,
        resetUserPin,
        revokeUserAccess,
        updateRolePermissions,
        updateSchool,
        submitPautaForApproval,
        approvePauta,
        rejectPauta,
        createTask,
        deleteTask,
        loginWithCode,
        logout,
        isLoggedIn,
        exportData,
        importData,
        resetToDefaults,
        restoreDatabase: (data: DatabaseState) => {
          setDb(data);
          saveDatabase(data);
        },
        resetToSampleData: resetToDefaults
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const ctx = useContext(AppContext);
  if (!ctx) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return ctx;
};
