/**
 * EduGest Moçambique - Serviço de Armazenamento e Base de Dados Local
 * Suporte a isolamento multi-escola (SaaS), persistência em localStorage e sincronização.
 */

import {
  School,
  AcademicYear,
  SNEConfig,
  Student,
  Teacher,
  ClassSection,
  Subject,
  Enrollment,
  GradeEntry,
  GradeAuditLog,
  AttendanceRecord,
  ScheduleSlot,
  PaymentItem,
  DocumentRecord,
  TransferRecord,
  NotificationMessage,
  AuditLog,
  UserProfile,
  UserRole,
  RolePermissions,
  SchoolTask,
  PautaApproval
} from '../types';

export const STORAGE_KEY = 'edugest_mz_db_v1';

// Escolas Iniciais
export const INITIAL_SCHOOLS: School[] = [
  {
    id: 'school-1',
    name: 'Escola Secundária Josina Machel',
    code: 'ESJM-MAPUTO-01',
    type: 'PUBLICA',
    province: 'Maputo Cidade',
    district: 'Distrito Urbano KaMpfumo',
    address: 'Av. Julius Nyerere, nº 1400, Sommerschield',
    phone: '+258 21 490 120',
    email: 'contacto@esjm.edu.mz',
    directorName: 'Dra. Graça Mandlate Cossa',
    nuit: '400192831'
  },
  {
    id: 'school-2',
    name: 'Colégio Privado Estrela da Manhã',
    code: 'CPEM-MATOLA-04',
    type: 'PRIVADA',
    province: 'Província de Maputo',
    district: 'Cidade da Matola',
    address: 'Av. 4 de Outubro, Bairro Fomento',
    phone: '+258 84 310 9900',
    email: 'secretaria@estreladamanha.co.mz',
    directorName: 'Prof. Dr. Armando Bila Cossa',
    nuit: '400928172'
  },
  {
    id: 'school-3',
    name: 'Escola Secundária Samora Machel',
    code: 'ESSM-BEIRA-02',
    type: 'PUBLICA',
    province: 'Sofala',
    district: 'Cidade da Beira',
    address: 'Rua Correia de Brito, Bairro Chaimite',
    phone: '+258 23 324 110',
    email: 'samoramachel.beira@minedh.gov.mz',
    directorName: 'Mestre Celso Nhancale',
    nuit: '400331092'
  }
];

// Ano Lectivo 2026
export const INITIAL_ACADEMIC_YEARS: AcademicYear[] = [
  {
    id: 'year-2026',
    year: 2026,
    status: 'ACTIVO',
    startDate: '2026-02-02',
    endDate: '2026-11-27',
    currentTerm: 1
  },
  {
    id: 'year-2025',
    year: 2025,
    status: 'ENCERRADO',
    startDate: '2025-02-03',
    endDate: '2025-11-28',
    currentTerm: 3
  }
];

// Configuração Oficial do Sistema Nacional de Educação (SNE) de Moçambique
export const INITIAL_SNE_CONFIG: SNEConfig = {
  academicYear: 2026,
  currentTerm: 1,
  minGrade: 0,
  maxGrade: 20,
  passingGrade: 10,
  minPassingGrade: 10,
  termsCount: 3,
  evaluationFormula: 'STANDARD_MINEDH', // MPT = (ACS1+ACS2+TI)/3 ; MT = (MPT*0.4) + (ACP*0.6)
  maxAbsencePercentage: 25,
  examExemptionGrade: 14,
  examAdmissionGrade: 10,
  gradingFormula: 'MT = (MPT * 0.4) + (ACP * 0.6)',
  mptWeight: 0.4,
  acpWeight: 0.6,
  allowGradeEditingAfterLock: false,
  levels: [
    {
      id: 'ep',
      name: 'Ensino Primário',
      cycles: [
        { cycleName: '1º Ciclo', classes: ['1ª Classe', '2ª Classe'] },
        { cycleName: '2º Ciclo', classes: ['3ª Classe', '4ª Classe'] },
        { cycleName: '3º Ciclo', classes: ['5ª Classe', '6ª Classe'] }
      ]
    },
    {
      id: 'esg-1',
      name: 'Ensino Secundário Geral - 1º Ciclo',
      cycles: [
        { cycleName: 'Ciclo Geral Básico', classes: ['7ª Classe', '8ª Classe', '9ª Classe'] }
      ]
    },
    {
      id: 'esg-2',
      name: 'Ensino Secundário Geral - 2º Ciclo (Pré-Universitário)',
      cycles: [
        { cycleName: 'Ciclo de Especialização', classes: ['10ª Classe', '11ª Classe', '12ª Classe'] }
      ]
    }
  ]
};

// Utilizadores de Demonstração para os 6 Perfis com Códigos Oficiais de Acesso
export const INITIAL_USERS: UserProfile[] = [
  {
    id: 'user-admin',
    name: 'Eng. Dionísio Matsinhe',
    email: 'admin@edugest.co.mz',
    role: 'ADMIN',
    accessCode: 'ADM-2026-0001',
    pin: '1234',
    status: 'ACTIVO',
    schoolId: 'school-1',
    phone: '+258 84 555 1000',
    lastLogin: '2026-04-06 08:15'
  },
  {
    id: 'user-direcao',
    name: 'Dra. Graça Mandlate Cossa',
    email: 'direcao@esjm.edu.mz',
    role: 'DIRECAO',
    accessCode: 'DIR-2026-0001',
    pin: '1234',
    status: 'ACTIVO',
    schoolId: 'school-1',
    phone: '+258 82 444 2000',
    lastLogin: '2026-04-06 07:45'
  },
  {
    id: 'user-secretaria',
    name: 'Sr. Sérgio Nhantumbo',
    email: 'secretaria@esjm.edu.mz',
    role: 'SECRETARIA',
    accessCode: 'SEC-2026-0001',
    pin: '1234',
    status: 'ACTIVO',
    schoolId: 'school-1',
    phone: '+258 87 333 4000',
    lastLogin: '2026-04-06 08:00'
  },
  {
    id: 'user-professor',
    name: 'Prof. Adelino Sitoe',
    email: 'adelino.sitoe@esjm.edu.mz',
    role: 'PROFESSOR',
    accessCode: 'PROF-2026-0048',
    pin: '1234',
    status: 'ACTIVO',
    schoolId: 'school-1',
    phone: '+258 84 999 5000',
    linkedTeacherId: 'teacher-1',
    lastLogin: '2026-04-05 15:10'
  },
  {
    id: 'user-encarregado',
    name: 'Sr. Fernando Macuácua',
    email: 'fernando.macuacua@gmail.com',
    role: 'ENCARREGADO',
    accessCode: 'ENC-2026-0012',
    pin: '1234',
    status: 'ACTIVO',
    schoolId: 'school-1',
    phone: '+258 84 123 7890',
    linkedStudentId: 'student-1',
    linkedStudentIds: ['student-1', 'student-3'],
    lastLogin: '2026-04-05 18:20'
  },
  {
    id: 'user-aluno',
    name: 'Nelsia Fernando Macuácua',
    email: 'nelsia.macuacua@aluno.esjm.edu.mz',
    role: 'ALUNO',
    accessCode: 'ALU-2026-0421',
    pin: '1234',
    status: 'ACTIVO',
    schoolId: 'school-1',
    phone: '+258 84 987 6543',
    linkedStudentId: 'student-1',
    lastLogin: '2026-04-05 19:40'
  }
];

export const INITIAL_TEACHERS: Teacher[] = [
  {
    id: 'teacher-1',
    schoolId: 'school-1',
    employeeNumber: 'DOC-2022-014',
    fullName: 'Prof. Adelino Sitoe',
    gender: 'M',
    birthDate: '1984-06-14',
    phone: '+258 84 999 5000',
    email: 'adelino.sitoe@esjm.edu.mz',
    nuit: '109283741',
    academicDegree: 'Licenciatura em Ensino de Matemática (Universidade Pedagógica de Maputo)',
    specializationArea: 'Ciências Exactas',
    assignedSubjects: ['Matemática', 'Física'],
    subjects: ['Matemática', 'Física'],
    assignedClasses: ['10ª Classe', '11ª Classe'],
    assignedSections: ['sec-10a', 'sec-10b', 'sec-11a'],
    status: 'ACTIVO',
    workloadHours: 24,
    weeklyHours: 24,
    institutionGraduated: 'Universidade Pedagógica de Moçambique (UP)',
    hireDate: '2022-02-01'
  },
  {
    id: 'teacher-2',
    schoolId: 'school-1',
    employeeNumber: 'DOC-2020-038',
    fullName: 'Profª. Maria Helena Tembe',
    gender: 'F',
    birthDate: '1988-11-20',
    phone: '+258 82 333 8811',
    email: 'helena.tembe@esjm.edu.mz',
    nuit: '102948572',
    academicDegree: 'Mestrado em Língua Portuguesa e Literatura Moçambicana (UEM)',
    specializationArea: 'Letras e Ciências Humanas',
    assignedSubjects: ['Português', 'Literatura'],
    subjects: ['Português', 'Literatura'],
    assignedClasses: ['10ª Classe', '12ª Classe'],
    assignedSections: ['sec-10a', 'sec-12a'],
    status: 'ACTIVO',
    workloadHours: 20,
    weeklyHours: 20,
    institutionGraduated: 'Universidade Eduardo Mondlane (UEM)',
    hireDate: '2020-02-01'
  },
  {
    id: 'teacher-3',
    schoolId: 'school-1',
    employeeNumber: 'DOC-2023-055',
    fullName: 'Prof. Bento Xavier Mabunda',
    gender: 'M',
    birthDate: '1990-03-05',
    phone: '+258 86 555 4321',
    email: 'bento.mabunda@esjm.edu.mz',
    nuit: '108472910',
    academicDegree: 'Licenciatura em Ensino de Biologia e Química (UP)',
    specializationArea: 'Ciências Naturais',
    assignedSubjects: ['Biologia', 'Química'],
    subjects: ['Biologia', 'Química'],
    assignedClasses: ['10ª Classe', '11ª Classe'],
    assignedSections: ['sec-10a', 'sec-11a'],
    status: 'ACTIVO',
    workloadHours: 22,
    weeklyHours: 22,
    institutionGraduated: 'Universidade Pedagógica (UP)',
    hireDate: '2023-02-01'
  },
  {
    id: 'teacher-4',
    schoolId: 'school-1',
    employeeNumber: 'DOC-2021-019',
    fullName: 'Prof. António Guambe',
    gender: 'M',
    birthDate: '1982-08-17',
    phone: '+258 87 222 9900',
    email: 'antonio.guambe@esjm.edu.mz',
    nuit: '104728193',
    academicDegree: 'Licenciatura em História e Geografia (Universidade Eduardo Mondlane)',
    specializationArea: 'Ciências Sociais',
    assignedSubjects: ['História', 'Geografia'],
    subjects: ['História', 'Geografia'],
    assignedClasses: ['10ª Classe', '9ª Classe'],
    assignedSections: ['sec-10a', 'sec-9a'],
    status: 'ACTIVO',
    workloadHours: 18,
    weeklyHours: 18,
    institutionGraduated: 'Universidade Eduardo Mondlane (UEM)',
    hireDate: '2021-02-01'
  }
];

export const INITIAL_SECTIONS: ClassSection[] = [
  {
    id: 'sec-10a',
    schoolId: 'school-1',
    academicYear: 2026,
    gradeLevel: '10ª Classe',
    name: 'Turma A',
    shift: 'DIURNO',
    classroom: 'Sala 12 - Bloco Central',
    directorTeacherId: 'teacher-1',
    maxCapacity: 45,
    currentEnrolled: 42,
    courseArea: 'GERAL'
  },
  {
    id: 'sec-10b',
    schoolId: 'school-1',
    academicYear: 2026,
    gradeLevel: '10ª Classe',
    name: 'Turma B',
    shift: 'VESPERTINO',
    classroom: 'Sala 14 - Bloco Central',
    directorTeacherId: 'teacher-2',
    maxCapacity: 45,
    currentEnrolled: 40,
    courseArea: 'GERAL'
  },
  {
    id: 'sec-11a',
    schoolId: 'school-1',
    academicYear: 2026,
    gradeLevel: '11ª Classe',
    name: 'Turma A (Ciências com Biologia)',
    shift: 'DIURNO',
    classroom: 'Laboratório de Ciências',
    directorTeacherId: 'teacher-3',
    maxCapacity: 40,
    currentEnrolled: 38,
    courseArea: 'CIENCIAS'
  },
  {
    id: 'sec-12a',
    schoolId: 'school-1',
    academicYear: 2026,
    gradeLevel: '12ª Classe',
    name: 'Turma A (Letras e Ciências Sociais)',
    shift: 'DIURNO',
    classroom: 'Sala 08 - Bloco Nobre',
    directorTeacherId: 'teacher-4',
    maxCapacity: 40,
    currentEnrolled: 36,
    courseArea: 'LETRAS'
  },
  {
    id: 'sec-9a',
    schoolId: 'school-1',
    academicYear: 2026,
    gradeLevel: '9ª Classe',
    name: 'Turma A',
    shift: 'DIURNO',
    classroom: 'Sala 05 - Bloco B',
    directorTeacherId: 'teacher-4',
    maxCapacity: 50,
    currentEnrolled: 47,
    courseArea: 'GERAL'
  }
];

export const INITIAL_SUBJECTS: Subject[] = [
  { id: 'sub-mat-10', schoolId: 'school-1', code: 'MAT-10', name: 'Matemática', gradeLevel: '10ª Classe', weeklyHours: 5, teacherId: 'teacher-1', teacherName: 'Prof. Adelino Sitoe', isElective: false, applicableGrades: ['10ª Classe', '11ª Classe'], type: 'NUCLEAR', isRequired: true },
  { id: 'sub-port-10', schoolId: 'school-1', code: 'POR-10', name: 'Português', gradeLevel: '10ª Classe', weeklyHours: 5, teacherId: 'teacher-2', teacherName: 'Profª. Maria Helena Tembe', isElective: false, applicableGrades: ['10ª Classe', '11ª Classe', '12ª Classe'], type: 'NUCLEAR', isRequired: true },
  { id: 'sub-fis-10', schoolId: 'school-1', code: 'FIS-10', name: 'Física', gradeLevel: '10ª Classe', weeklyHours: 3, teacherId: 'teacher-1', teacherName: 'Prof. Adelino Sitoe', isElective: false, applicableGrades: ['10ª Classe', '11ª Classe'], type: 'NUCLEAR', isRequired: true },
  { id: 'sub-qui-10', schoolId: 'school-1', code: 'QUI-10', name: 'Química', gradeLevel: '10ª Classe', weeklyHours: 3, teacherId: 'teacher-3', teacherName: 'Prof. Bento Xavier Mabunda', isElective: false, applicableGrades: ['10ª Classe', '11ª Classe'], type: 'NUCLEAR', isRequired: true },
  { id: 'sub-bio-10', schoolId: 'school-1', code: 'BIO-10', name: 'Biologia', gradeLevel: '10ª Classe', weeklyHours: 3, teacherId: 'teacher-3', teacherName: 'Prof. Bento Xavier Mabunda', isElective: false, applicableGrades: ['10ª Classe', '11ª Classe'], type: 'NUCLEAR', isRequired: true },
  { id: 'sub-hist-10', schoolId: 'school-1', code: 'HIS-10', name: 'História', gradeLevel: '10ª Classe', weeklyHours: 2, teacherId: 'teacher-4', teacherName: 'Prof. António Guambe', isElective: false, applicableGrades: ['10ª Classe'], type: 'COMPLEMENTAR', isRequired: true },
  { id: 'sub-geo-10', schoolId: 'school-1', code: 'GEO-10', name: 'Geografia', gradeLevel: '10ª Classe', weeklyHours: 2, teacherId: 'teacher-4', teacherName: 'Prof. António Guambe', isElective: false, applicableGrades: ['10ª Classe'], type: 'COMPLEMENTAR', isRequired: true },
  { id: 'sub-ing-10', schoolId: 'school-1', code: 'ING-10', name: 'Inglês', gradeLevel: '10ª Classe', weeklyHours: 3, teacherId: 'teacher-2', teacherName: 'Profª. Maria Helena Tembe', isElective: false, applicableGrades: ['10ª Classe', '11ª Classe', '12ª Classe'], type: 'NUCLEAR', isRequired: true },
  { id: 'sub-edfis-10', schoolId: 'school-1', code: 'EDF-10', name: 'Educação Física', gradeLevel: '10ª Classe', weeklyHours: 2, teacherId: 'teacher-1', teacherName: 'Prof. Adelino Sitoe', isElective: false, applicableGrades: ['10ª Classe'], type: 'COMPLEMENTAR', isRequired: true },
  { id: 'sub-tic-10', schoolId: 'school-1', code: 'TIC-10', name: 'Tecnologias de Informação e Comunicação (TIC)', gradeLevel: '10ª Classe', weeklyHours: 2, isElective: true, applicableGrades: ['10ª Classe', '11ª Classe'], type: 'OPCAO', isRequired: false }
];

export const INITIAL_STUDENTS: Student[] = [
  {
    id: 'student-1',
    schoolId: 'school-1',
    studentNumber: 'AL-2026-0042',
    fullName: 'Nelsia Fernando Macuácua',
    gender: 'F',
    birthDate: '2010-04-12',
    birthPlace: 'Maputo Cidade',
    district: 'Distrito KaMpfumo',
    province: 'Maputo Cidade',
    nationality: 'Moçambicana',
    idDocType: 'BI',
    idDocNumber: '110293847291B',
    nuit: '120938471',
    phone: '+258 84 987 6543',
    address: 'Bairro da Polana Cimento, Rua de Mukumbura, nº 244',
    fatherName: 'Fernando Alberto Macuácua',
    motherName: 'Rosa Joana Cossa',
    guardianName: 'Fernando Alberto Macuácua',
    guardianPhone: '+258 84 123 7890',
    guardianEmail: 'fernando.macuacua@gmail.com',
    guardianRelation: 'PAI',
    medicalNotes: 'Nenhuma alergia conhecida. Grupo sanguíneo O+.',
    specialNeeds: 'Nenhuma',
    schoolHistory: 'Concluiu a 9ª classe em 2025 com média de 14.5 valores na EPC 3 de Fevereiro.',
    currentClass: '10ª Classe',
    currentSection: 'Turma A',
    status: 'ACTIVO',
    createdAt: '2026-01-15'
  },
  {
    id: 'student-2',
    schoolId: 'school-1',
    studentNumber: 'AL-2026-0043',
    fullName: 'Edson Zacarias Mondlane',
    gender: 'M',
    birthDate: '2009-09-25',
    birthPlace: 'Chibuto',
    district: 'Chibuto',
    province: 'Gaza',
    nationality: 'Moçambicana',
    idDocType: 'BI',
    idDocNumber: '090182746193M',
    nuit: '119283742',
    phone: '+258 82 777 4411',
    address: 'Bairro do Alto Maé, Rua General Craveiro Lopes, nº 88',
    fatherName: 'Zacarias Mondlane',
    motherName: 'Albertina Sitoe',
    guardianName: 'Albertina Sitoe',
    guardianPhone: '+258 82 777 4400',
    guardianEmail: 'albertina.sitoe@hotmail.com',
    guardianRelation: 'MAE',
    medicalNotes: 'Usa lentes de contacto / óculos graduados para miopia.',
    specialNeeds: 'Dificuldade visual ligeira',
    schoolHistory: 'Transferido da EPC de Chibuto em 2024.',
    currentClass: '10ª Classe',
    currentSection: 'Turma A',
    status: 'ACTIVO',
    createdAt: '2026-01-16'
  },
  {
    id: 'student-3',
    schoolId: 'school-1',
    studentNumber: 'AL-2026-0044',
    fullName: 'Samira Abdul Carimo',
    gender: 'F',
    birthDate: '2010-01-18',
    birthPlace: 'Nampula',
    district: 'Cidade de Nampula',
    province: 'Nampula',
    nationality: 'Moçambicana',
    idDocType: 'BI',
    idDocNumber: '110394857201K',
    nuit: '121049284',
    phone: '+258 87 654 3210',
    address: 'Bairro da Sommerschield II, Rua do Palmar, nº 12',
    fatherName: 'Abdul Carimo Issufo',
    motherName: 'Fátima Sulemane',
    guardianName: 'Abdul Carimo Issufo',
    guardianPhone: '+258 87 654 0000',
    guardianEmail: 'abdul.carimo@empresa.co.mz',
    guardianRelation: 'PAI',
    medicalNotes: 'Asmática ligeira. Traz inalador de recurso.',
    specialNeeds: 'Nenhuma',
    schoolHistory: 'Frequentou o 1º ciclo na Escola Comunitária de Nampula.',
    currentClass: '10ª Classe',
    currentSection: 'Turma A',
    status: 'ACTIVO',
    createdAt: '2026-01-18'
  },
  {
    id: 'student-4',
    schoolId: 'school-1',
    studentNumber: 'AL-2026-0045',
    fullName: 'Tarcísio da Graça Langa',
    gender: 'M',
    birthDate: '2010-07-30',
    birthPlace: 'Matola',
    district: 'Matola',
    province: 'Província de Maputo',
    nationality: 'Moçambicana',
    idDocType: 'BI',
    idDocNumber: '110827394019G',
    nuit: '122938475',
    phone: '+258 84 001 2345',
    address: 'Bairro da Liberdade, Matola',
    fatherName: 'Graça Langa',
    motherName: 'Lucília Munguambe',
    guardianName: 'Lucília Munguambe',
    guardianPhone: '+258 84 001 2340',
    guardianRelation: 'MAE',
    medicalNotes: 'Nenhuma condição reportada.',
    specialNeeds: 'Nenhuma',
    schoolHistory: 'Aprovado na 9ª classe com mérito desportivo.',
    currentClass: '10ª Classe',
    currentSection: 'Turma A',
    status: 'ACTIVO',
    createdAt: '2026-01-19'
  },
  {
    id: 'student-5',
    schoolId: 'school-1',
    studentNumber: 'AL-2026-0046',
    fullName: 'Benilde Ivone Chissano',
    gender: 'F',
    birthDate: '2009-12-03',
    birthPlace: 'Xai-Xai',
    district: 'Xai-Xai',
    province: 'Gaza',
    nationality: 'Moçambicana',
    idDocType: 'BI',
    idDocNumber: '109827364501F',
    nuit: '124938271',
    phone: '+258 86 112 3344',
    address: 'Bairro Central, Av. Eduardo Mondlane, nº 1500',
    fatherName: 'Joaquim Alberto Chissano Jr.',
    motherName: 'Marta Bila',
    guardianName: 'Marta Bila',
    guardianPhone: '+258 86 112 3300',
    guardianRelation: 'MAE',
    medicalNotes: 'Nenhuma',
    specialNeeds: 'Nenhuma',
    schoolHistory: 'Concluiu o 1º ciclo do ESG em Xai-Xai.',
    currentClass: '10ª Classe',
    currentSection: 'Turma A',
    status: 'ACTIVO',
    createdAt: '2026-01-20'
  },
  {
    id: 'student-6',
    schoolId: 'school-1',
    studentNumber: 'AL-2026-0047',
    fullName: 'Kelvin Manuel Muchanga',
    gender: 'M',
    birthDate: '2008-05-14',
    birthPlace: 'Inhambane',
    district: 'Maxixe',
    province: 'Inhambane',
    nationality: 'Moçambicana',
    idDocType: 'BI',
    idDocNumber: '108293847501X',
    nuit: '123849102',
    phone: '+258 84 445 6677',
    address: 'Bairro de Malhangalene, Rua de Timor, nº 55',
    fatherName: 'Manuel Muchanga',
    motherName: 'Helena Guirrugo',
    guardianName: 'Manuel Muchanga',
    guardianPhone: '+258 84 445 6600',
    guardianRelation: 'PAI',
    medicalNotes: 'Nenhuma',
    specialNeeds: 'Nenhuma',
    schoolHistory: 'Matriculado regularmente.',
    currentClass: '11ª Classe',
    currentSection: 'Turma A (Ciências com Biologia)',
    status: 'ACTIVO',
    createdAt: '2026-01-22'
  }
];

export const INITIAL_ENROLLMENTS: Enrollment[] = [
  {
    id: 'enr-1',
    schoolId: 'school-1',
    academicYear: 2026,
    studentId: 'student-1',
    studentName: 'Nelsia Fernando Macuácua',
    gradeLevel: '10ª Classe',
    sectionId: 'sec-10a',
    sectionName: 'Turma A',
    enrollmentNumber: 'MAT-2026-0042',
    date: '2026-01-15',
    status: 'CONFIRMADA',
    guardianName: 'Fernando Alberto Macuácua',
    guardianPhone: '+258 84 123 7890',
    receiptNumber: 'REC-2026-00192'
  },
  {
    id: 'enr-2',
    schoolId: 'school-1',
    academicYear: 2026,
    studentId: 'student-2',
    studentName: 'Edson Zacarias Mondlane',
    gradeLevel: '10ª Classe',
    sectionId: 'sec-10a',
    sectionName: 'Turma A',
    enrollmentNumber: 'MAT-2026-0043',
    date: '2026-01-16',
    status: 'CONFIRMADA',
    guardianName: 'Albertina Sitoe',
    guardianPhone: '+258 82 777 4400',
    receiptNumber: 'REC-2026-00193'
  },
  {
    id: 'enr-3',
    schoolId: 'school-1',
    academicYear: 2026,
    studentId: 'student-3',
    studentName: 'Samira Abdul Carimo',
    gradeLevel: '10ª Classe',
    sectionId: 'sec-10a',
    sectionName: 'Turma A',
    enrollmentNumber: 'MAT-2026-0044',
    date: '2026-01-18',
    status: 'CONFIRMADA',
    guardianName: 'Abdul Carimo Issufo',
    guardianPhone: '+258 87 654 0000',
    receiptNumber: 'REC-2026-00194'
  },
  {
    id: 'enr-4',
    schoolId: 'school-1',
    academicYear: 2026,
    studentId: 'student-4',
    studentName: 'Tarcísio da Graça Langa',
    gradeLevel: '10ª Classe',
    sectionId: 'sec-10a',
    sectionName: 'Turma A',
    enrollmentNumber: 'MAT-2026-0045',
    date: '2026-01-19',
    status: 'CONFIRMADA',
    guardianName: 'Lucília Munguambe',
    guardianPhone: '+258 84 001 2340',
    receiptNumber: 'REC-2026-00195'
  },
  {
    id: 'enr-5',
    schoolId: 'school-1',
    academicYear: 2026,
    studentId: 'student-5',
    studentName: 'Benilde Ivone Chissano',
    gradeLevel: '10ª Classe',
    sectionId: 'sec-10a',
    sectionName: 'Turma A',
    enrollmentNumber: 'MAT-2026-0046',
    date: '2026-01-20',
    status: 'PENDENTE',
    guardianName: 'Marta Bila',
    guardianPhone: '+258 86 112 3300'
  }
];

// Lançamento Inicial de Notas para 10ª Classe - Matemática e Português
export const INITIAL_GRADES: GradeEntry[] = [
  {
    id: 'grd-1-mat',
    schoolId: 'school-1',
    academicYear: 2026,
    studentId: 'student-1',
    subjectId: 'sub-mat-10',
    sectionId: 'sec-10a',
    term: 1,
    acs1: 16.0,
    acs2: 17.5,
    trabalho: 16.0,
    acp: 15.0,
    mpt: 16.5,
    mt: 15.6,
    status: 'VALIDADA',
    lastModifiedBy: 'Prof. Adelino Sitoe',
    lastModifiedAt: '2026-03-28 14:32'
  },
  {
    id: 'grd-1-por',
    schoolId: 'school-1',
    academicYear: 2026,
    studentId: 'student-1',
    subjectId: 'sub-port-10',
    sectionId: 'sec-10a',
    term: 1,
    acs1: 15.0,
    acs2: 14.0,
    trabalho: 16.0,
    acp: 14.5,
    mpt: 15.0,
    mt: 14.7,
    status: 'VALIDADA',
    lastModifiedBy: 'Profª. Maria Helena Tembe',
    lastModifiedAt: '2026-03-29 11:20'
  },
  {
    id: 'grd-2-mat',
    schoolId: 'school-1',
    academicYear: 2026,
    studentId: 'student-2',
    subjectId: 'sub-mat-10',
    sectionId: 'sec-10a',
    term: 1,
    acs1: 12.0,
    acs2: 11.0,
    trabalho: 13.5,
    acp: 10.0,
    mpt: 12.2,
    mt: 10.9,
    status: 'VALIDADA',
    lastModifiedBy: 'Prof. Adelino Sitoe',
    lastModifiedAt: '2026-03-28 14:35'
  },
  {
    id: 'grd-3-mat',
    schoolId: 'school-1',
    academicYear: 2026,
    studentId: 'student-3',
    subjectId: 'sub-mat-10',
    sectionId: 'sec-10a',
    term: 1,
    acs1: 18.0,
    acs2: 19.0,
    trabalho: 18.5,
    acp: 17.5,
    mpt: 18.5,
    mt: 17.9,
    status: 'VALIDADA',
    lastModifiedBy: 'Prof. Adelino Sitoe',
    lastModifiedAt: '2026-03-28 14:36'
  },
  {
    id: 'grd-4-mat',
    schoolId: 'school-1',
    academicYear: 2026,
    studentId: 'student-4',
    subjectId: 'sub-mat-10',
    sectionId: 'sec-10a',
    term: 1,
    acs1: 8.5,
    acs2: 9.0,
    trabalho: 10.0,
    acp: 8.0,
    mpt: 9.2,
    mt: 8.5,
    status: 'RASCUNHO',
    lastModifiedBy: 'Prof. Adelino Sitoe',
    lastModifiedAt: '2026-04-02 16:10'
  },
  {
    id: 'grd-5-mat',
    schoolId: 'school-1',
    academicYear: 2026,
    studentId: 'student-5',
    subjectId: 'sub-mat-10',
    sectionId: 'sec-10a',
    term: 1,
    acs1: 14.0,
    acs2: 13.5,
    trabalho: 15.0,
    acp: 14.0,
    mpt: 14.2,
    mt: 14.1,
    status: 'VALIDADA',
    lastModifiedBy: 'Prof. Adelino Sitoe',
    lastModifiedAt: '2026-03-28 14:38'
  }
];

export const INITIAL_AUDIT_GRADES: GradeAuditLog[] = [
  {
    id: 'audit-grd-1',
    gradeEntryId: 'grd-4-mat',
    studentName: 'Tarcísio da Graça Langa',
    subjectName: 'Matemática',
    fieldChanged: 'trabalho',
    oldValue: 8.0,
    newValue: 10.0,
    changedBy: 'Prof. Adelino Sitoe',
    reason: 'Entrega de exercício de recuperação aprovado pela direcção de turma.',
    timestamp: '2026-04-02 16:10'
  }
];

export const INITIAL_ATTENDANCE: AttendanceRecord[] = [
  {
    id: 'att-1',
    schoolId: 'school-1',
    date: '2026-04-06',
    sectionId: 'sec-10a',
    subjectId: 'sub-mat-10',
    teacherId: 'teacher-1',
    entries: [
      { studentId: 'student-1', status: 'PRESENTE' },
      { studentId: 'student-2', status: 'PRESENTE' },
      { studentId: 'student-3', status: 'PRESENTE' },
      { studentId: 'student-4', status: 'ATRASO', notes: 'Chegou 15 min após o toque' },
      { studentId: 'student-5', status: 'FALTA', notes: 'Sem justificação' }
    ]
  },
  {
    id: 'att-2',
    schoolId: 'school-1',
    date: '2026-04-07',
    sectionId: 'sec-10a',
    subjectId: 'sub-port-10',
    teacherId: 'teacher-2',
    entries: [
      { studentId: 'student-1', status: 'PRESENTE' },
      { studentId: 'student-2', status: 'JUSTIFICADA', notes: 'Atestado médico entregue na secretaria' },
      { studentId: 'student-3', status: 'PRESENTE' },
      { studentId: 'student-4', status: 'PRESENTE' },
      { studentId: 'student-5', status: 'PRESENTE' }
    ]
  }
];

export const INITIAL_SCHEDULE: ScheduleSlot[] = [
  { id: 'sch-1', schoolId: 'school-1', sectionId: 'sec-10a', dayOfWeek: 1, slotNumber: 1, timeSlot: '07:00 - 07:45', subjectId: 'sub-mat-10', teacherId: 'teacher-1', classroom: 'Sala 12' },
  { id: 'sch-2', schoolId: 'school-1', sectionId: 'sec-10a', dayOfWeek: 1, slotNumber: 2, timeSlot: '07:50 - 08:35', subjectId: 'sub-mat-10', teacherId: 'teacher-1', classroom: 'Sala 12' },
  { id: 'sch-3', schoolId: 'school-1', sectionId: 'sec-10a', dayOfWeek: 1, slotNumber: 3, timeSlot: '08:50 - 09:35', subjectId: 'sub-port-10', teacherId: 'teacher-2', classroom: 'Sala 12' },
  { id: 'sch-4', schoolId: 'school-1', sectionId: 'sec-10a', dayOfWeek: 1, slotNumber: 4, timeSlot: '09:40 - 10:25', subjectId: 'sub-fis-10', teacherId: 'teacher-1', classroom: 'Laboratório' },
  { id: 'sch-5', schoolId: 'school-1', sectionId: 'sec-10a', dayOfWeek: 2, slotNumber: 1, timeSlot: '07:00 - 07:45', subjectId: 'sub-qui-10', teacherId: 'teacher-3', classroom: 'Laboratório' },
  { id: 'sch-6', schoolId: 'school-1', sectionId: 'sec-10a', dayOfWeek: 2, slotNumber: 2, timeSlot: '07:50 - 08:35', subjectId: 'sub-bio-10', teacherId: 'teacher-3', classroom: 'Sala 12' },
  { id: 'sch-7', schoolId: 'school-1', sectionId: 'sec-10a', dayOfWeek: 3, slotNumber: 1, timeSlot: '07:00 - 07:45', subjectId: 'sub-hist-10', teacherId: 'teacher-4', classroom: 'Sala 12' },
  { id: 'sch-8', schoolId: 'school-1', sectionId: 'sec-10a', dayOfWeek: 3, slotNumber: 2, timeSlot: '07:50 - 08:35', subjectId: 'sub-geo-10', teacherId: 'teacher-4', classroom: 'Sala 12' }
];

// Valores em Meticais (MT / MZN)
export const INITIAL_PAYMENTS: PaymentItem[] = [
  {
    id: 'pay-1',
    schoolId: 'school-1',
    studentId: 'student-1',
    studentName: 'Nelsia Fernando Macuácua',
    studentNumber: 'AL-2026-0042',
    gradeLevel: '10ª Classe',
    feeType: 'MATRICULA',
    amount: 1500,
    dueDate: '2026-01-31',
    paidDate: '2026-01-15',
    status: 'PAGO',
    paymentMethod: 'M-PESA',
    transactionRef: 'MPESA-9K284L12',
    receiptNumber: 'REC-MZ-2026-0192'
  },
  {
    id: 'pay-2',
    schoolId: 'school-1',
    studentId: 'student-1',
    studentName: 'Nelsia Fernando Macuácua',
    studentNumber: 'AL-2026-0042',
    gradeLevel: '10ª Classe',
    feeType: 'PROPINA',
    monthRef: 'Fevereiro 2026',
    amount: 2500,
    dueDate: '2026-02-10',
    paidDate: '2026-02-05',
    status: 'PAGO',
    paymentMethod: 'M-PESA',
    transactionRef: 'MPESA-8H192K33',
    receiptNumber: 'REC-MZ-2026-0245'
  },
  {
    id: 'pay-3',
    schoolId: 'school-1',
    studentId: 'student-1',
    studentName: 'Nelsia Fernando Macuácua',
    studentNumber: 'AL-2026-0042',
    gradeLevel: '10ª Classe',
    feeType: 'PROPINA',
    monthRef: 'Março 2026',
    amount: 2500,
    dueDate: '2026-03-10',
    paidDate: '2026-03-08',
    status: 'PAGO',
    paymentMethod: 'E-MOLA',
    transactionRef: 'EMOLA-54019284',
    receiptNumber: 'REC-MZ-2026-0318'
  },
  {
    id: 'pay-4',
    schoolId: 'school-1',
    studentId: 'student-1',
    studentName: 'Nelsia Fernando Macuácua',
    studentNumber: 'AL-2026-0042',
    gradeLevel: '10ª Classe',
    feeType: 'PROPINA',
    monthRef: 'Abril 2026',
    amount: 2500,
    dueDate: '2026-04-10',
    status: 'PENDENTE'
  },
  {
    id: 'pay-5',
    schoolId: 'school-1',
    studentId: 'student-2',
    studentName: 'Edson Zacarias Mondlane',
    studentNumber: 'AL-2026-0043',
    gradeLevel: '10ª Classe',
    feeType: 'PROPINA',
    monthRef: 'Março 2026',
    amount: 2500,
    dueDate: '2026-03-10',
    status: 'EM_DIVIDA'
  },
  {
    id: 'pay-6',
    schoolId: 'school-1',
    studentId: 'student-5',
    studentName: 'Benilde Ivone Chissano',
    studentNumber: 'AL-2026-0046',
    gradeLevel: '10ª Classe',
    feeType: 'MATRICULA',
    amount: 1500,
    dueDate: '2026-01-31',
    status: 'EM_DIVIDA'
  }
];

export const INITIAL_DOCUMENTS: DocumentRecord[] = [
  {
    id: 'doc-1',
    schoolId: 'school-1',
    documentNumber: 'DOC-MZ-2026-0814',
    securityHash: 'MZ948271A8F932E',
    type: 'DECLARACAO_MATRICULA',
    studentId: 'student-1',
    studentName: 'Nelsia Fernando Macuácua',
    gradeLevel: '10ª Classe',
    sectionName: 'Turma A',
    academicYear: 2026,
    issueDate: '2026-02-10',
    issuedBy: 'Sr. Sérgio Nhantumbo (Chefe de Secretaria)',
    status: 'VALIDO',
    details: 'Declaração para efeitos de apresentação junto aos Serviços de Migração e Encarregado.'
  },
  {
    id: 'doc-2',
    schoolId: 'school-1',
    documentNumber: 'DOC-MZ-2026-0922',
    securityHash: 'MZ391827B0C441F',
    type: 'DECLARACAO_APROVEITAMENTO',
    studentId: 'student-3',
    studentName: 'Samira Abdul Carimo',
    gradeLevel: '10ª Classe',
    sectionName: 'Turma A',
    academicYear: 2026,
    issueDate: '2026-03-30',
    issuedBy: 'Dra. Graça Mandlate Cossa (Directora)',
    status: 'VALIDO',
    details: 'Aproveitamento escolar relativo ao 1º Trimestre de 2026 com Média Geral de 17.8 valores.'
  },
  {
    id: 'doc-3',
    schoolId: 'school-1',
    documentNumber: 'DOC-MZ-2025-1105',
    securityHash: 'MZ771928K99014E',
    type: 'CERTIFICADO',
    studentId: 'student-1',
    studentName: 'Nelsia Fernando Macuácua',
    gradeLevel: '9ª Classe',
    academicYear: 2025,
    issueDate: '2025-12-15',
    issuedBy: 'Ministério da Educação e Desenvolvimento Humano (MINEDH)',
    status: 'VALIDO',
    details: 'Certificado de Habilitações Literárias do 1º Ciclo do Ensino Secundário Geral.'
  }
];

export const INITIAL_TRANSFERS: TransferRecord[] = [
  {
    id: 'trf-1',
    schoolId: 'school-1',
    studentId: 'student-2',
    studentName: 'Edson Zacarias Mondlane',
    type: 'ENTRADA',
    originSchool: 'Escola Secundária de Chibuto (Gaza)',
    destinationSchool: 'Escola Secundária Josina Machel (Maputo Cidade)',
    gradeLevel: '10ª Classe',
    reason: 'Mudança de residência dos encarregados de educação para Maputo.',
    requestDate: '2026-01-10',
    processDate: '2026-01-16',
    transferGuideNumber: 'GT-GZ-2026-0044',
    status: 'CONCLUIDA'
  },
  {
    id: 'trf-2',
    schoolId: 'school-1',
    studentId: 'student-6',
    studentName: 'Kelvin Manuel Muchanga',
    type: 'SAIDA',
    originSchool: 'Escola Secundária Josina Machel (Maputo Cidade)',
    destinationSchool: 'Escola Secundária de Maxixe (Inhambane)',
    gradeLevel: '11ª Classe',
    reason: 'Transferência de posto de trabalho do encarregado de educação.',
    requestDate: '2026-03-25',
    transferGuideNumber: 'GT-MP-2026-0189',
    status: 'APROVADA'
  }
];

export const INITIAL_NOTIFICATIONS: NotificationMessage[] = [
  {
    id: 'notif-1',
    schoolId: 'school-1',
    title: 'Abertura Oficial do 1º Trimestre e Boas-Vindas',
    body: 'A Direcção da Escola Secundária Josina Machel informa que as aulas do ano lectivo 2026 iniciam conforme o calendário oficial do MINEDH. Uso obrigatório do uniforme escolar oficial.',
    category: 'AVISO',
    targetAudience: 'TODOS',
    channel: 'SISTEMA',
    createdAt: '2026-02-01 08:00'
  },
  {
    id: 'notif-2',
    schoolId: 'school-1',
    title: 'Reunião Geral de Encarregados de Educação - 10ª Classe',
    body: 'Convidam-se todos os pais e encarregados da 10ª classe para a 1ª reunião pedagógica no sábado, dia 14 de Abril, às 08:30 no Anfiteatro Central.',
    category: 'REUNIAO',
    targetAudience: 'ENCARREGADOS',
    channel: 'SMS',
    createdAt: '2026-04-04 10:30'
  },
  {
    id: 'notif-3',
    schoolId: 'school-1',
    title: 'Publicação das Pautas Provisórias do 1º Trimestre',
    body: 'As pautas do 1º trimestre estão disponíveis para consulta no painel do aluno e encarregado. Reclamações de notas devem ser submetidas até sexta-feira.',
    category: 'NOTAS',
    targetAudience: 'ALUNOS',
    channel: 'SISTEMA',
    createdAt: '2026-04-05 16:00'
  },
  {
    id: 'notif-4',
    schoolId: 'school-1',
    title: 'Lembrete de Pagamento de Propinas - Abril 2026',
    body: 'Recordamos que o prazo para regularização da propina do mês de Abril termina no dia 10. Evite a sobretaxa de mora utilizando M-Pesa ou e-Mola.',
    category: 'PAGAMENTOS',
    targetAudience: 'ENCARREGADOS',
    channel: 'WHATSAPP',
    createdAt: '2026-04-06 09:00'
  }
];

export const INITIAL_AUDIT_LOGS: AuditLog[] = [
  {
    id: 'log-1',
    schoolId: 'school-1',
    userName: 'Sr. Sérgio Nhantumbo',
    userRole: 'SECRETARIA',
    action: 'CONFIRMOU_MATRICULA',
    module: 'MATRICULAS',
    details: 'Matrícula confirmada para a aluna Nelsia Fernando Macuácua na 10ª Classe Turma A.',
    timestamp: '2026-01-15 11:24',
    ipAddress: '197.249.4.12 (Maputo/TMCEL)'
  },
  {
    id: 'log-2',
    schoolId: 'school-1',
    userName: 'Prof. Adelino Sitoe',
    userRole: 'PROFESSOR',
    action: 'LANCAMENTO_NOTAS',
    module: 'NOTAS',
    details: 'Lançamento de notas de ACP e MPT da disciplina de Matemática para a Turma A 10ª Classe.',
    timestamp: '2026-03-28 14:40',
    ipAddress: '197.249.4.88 (Maputo/Vodacom)'
  },
  {
    id: 'log-3',
    schoolId: 'school-1',
    userName: 'Dra. Graça Mandlate Cossa',
    userRole: 'DIRECAO',
    action: 'VALIDOU_PAUTA',
    module: 'PAUTAS',
    details: 'Homologação e assinatura digital da pauta trimestral de Matemática da 10ª Classe A.',
    timestamp: '2026-03-29 09:15',
    ipAddress: '105.234.12.5 (Maputo/Movitel)'
  },
  {
    id: 'log-4',
    schoolId: 'school-1',
    userName: 'Eng. Dionísio Matsinhe',
    userRole: 'ADMIN',
    action: 'CONFIGURACAO_SNE',
    module: 'SNE',
    details: 'Actualização da grelha curricular da 10ª Classe com introdução do módulo de Agro-Pecuária.',
    timestamp: '2026-04-01 17:30',
    ipAddress: '197.249.2.1 (Maputo)'
  }
];

export const DEFAULT_ROLE_PERMISSIONS: Record<UserRole, RolePermissions> = {
  ADMIN: {
    canManageUsers: true,
    canManageSchool: true,
    canManageStudents: true,
    canManageTeachers: true,
    canManageEnrollments: true,
    canManageClasses: true,
    canManageSubjects: true,
    canManageSchedules: true,
    canLaunchGrades: true,
    canApprovePautas: true,
    canManageAttendance: true,
    canManageFinance: true,
    canIssueDocuments: true,
    canManageTransfers: true,
    canViewReports: true,
    canPublishAnnouncements: true,
    canConfigureSNE: true,
    canViewAuditLogs: true
  },
  DIRECAO: {
    canManageUsers: false,
    canManageSchool: true,
    canManageStudents: true,
    canManageTeachers: true,
    canManageEnrollments: false,
    canManageClasses: true,
    canManageSubjects: true,
    canManageSchedules: true,
    canLaunchGrades: false,
    canApprovePautas: true,
    canManageAttendance: true,
    canManageFinance: false,
    canIssueDocuments: true,
    canManageTransfers: true,
    canViewReports: true,
    canPublishAnnouncements: true,
    canConfigureSNE: true,
    canViewAuditLogs: true
  },
  SECRETARIA: {
    canManageUsers: false,
    canManageSchool: false,
    canManageStudents: true,
    canManageTeachers: false,
    canManageEnrollments: true,
    canManageClasses: false,
    canManageSubjects: false,
    canManageSchedules: false,
    canLaunchGrades: false,
    canApprovePautas: false,
    canManageAttendance: false,
    canManageFinance: true,
    canIssueDocuments: true,
    canManageTransfers: true,
    canViewReports: false,
    canPublishAnnouncements: false,
    canConfigureSNE: false,
    canViewAuditLogs: false
  },
  PROFESSOR: {
    canManageUsers: false,
    canManageSchool: false,
    canManageStudents: false,
    canManageTeachers: false,
    canManageEnrollments: false,
    canManageClasses: false,
    canManageSubjects: false,
    canManageSchedules: false,
    canLaunchGrades: true,
    canApprovePautas: false,
    canManageAttendance: true,
    canManageFinance: false,
    canIssueDocuments: false,
    canManageTransfers: false,
    canViewReports: false,
    canPublishAnnouncements: true,
    canConfigureSNE: false,
    canViewAuditLogs: false
  },
  ALUNO: {
    canManageUsers: false,
    canManageSchool: false,
    canManageStudents: false,
    canManageTeachers: false,
    canManageEnrollments: false,
    canManageClasses: false,
    canManageSubjects: false,
    canManageSchedules: false,
    canLaunchGrades: false,
    canApprovePautas: false,
    canManageAttendance: false,
    canManageFinance: false,
    canIssueDocuments: false,
    canManageTransfers: false,
    canViewReports: false,
    canPublishAnnouncements: false,
    canConfigureSNE: false,
    canViewAuditLogs: false
  },
  ENCARREGADO: {
    canManageUsers: false,
    canManageSchool: false,
    canManageStudents: false,
    canManageTeachers: false,
    canManageEnrollments: false,
    canManageClasses: false,
    canManageSubjects: false,
    canManageSchedules: false,
    canLaunchGrades: false,
    canApprovePautas: false,
    canManageAttendance: false,
    canManageFinance: false,
    canIssueDocuments: false,
    canManageTransfers: false,
    canViewReports: false,
    canPublishAnnouncements: false,
    canConfigureSNE: false,
    canViewAuditLogs: false
  }
};

export const INITIAL_TASKS: SchoolTask[] = [
  {
    id: 'task-1',
    schoolId: 'school-1',
    teacherId: 'teacher-1',
    teacherName: 'Prof. Adelino Sitoe',
    sectionId: 'sec-10a',
    sectionName: 'Turma A',
    subjectId: 'sub-mat-10',
    subjectName: 'Matemática',
    title: 'Ficha de Exercícios: Equações Quadráticas e Função Quadrática',
    description: 'Resolver todos os exercícios das páginas 45 a 48 do Manual de Matemática da 10ª Classe (MINEDH). Entrega obrigatória antes do 2º Teste.',
    attachmentName: 'Ficha_03_Equacoes_10Classe.pdf',
    dueDate: '2026-04-18',
    createdAt: '2026-04-02 10:00'
  },
  {
    id: 'task-2',
    schoolId: 'school-1',
    teacherId: 'teacher-2',
    teacherName: 'Profª. Maria Helena Tembe',
    sectionId: 'sec-10a',
    sectionName: 'Turma A',
    subjectId: 'sub-port-10',
    subjectName: 'Português',
    title: 'Análise Literária: "Nós Matámos o Cão-Tinhoso" de Luís Bernardo Honwana',
    description: 'Elaborar uma síntese reflexiva sobre a temática social e o simbolismo dos contos moçambicanos estudados nas aulas presenciais.',
    attachmentName: 'Guiao_Analise_Literaria_Honwana.pdf',
    dueDate: '2026-04-22',
    createdAt: '2026-04-04 11:30'
  }
];

export const INITIAL_PAUTA_APPROVALS: PautaApproval[] = [
  {
    id: 'papp-1',
    schoolId: 'school-1',
    sectionId: 'sec-10a',
    sectionName: '10ª Classe - Turma A',
    term: 1,
    pautaType: 'TRIMESTRAL',
    submittedByTeacherId: 'teacher-1',
    submittedByTeacherName: 'Prof. Adelino Sitoe',
    submittedAt: '2026-03-28 17:00',
    status: 'HOMOLOGADA',
    approvedBy: 'Dra. Graça Mandlate Cossa',
    approvedAt: '2026-03-29 09:15'
  },
  {
    id: 'papp-2',
    schoolId: 'school-1',
    sectionId: 'sec-10b',
    sectionName: '10ª Classe - Turma B',
    term: 1,
    pautaType: 'TRIMESTRAL',
    submittedByTeacherId: 'teacher-2',
    submittedByTeacherName: 'Profª. Maria Helena Tembe',
    submittedAt: '2026-04-02 14:00',
    status: 'PENDENTE'
  }
];

export interface DatabaseState {
  schools: School[];
  academicYears: AcademicYear[];
  sneConfig: SNEConfig;
  users: UserProfile[];
  rolePermissions: Record<UserRole, RolePermissions>;
  teachers: Teacher[];
  sections: ClassSection[];
  subjects: Subject[];
  students: Student[];
  enrollments: Enrollment[];
  grades: GradeEntry[];
  gradeAudits: GradeAuditLog[];
  attendance: AttendanceRecord[];
  schedules: ScheduleSlot[];
  payments: PaymentItem[];
  documents: DocumentRecord[];
  transfers: TransferRecord[];
  notifications: NotificationMessage[];
  auditLogs: AuditLog[];
  tasks: SchoolTask[];
  pautaApprovals: PautaApproval[];
}

export const loadInitialDatabase = (): DatabaseState => {
  if (typeof window === 'undefined') {
    return {
      schools: INITIAL_SCHOOLS,
      academicYears: INITIAL_ACADEMIC_YEARS,
      sneConfig: INITIAL_SNE_CONFIG,
      users: INITIAL_USERS,
      rolePermissions: DEFAULT_ROLE_PERMISSIONS,
      teachers: INITIAL_TEACHERS,
      sections: INITIAL_SECTIONS,
      subjects: INITIAL_SUBJECTS,
      students: INITIAL_STUDENTS,
      enrollments: INITIAL_ENROLLMENTS,
      grades: INITIAL_GRADES,
      gradeAudits: INITIAL_AUDIT_GRADES,
      attendance: INITIAL_ATTENDANCE,
      schedules: INITIAL_SCHEDULE,
      payments: INITIAL_PAYMENTS,
      documents: INITIAL_DOCUMENTS,
      transfers: INITIAL_TRANSFERS,
      notifications: INITIAL_NOTIFICATIONS,
      auditLogs: INITIAL_AUDIT_LOGS,
      tasks: INITIAL_TASKS,
      pautaApprovals: INITIAL_PAUTA_APPROVALS
    };
  }

  const defaultDb: DatabaseState = {
    schools: INITIAL_SCHOOLS,
    academicYears: INITIAL_ACADEMIC_YEARS,
    sneConfig: INITIAL_SNE_CONFIG,
    users: INITIAL_USERS,
    rolePermissions: DEFAULT_ROLE_PERMISSIONS,
    teachers: INITIAL_TEACHERS,
    sections: INITIAL_SECTIONS,
    subjects: INITIAL_SUBJECTS,
    students: INITIAL_STUDENTS,
    enrollments: INITIAL_ENROLLMENTS,
    grades: INITIAL_GRADES,
    gradeAudits: INITIAL_AUDIT_GRADES,
    attendance: INITIAL_ATTENDANCE,
    schedules: INITIAL_SCHEDULE,
    payments: INITIAL_PAYMENTS,
    documents: INITIAL_DOCUMENTS,
    transfers: INITIAL_TRANSFERS,
    notifications: INITIAL_NOTIFICATIONS,
    auditLogs: INITIAL_AUDIT_LOGS,
    tasks: INITIAL_TASKS,
    pautaApprovals: INITIAL_PAUTA_APPROVALS
  };

  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      const rawTeachers: Teacher[] = Array.isArray(parsed.teachers) ? parsed.teachers : defaultDb.teachers;
      const rawSubjects: Subject[] = Array.isArray(parsed.subjects) ? parsed.subjects : defaultDb.subjects;

      const normalizedTeachers: Teacher[] = rawTeachers.map((t) => ({
        ...t,
        assignedSubjects: t.assignedSubjects || t.subjects || ['Geral'],
        subjects: t.subjects || t.assignedSubjects || ['Geral'],
        assignedClasses: t.assignedClasses || ['10ª Classe'],
        assignedSections: t.assignedSections || [],
        workloadHours: t.workloadHours || t.weeklyHours || 24,
        weeklyHours: t.weeklyHours || t.workloadHours || 24,
        institutionGraduated: t.institutionGraduated || 'Universidade Pedagógica (UP)',
        hireDate: t.hireDate || '2022-02-01'
      }));

      const normalizedSubjects: Subject[] = rawSubjects.map((s) => ({
        ...s,
        applicableGrades: s.applicableGrades && s.applicableGrades.length > 0
          ? s.applicableGrades
          : [s.gradeLevel || '10ª Classe'],
        type: s.type || 'NUCLEAR',
        isRequired: s.isRequired ?? (!s.isElective)
      }));

      return {
        ...defaultDb,
        ...parsed,
        schools: Array.isArray(parsed.schools) && parsed.schools.length > 0 ? parsed.schools : defaultDb.schools,
        academicYears: Array.isArray(parsed.academicYears) ? parsed.academicYears : defaultDb.academicYears,
        users: Array.isArray(parsed.users) ? parsed.users : defaultDb.users,
        rolePermissions: parsed.rolePermissions || DEFAULT_ROLE_PERMISSIONS,
        teachers: normalizedTeachers,
        sections: Array.isArray(parsed.sections) ? parsed.sections : defaultDb.sections,
        subjects: normalizedSubjects,
        students: Array.isArray(parsed.students) ? parsed.students : defaultDb.students,
        enrollments: Array.isArray(parsed.enrollments) ? parsed.enrollments : defaultDb.enrollments,
        grades: Array.isArray(parsed.grades) ? parsed.grades : defaultDb.grades,
        gradeAudits: Array.isArray(parsed.gradeAudits) ? parsed.gradeAudits : defaultDb.gradeAudits,
        attendance: Array.isArray(parsed.attendance) ? parsed.attendance : defaultDb.attendance,
        schedules: Array.isArray(parsed.schedules) ? parsed.schedules : defaultDb.schedules,
        payments: Array.isArray(parsed.payments) ? parsed.payments : defaultDb.payments,
        documents: Array.isArray(parsed.documents) ? parsed.documents : defaultDb.documents,
        transfers: Array.isArray(parsed.transfers) ? parsed.transfers : defaultDb.transfers,
        notifications: Array.isArray(parsed.notifications) ? parsed.notifications : defaultDb.notifications,
        auditLogs: Array.isArray(parsed.auditLogs) ? parsed.auditLogs : defaultDb.auditLogs,
        tasks: Array.isArray(parsed.tasks) ? parsed.tasks : defaultDb.tasks,
        pautaApprovals: Array.isArray(parsed.pautaApprovals) ? parsed.pautaApprovals : defaultDb.pautaApprovals,
        sneConfig: {
          ...INITIAL_SNE_CONFIG,
          ...(parsed.sneConfig || {})
        }
      };
    }
  } catch (err) {
    console.error('Erro ao ler base de dados local:', err);
  }

  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(defaultDb));
  } catch (e) {
    console.warn('Falha ao inicializar localStorage:', e);
  }

  return defaultDb;
};

export const saveDatabase = (state: DatabaseState): void => {
  if (typeof window !== 'undefined') {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (err) {
      console.error('Erro ao guardar base de dados:', err);
    }
  }
};
