/**
 * EduGest Moçambique - Aplicação Principal (App.tsx)
 * Plataforma Centralizada de Gestão Escolar para Moçambique (SNE).
 */

import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/common/Header';
import { Sidebar } from './components/common/Sidebar';
import { DashboardView } from './components/dashboard/DashboardView';
import { StudentsView } from './components/students/StudentsView';
import { TeachersView } from './components/teachers/TeachersView';
import { EnrollmentsView } from './components/enrollments/EnrollmentsView';
import { ClassesView } from './components/classes/ClassesView';
import { SubjectsView } from './components/subjects/SubjectsView';
import { GradesSpreadsheetView } from './components/grades/GradesSpreadsheetView';
import { PautasView } from './components/pautas/PautasView';
import { AttendanceView } from './components/attendance/AttendanceView';
import { SchedulesView } from './components/schedules/SchedulesView';
import { FinanceView } from './components/finance/FinanceView';
import { DocumentsView } from './components/documents/DocumentsView';
import { PublicValidatorView } from './components/documents/PublicValidatorView';
import { TransfersView } from './components/transfers/TransfersView';
import { ReportsView } from './components/reports/ReportsView';
import { CommunicationView } from './components/communication/CommunicationView';
import { SNEConfigView } from './components/sne/SNEConfigView';
import { AuditLogsView } from './components/audit/AuditLogsView';
import { UsersAccessView } from './components/users/UsersAccessView';
import { DirecaoDashboardView } from './components/direcao/DirecaoDashboardView';
import { ProfessorPortalView } from './components/professor/ProfessorPortalView';
import { AlunoPortalView } from './components/aluno/AlunoPortalView';
import { EncarregadoPortalView } from './components/encarregado/EncarregadoPortalView';
import { SchoolCalendarView } from './components/calendar/SchoolCalendarView';
import { LoginModal } from './components/auth/LoginModal';
import { Menu, X, WifiOff } from 'lucide-react';
import { useOnlineStatus } from './hooks/usePWAInstall';

const MainContent: React.FC = () => {
  const { activeTab, setActiveTab, isLoggedIn } = useApp();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [globalSearchTerm, setGlobalSearchTerm] = useState('');
  const isOnline = useOnlineStatus();

  const handleGlobalSearch = (term: string) => {
    setGlobalSearchTerm(term);
    setActiveTab('alunos');
  };

  const renderActiveView = () => {
    switch (activeTab) {
      case 'dashboard':
        return <DashboardView />;
      case 'portal-direcao':
        return <DirecaoDashboardView />;
      case 'portal-professor':
        return <ProfessorPortalView />;
      case 'portal-aluno':
        return <AlunoPortalView />;
      case 'portal-encarregado':
        return <EncarregadoPortalView />;
      case 'calendario':
        return <SchoolCalendarView />;
      case 'utilizadores':
      case 'permissoes':
        return <UsersAccessView />;
      case 'alunos':
        return <StudentsView initialSearch={globalSearchTerm} />;
      case 'professores':
        return <TeachersView />;
      case 'matriculas':
        return <EnrollmentsView />;
      case 'turmas':
        return <ClassesView />;
      case 'disciplinas':
        return <SubjectsView />;
      case 'avaliacoes':
        return <GradesSpreadsheetView />;
      case 'pautas':
        return <PautasView />;
      case 'assiduidade':
        return <AttendanceView />;
      case 'horarios':
        return <SchedulesView />;
      case 'pagamentos':
        return <FinanceView />;
      case 'documentos':
        return <DocumentsView />;
      case 'validar-documento':
        return <PublicValidatorView />;
      case 'transferencias':
        return <TransfersView />;
      case 'relatorios':
        return <ReportsView />;
      case 'comunicacao':
        return <CommunicationView />;
      case 'sne-config':
        return <SNEConfigView />;
      case 'auditoria':
      case 'backup':
        return <AuditLogsView />;
      default:
        return <DashboardView />;
    }
  };

  return (
    <div className="flex h-screen w-full overflow-hidden bg-slate-50 font-sans">
      {/* Modal de Login (Aparece se sessão não iniciada) */}
      {!isLoggedIn && <LoginModal isOpen={!isLoggedIn} />}

      {/* Menu Lateral de Navegação (Sidebar) */}
      <Sidebar isOpen={sidebarOpen} onCloseMobile={() => setSidebarOpen(false)} />

      {/* Conteúdo Principal */}
      <div className="flex flex-1 flex-col overflow-hidden min-w-0">
        {/* Barra de Notificação Offline se conexão perdida */}
        {!isOnline && (
          <div className="no-print bg-amber-500 px-4 py-1 text-center text-xs font-bold text-white flex items-center justify-center gap-1.5 shadow-xs">
            <WifiOff className="h-3.5 w-3.5" />
            Modo Offline Ativo: As alterações estão a ser guardadas localmente na memória e serão sincronizadas.
          </div>
        )}

        {/* Cabeçalho */}
        <div className="flex items-center">
          {/* Botão Hambúrguer Mobile */}
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            aria-label="Abrir Menu"
            className="no-print p-3 text-slate-600 hover:text-slate-900 lg:hidden focus:outline-none"
          >
            {sidebarOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>

          <div className="flex-1">
            <Header onSearchTrigger={handleGlobalSearch} />
          </div>
        </div>

        {/* Área de Visualização com Scroll Independente */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 custom-scrollbar">
          <div className="mx-auto max-w-7xl">
            {renderActiveView()}
          </div>
        </main>
      </div>
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  );
}
