/**
 * EduGest Moçambique - Tipos e Modelos de Dados
 * Em conformidade com o Sistema Nacional de Educação (SNE) de Moçambique
 */

export type UserRole = 'ADMIN' | 'DIRECAO' | 'SECRETARIA' | 'PROFESSOR' | 'ENCARREGADO' | 'ALUNO';

export interface RolePermissions {
  canManageUsers: boolean;
  canManageSchool: boolean;
  canManageStudents: boolean;
  canManageTeachers: boolean;
  canManageEnrollments: boolean;
  canManageClasses: boolean;
  canManageSubjects: boolean;
  canManageSchedules: boolean;
  canLaunchGrades: boolean;
  canApprovePautas: boolean;
  canManageAttendance: boolean;
  canManageFinance: boolean;
  canIssueDocuments: boolean;
  canManageTransfers: boolean;
  canViewReports: boolean;
  canPublishAnnouncements: boolean;
  canConfigureSNE: boolean;
  canViewAuditLogs: boolean;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  accessCode: string; // Ex: PROF-2026-0048, ALU-2026-0421, ENC-2026-0012, ADM-2026-0001
  pin: string; // Senha ou PIN de 4 a 6 dígitos
  status: 'ACTIVO' | 'BLOQUEADO' | 'INACTIVO';
  avatarUrl?: string;
  schoolId: string;
  phone?: string;
  lastLogin?: string;
  isRevoked?: boolean;
  linkedStudentId?: string; // Para encarregados e alunos
  linkedStudentIds?: string[]; // Para encarregados com múltiplos educandos
  linkedTeacherId?: string; // Para professores
  customPermissions?: Partial<RolePermissions>;
}

export interface School {
  id: string;
  name: string;
  code: string;
  type: 'PUBLICA' | 'PRIVADA' | 'COMUNITARIA';
  province: string;
  district: string;
  address: string;
  phone: string;
  email: string;
  directorName: string;
  logoUrl?: string;
  nuit: string;
}

export interface AcademicYear {
  id: string;
  year: number; // ex: 2026
  status: 'PLANEAMENTO' | 'ACTIVO' | 'ENCERRADO';
  startDate: string;
  endDate: string;
  currentTerm: 1 | 2 | 3;
}

export interface SNELevel {
  id: string;
  name: string; // ex: "Ensino Primário", "Ensino Secundário Geral - 1º Ciclo", "Ensino Secundário Geral - 2º Ciclo"
  cycles: {
    cycleName: string; // ex: "1º Ciclo (1ª e 2ª Classes)"
    classes: string[]; // ["1ª Classe", "2ª Classe"]
  }[];
}

export interface SNESubjectTemplate {
  id: string;
  code: string;
  name: string;
  category: 'LETRAS' | 'CIENCIAS' | 'GERAL' | 'VOCACIONAL';
  classes: string[];
  weeklyHours: number;
}

export interface SNEConfig {
  academicYear: number;
  currentTerm: number;
  minGrade: number;
  maxGrade: number;
  passingGrade: number;
  minPassingGrade: number; // Moçambique: 10 valores
  termsCount: number; // 3 Trimestres
  evaluationFormula: string; // 'STANDARD_MINEDH'
  maxAbsencePercentage: number; // 25% limite oficial de faltas
  examExemptionGrade: number;
  examAdmissionGrade: number;
  gradingFormula: string;
  mptWeight: number;
  acpWeight: number;
  allowGradeEditingAfterLock: boolean;
  levels: SNELevel[];
}

export interface Student {
  id: string;
  schoolId: string;
  studentNumber: string; // ex: "AL-2026-0421"
  fullName: string;
  gender: 'M' | 'F';
  birthDate: string;
  birthPlace: string; // Naturalidade
  district: string;
  province: string;
  nationality: string;
  idDocType: 'BI' | 'CEDULA' | 'PASSAPORTE' | 'DIRE';
  idDocNumber: string;
  nuit?: string;
  phone?: string;
  address: string;
  photoUrl?: string;
  fatherName: string;
  motherName: string;
  guardianName: string;
  guardianPhone: string;
  guardianEmail?: string;
  guardianRelation: 'PAI' | 'MAE' | 'TIO' | 'AVO' | 'TUTOR';
  medicalNotes?: string;
  specialNeeds?: string;
  schoolHistory?: string;
  currentClass: string; // ex: "10ª Classe"
  currentSection: string; // ex: "Turma A"
  status: 'ACTIVO' | 'TRANSFERIDO' | 'DESISTENTE' | 'GRADUADO';
  createdAt: string;
}

export interface Teacher {
  id: string;
  schoolId: string;
  employeeNumber: string; // ex: "DOC-2024-089"
  fullName: string;
  gender: 'M' | 'F';
  birthDate: string;
  phone: string;
  email: string;
  nuit: string;
  academicDegree: string; // Licenciatura em Ensino de Matemática, UP
  specializationArea?: string; // Ciências Exactas
  assignedSubjects: string[]; // ["Matemática", "Física"]
  subjects?: string[]; // Alias para compatibilidade
  assignedClasses?: string[]; // ["10ª Classe", "11ª Classe"]
  assignedSections: string[]; // IDs das turmas
  status: 'ACTIVO' | 'LICENCA' | 'INACTIVO';
  workloadHours: number;
  weeklyHours?: number; // Alias para compatibilidade
  institutionGraduated?: string;
  hireDate?: string;
}

export interface ClassSection {
  id: string;
  schoolId: string;
  academicYear: number;
  gradeLevel: string; // ex: "10ª Classe"
  name: string; // ex: "Turma A"
  shift: 'DIURNO' | 'VESPERTINO' | 'NOTURNO';
  classroom: string; // Sala 04
  directorTeacherId: string; // Director de Turma
  maxCapacity: number;
  currentEnrolled: number;
  courseArea?: 'GERAL' | 'CIENCIAS' | 'LETRAS';
}

export interface Subject {
  id: string;
  schoolId: string;
  code: string;
  name: string;
  gradeLevel: string; // 10ª Classe
  weeklyHours: number;
  teacherId?: string;
  teacherName?: string;
  isElective: boolean;
  applicableGrades?: string[];
  type?: 'NUCLEAR' | 'COMPLEMENTAR' | 'OPCAO';
  isRequired?: boolean;
}

export interface Enrollment {
  id: string;
  schoolId: string;
  academicYear: number;
  studentId: string;
  studentName: string;
  gradeLevel: string;
  sectionId: string;
  sectionName: string;
  enrollmentNumber: string; // ex: "MAT-2026-0038"
  date: string;
  status: 'PRE_MATRICULA' | 'PENDENTE' | 'CONFIRMADA' | 'CANCELADA' | 'TRANSFERIDA';
  guardianName: string;
  guardianPhone: string;
  receiptNumber?: string;
}

export interface GradeEntry {
  id: string;
  schoolId: string;
  academicYear: number;
  studentId: string;
  subjectId: string;
  sectionId: string;
  term: 1 | 2 | 3;
  acs1: number | null; // Avaliação Contínua 1 (0-20)
  acs2: number | null; // Avaliação Contínua 2 (0-20)
  trabalho: number | null; // Tarefa / Trabalho de Investigação (0-20)
  acp: number | null; // Avaliação de Controlo Periódico / Prova Trimestral (0-20)
  mpt: number | null; // Média Parcial Trimestral
  mt: number | null; // Média do Trimestre
  examGrade?: number | null; // Exame Nacional (se aplicável)
  finalGrade?: number | null; // Média Final
  status: 'RASCUNHO' | 'VALIDADA' | 'BLOQUEADA';
  lastModifiedBy: string;
  lastModifiedAt: string;
}

export interface GradeAuditLog {
  id: string;
  gradeEntryId: string;
  studentName: string;
  subjectName: string;
  fieldChanged: string;
  oldValue: number | null;
  newValue: number | null;
  changedBy: string;
  reason: string;
  timestamp: string;
}

export interface AttendanceRecord {
  id: string;
  schoolId: string;
  date: string;
  sectionId: string;
  subjectId: string;
  teacherId: string;
  entries: {
    studentId: string;
    status: 'PRESENTE' | 'FALTA' | 'JUSTIFICADA' | 'ATRASO';
    notes?: string;
  }[];
}

export interface ScheduleSlot {
  id: string;
  schoolId: string;
  sectionId: string;
  dayOfWeek: 1 | 2 | 3 | 4 | 5; // Seg a Sex
  timeSlot: string; // "07:30 - 08:15", "08:15 - 09:00", etc.
  slotNumber: number; // 1 a 6
  subjectId: string;
  teacherId: string;
  classroom: string;
}

export interface PaymentItem {
  id: string;
  schoolId: string;
  studentId: string;
  studentName: string;
  studentNumber: string;
  gradeLevel: string;
  feeType: 'PROPINA' | 'MATRICULA' | 'INSCRICAO' | 'EXAME' | 'CERTIFICADO' | 'UNIFORME';
  monthRef?: string; // "Fevereiro 2026", "Março 2026"
  amount: number; // em Meticais (MT)
  dueDate: string;
  paidDate?: string;
  status: 'PAGO' | 'PENDENTE' | 'EM_DIVIDA' | 'CANCELADO';
  paymentMethod?: 'M-PESA' | 'E-MOLA' | 'MKESH' | 'BIM_IZI' | 'PONTO24' | 'BANCO' | 'NUMERARIO';
  transactionRef?: string;
  receiptNumber?: string;
}

export interface DocumentRecord {
  id: string;
  schoolId: string;
  documentNumber: string; // ex: "DOC-MZ-2026-0814"
  securityHash: string; // Código hash para verificação pública QR
  type: 'DECLARACAO_MATRICULA' | 'DECLARACAO_FREQUENCIA' | 'DECLARACAO_APROVEITAMENTO' | 'CERTIFICADO' | 'COMPROVATIVO' | 'RECIBO' | 'PAUTA_OFICIAL';
  studentId: string;
  studentName: string;
  gradeLevel: string;
  sectionName?: string;
  academicYear: number;
  issueDate: string;
  issuedBy: string;
  status: 'VALIDO' | 'ANULADO' | 'EXPIRADO';
  details?: string;
}

export interface TransferRecord {
  id: string;
  schoolId: string;
  studentId: string;
  studentName: string;
  type: 'ENTRADA' | 'SAIDA';
  originSchool: string;
  destinationSchool: string;
  gradeLevel: string;
  reason: string;
  requestDate: string;
  processDate?: string;
  transferGuideNumber: string;
  status: 'PENDENTE' | 'APROVADA' | 'CONCLUIDA' | 'RECUSADA';
  attachedDocs?: string[];
}

export interface NotificationMessage {
  id: string;
  schoolId: string;
  title: string;
  body: string;
  category: 'AVISO' | 'NOTAS' | 'FALTAS' | 'PAGAMENTOS' | 'EXAMES' | 'REUNIAO';
  targetAudience: 'TODOS' | 'ENCARREGADOS' | 'PROFESSORES' | 'ALUNOS' | 'TURMA';
  targetSectionId?: string;
  channel: 'SISTEMA' | 'SMS' | 'WHATSAPP' | 'EMAIL';
  createdAt: string;
  isRead?: boolean;
}

export interface AuditLog {
  id: string;
  schoolId: string;
  userName: string;
  userRole: UserRole;
  action: string; // "CRIOU_MATRICULA", "LANCAMENTO_NOTA", "EMITIU_CERTIFICADO"
  module: string; // "NOTAS", "FINANCAS", "ALUNOS", "SNE"
  details: string;
  timestamp: string;
  ipAddress: string;
}

export interface SchoolTask {
  id: string;
  schoolId: string;
  teacherId: string;
  teacherName: string;
  sectionId: string;
  sectionName: string;
  subjectId: string;
  subjectName: string;
  title: string;
  description: string;
  type?: 'TPC' | 'TRABALHO' | 'FICHA' | 'LEITURA' | 'PROJETO';
  attachmentName?: string;
  dueDate: string;
  createdAt: string;
}

export interface PautaApproval {
  id: string;
  schoolId: string;
  sectionId: string;
  sectionName: string;
  term: 1 | 2 | 3;
  pautaType: 'TRIMESTRAL' | 'GERAL' | 'EXAME';
  submittedByTeacherId: string;
  submittedByTeacherName: string;
  submittedAt: string;
  status: 'PENDENTE' | 'HOMOLOGADA' | 'REJEITADA';
  approvedBy?: string;
  approvedAt?: string;
  rejectionReason?: string;
}
